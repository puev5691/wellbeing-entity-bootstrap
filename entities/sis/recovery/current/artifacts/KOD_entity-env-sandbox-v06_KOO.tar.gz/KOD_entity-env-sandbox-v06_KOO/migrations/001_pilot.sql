PRAGMA foreign_keys = ON;

CREATE TABLE entities (
  entity_id TEXT PRIMARY KEY,
  display_name TEXT,
  state TEXT NOT NULL DEFAULT 'active',
  row_version INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE instances (
  instance_id TEXT PRIMARY KEY,
  entity_id TEXT NOT NULL REFERENCES entities(entity_id),
  lifecycle TEXT NOT NULL,
  work_mode TEXT NOT NULL,
  writer_grant_ref TEXT,
  writer_generation INTEGER,
  writer_scope TEXT,
  row_version INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE authority_refs (
  authority_ref TEXT PRIMARY KEY,
  holder_entity_id TEXT NOT NULL REFERENCES entities(entity_id),
  issuer_kind TEXT NOT NULL CHECK (issuer_kind IN ('entity','operator','approved_process')),
  issuer_ref TEXT NOT NULL,
  action TEXT NOT NULL,
  object_scope TEXT NOT NULL,
  conditions_json TEXT,
  parent_authority_ref TEXT REFERENCES authority_refs(authority_ref),
  evidence_locator TEXT,
  evidence_version TEXT,
  state TEXT NOT NULL DEFAULT 'active',
  row_version INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE writer_grants (
  writer_grant_id TEXT PRIMARY KEY,
  entity_id TEXT NOT NULL REFERENCES entities(entity_id),
  instance_id TEXT NOT NULL REFERENCES instances(instance_id),
  authority_ref TEXT NOT NULL REFERENCES authority_refs(authority_ref),
  scope TEXT NOT NULL,
  generation INTEGER NOT NULL,
  state TEXT NOT NULL CHECK (state IN ('active','released','superseded')),
  grant_evidence_ref TEXT NOT NULL,
  row_version INTEGER NOT NULL DEFAULT 1,
  UNIQUE(entity_id, scope, generation)
);
CREATE UNIQUE INDEX ux_writer_grants_one_active
ON writer_grants(entity_id, scope)
WHERE state='active';

CREATE TABLE requests (
  request_id TEXT PRIMARY KEY,
  requester_entity_id TEXT NOT NULL REFERENCES entities(entity_id),
  target_entity_id TEXT NOT NULL REFERENCES entities(entity_id),
  requested_outcome TEXT NOT NULL,
  scope TEXT NOT NULL,
  state TEXT NOT NULL,
  row_version INTEGER NOT NULL DEFAULT 1,
  idempotency_key TEXT NOT NULL,
  UNIQUE(requester_entity_id, idempotency_key)
);

CREATE TABLE tasks (
  task_id TEXT PRIMARY KEY,
  owner_entity_id TEXT NOT NULL REFERENCES entities(entity_id),
  source_entity_id TEXT REFERENCES entities(entity_id),
  origin_request_id TEXT NOT NULL REFERENCES requests(request_id),
  task_state TEXT NOT NULL,
  terminal_criterion TEXT NOT NULL,
  required_acceptance INTEGER NOT NULL CHECK (required_acceptance IN (0,1)),
  result_artifact_id TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  idempotency_key TEXT NOT NULL,
  UNIQUE(owner_entity_id, idempotency_key)
);

CREATE TABLE assignments (
  assignment_id TEXT PRIMARY KEY,
  task_id TEXT NOT NULL REFERENCES tasks(task_id),
  assignee_entity_id TEXT NOT NULL REFERENCES entities(entity_id),
  assignee_instance_id TEXT REFERENCES instances(instance_id),
  assignment_state TEXT NOT NULL,
  row_version INTEGER NOT NULL DEFAULT 1,
  idempotency_key TEXT NOT NULL,
  UNIQUE(task_id, assignee_entity_id, idempotency_key)
);

CREATE TABLE artifacts (
  artifact_id TEXT PRIMARY KEY,
  source_entity_id TEXT NOT NULL REFERENCES entities(entity_id),
  task_id TEXT REFERENCES tasks(task_id),
  purpose TEXT NOT NULL,
  artifact_currentness TEXT NOT NULL,
  artifact_normative_status TEXT NOT NULL,
  authoritative INTEGER NOT NULL DEFAULT 0 CHECK (authoritative IN (0,1)),
  row_version INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE artifact_versions (
  artifact_version_id TEXT PRIMARY KEY,
  artifact_id TEXT NOT NULL REFERENCES artifacts(artifact_id),
  sha256 TEXT NOT NULL,
  size_bytes INTEGER NOT NULL,
  locator TEXT NOT NULL,
  publication_state TEXT NOT NULL,
  created_by_instance_id TEXT NOT NULL REFERENCES instances(instance_id),
  UNIQUE(artifact_id, sha256)
);

CREATE TABLE routes (
  route_id TEXT PRIMARY KEY,
  payload_type TEXT NOT NULL,
  payload_id TEXT NOT NULL,
  sender_entity_id TEXT NOT NULL REFERENCES entities(entity_id),
  recipient_entity_id TEXT NOT NULL REFERENCES entities(entity_id),
  required_artifact_version_id TEXT REFERENCES artifact_versions(artifact_version_id),
  route_state TEXT NOT NULL,
  row_version INTEGER NOT NULL DEFAULT 1,
  idempotency_key TEXT NOT NULL,
  UNIQUE(sender_entity_id, idempotency_key)
);

CREATE TABLE receipts (
  receipt_id TEXT PRIMARY KEY,
  route_id TEXT NOT NULL REFERENCES routes(route_id),
  recipient_entity_id TEXT NOT NULL REFERENCES entities(entity_id),
  received_artifact_version_id TEXT REFERENCES artifact_versions(artifact_version_id),
  received_sha256 TEXT,
  verification_result TEXT NOT NULL,
  supersedes_receipt_ref TEXT REFERENCES receipts(receipt_id),
  validity_state TEXT NOT NULL,
  idempotency_key TEXT NOT NULL,
  UNIQUE(route_id, recipient_entity_id, idempotency_key)
);

CREATE TABLE acceptances (
  acceptance_id TEXT PRIMARY KEY,
  task_id TEXT NOT NULL REFERENCES tasks(task_id),
  receipt_id TEXT NOT NULL REFERENCES receipts(receipt_id),
  accepted_by_entity_id TEXT NOT NULL REFERENCES entities(entity_id),
  authority_ref TEXT NOT NULL REFERENCES authority_refs(authority_ref),
  acceptance_state TEXT NOT NULL,
  idempotency_key TEXT NOT NULL,
  UNIQUE(task_id, idempotency_key)
);

CREATE TABLE dependencies (
  dependency_id TEXT PRIMARY KEY,
  task_id TEXT NOT NULL REFERENCES tasks(task_id),
  predicate_kind TEXT NOT NULL,
  predicate_spec TEXT NOT NULL,
  evidence_ref TEXT,
  evaluation_state TEXT NOT NULL,
  row_version INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE outbox (
  outbox_id TEXT PRIMARY KEY,
  route_id TEXT NOT NULL UNIQUE REFERENCES routes(route_id),
  dispatch_state TEXT NOT NULL,
  attempt_count INTEGER NOT NULL DEFAULT 0,
  last_failure TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  idempotency_key TEXT NOT NULL UNIQUE
);

CREATE TABLE inbox (
  inbox_id TEXT PRIMARY KEY,
  recipient_entity_id TEXT NOT NULL REFERENCES entities(entity_id),
  transport_message_id TEXT NOT NULL,
  route_id TEXT NOT NULL REFERENCES routes(route_id),
  processing_state TEXT NOT NULL,
  row_version INTEGER NOT NULL DEFAULT 1,
  UNIQUE(recipient_entity_id, transport_message_id)
);

CREATE TABLE audit_transitions (
  transition_id TEXT PRIMARY KEY,
  object_type TEXT NOT NULL,
  object_id TEXT NOT NULL,
  previous_version INTEGER,
  previous_state TEXT,
  new_version INTEGER,
  new_state TEXT,
  actor_entity_id TEXT NOT NULL,
  actor_instance_id TEXT,
  action TEXT NOT NULL,
  authority_ref_or_not_required TEXT NOT NULL,
  evidence_refs TEXT,
  result TEXT NOT NULL,
  time_value TEXT,
  time_source TEXT NOT NULL DEFAULT 'unknown',
  idempotency_key TEXT NOT NULL UNIQUE,
  prev_record_hash TEXT,
  current_record_hash TEXT
);

CREATE TABLE command_idempotency (
 operation TEXT NOT NULL,
 idempotency_key TEXT NOT NULL,
 semantic_fingerprint TEXT NOT NULL,
 result_json TEXT NOT NULL,
 PRIMARY KEY(operation,idempotency_key)
);

CREATE TABLE principals (
 principal_id TEXT PRIMARY KEY,
 principal_kind TEXT NOT NULL CHECK(principal_kind IN ('instance','operator_admin')),
 principal_ref TEXT NOT NULL,
 state TEXT NOT NULL DEFAULT 'active',
 UNIQUE(principal_kind, principal_ref)
);
CREATE TABLE credentials (
 credential_id TEXT PRIMARY KEY,
 principal_id TEXT NOT NULL REFERENCES principals(principal_id),
 token_hash TEXT NOT NULL UNIQUE,
 state TEXT NOT NULL DEFAULT 'active',
 issued_seq INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE upload_intents (
 upload_id TEXT PRIMARY KEY,
 actor_entity_id TEXT NOT NULL,
 task_id TEXT NOT NULL,
 instance_id TEXT NOT NULL,
 staging_path TEXT NOT NULL,
 state TEXT NOT NULL,
 semantic_fingerprint TEXT NOT NULL,
 idempotency_key TEXT NOT NULL,
 UNIQUE(actor_entity_id,idempotency_key)
);
CREATE TABLE sandbox_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
INSERT INTO sandbox_meta(key,value) VALUES('schema_version','1');
