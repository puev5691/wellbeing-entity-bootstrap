CREATE TABLE IF NOT EXISTS migration_history (
 version INTEGER PRIMARY KEY,
 checksum TEXT NOT NULL,
 applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
UPDATE sandbox_meta SET value='2' WHERE key='schema_version';

CREATE TABLE IF NOT EXISTS evidence_registry (
 evidence_ref TEXT PRIMARY KEY,
 issuer_kind TEXT NOT NULL CHECK(issuer_kind IN ('operator','approved_process')),
 issuer_ref TEXT NOT NULL,
 locator TEXT NOT NULL,
 sha256 TEXT NOT NULL,
 state TEXT NOT NULL DEFAULT 'verified'
);
CREATE TABLE IF NOT EXISTS bootstrap_state (
 singleton INTEGER PRIMARY KEY CHECK(singleton=1),
 initialized INTEGER NOT NULL DEFAULT 0 CHECK(initialized IN (0,1))
);
INSERT OR IGNORE INTO bootstrap_state(singleton,initialized) VALUES(1,0);
