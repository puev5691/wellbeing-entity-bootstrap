from __future__ import annotations
import hashlib, json, os, sqlite3, uuid
from pathlib import Path

FAILURES = {
    "unknown","out_of_role","missing_authority","approval_required","dependency_unsatisfied",
    "artifact_missing","version_mismatch","locator_unavailable","receipt_missing","conflict",
    "duplicate","stale_instance","writer_conflict","lease_expired","lock_stale",
    "file_field_unavailable","coordination_field_unavailable"
}

class PilotError(RuntimeError):
    def __init__(self, code: str, message: str = "", subcode: str | None = None):
        super().__init__(message or code)
        self.code, self.subcode = code, subcode


def oid(kind: str) -> str:
    return f"{kind}:{uuid.uuid4()}"

class FileAdapter:
    def __init__(self, root: Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def digest(data: bytes) -> str:
        return hashlib.sha256(data).hexdigest()

    def publish(self, data: bytes, name: str | None = None) -> tuple[str, str, int]:
        sha = self.digest(data)
        name = name or sha
        path = self.root / name
        path.write_bytes(data)
        reread = path.read_bytes()
        if self.digest(reread) != sha:
            raise PilotError("version_mismatch", "post-write verification failed")
        return str(path), sha, len(data)

    def verify(self, locator: str, required_sha: str) -> tuple[str, str | None, bytes | None]:
        path = Path(locator)
        try:
            if not path.exists():
                return "artifact_missing", None, None
            data = path.read_bytes()
        except OSError:
            return "locator_unavailable", None, None
        got = self.digest(data)
        if got != required_sha:
            return "version_mismatch", got, data
        return "verified", got, data

class CoordinationService:
    def __init__(self, db_path: Path, schema_path: Path, file_root: Path):
        self.db_path, self.schema_path = Path(db_path), Path(schema_path)
        self.files = FileAdapter(file_root)
        self._init_db()

    def connect(self):
        c = sqlite3.connect(self.db_path)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA foreign_keys=ON")
        return c

    def _init_db(self):
        first = not self.db_path.exists()
        with self.connect() as c:
            if first:
                c.executescript(self.schema_path.read_text(encoding="utf-8"))

    def _audit(self, c, *, obj_type, obj_id, prev_v, prev_s, new_v, new_s,
               actor_entity, actor_instance, action, authority, evidence, result, ikey):
        values=(oid("tr"),obj_type,obj_id,prev_v,prev_s,new_v,new_s,actor_entity,actor_instance,
                action,authority,json.dumps(evidence or []),result,ikey)
        try:
            c.execute("""INSERT INTO audit_transitions
              (transition_id,object_type,object_id,previous_version,previous_state,new_version,new_state,
               actor_entity_id,actor_instance_id,action,authority_ref_or_not_required,evidence_refs,result,time_value,time_source,idempotency_key)
              VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,NULL,'unknown',?)""", values)
            return "created"
        except sqlite3.IntegrityError as e:
            existing=c.execute("""SELECT object_type,object_id,previous_version,previous_state,new_version,new_state,
                         actor_entity_id,actor_instance_id,action,authority_ref_or_not_required,evidence_refs,result
                         FROM audit_transitions WHERE idempotency_key=?""",(ikey,)).fetchone()
            expected=(obj_type,obj_id,prev_v,prev_s,new_v,new_s,actor_entity,actor_instance,action,authority,json.dumps(evidence or []),result)
            if existing and tuple(existing)==expected:
                return "duplicate"
            raise PilotError("conflict", "audit_integrity_failure", subcode="audit_integrity_failure") from e

    def register_entity(self, entity_id, display_name=None):
        with self.connect() as c:
            c.execute("INSERT OR IGNORE INTO entities(entity_id,display_name) VALUES (?,?)", (entity_id,display_name))
        return entity_id

    def register_instance(self, entity_id, work_mode="worker", lifecycle="active", instance_id=None):
        instance_id = instance_id or f"inst:{entity_id.split(':',1)[-1]}:{uuid.uuid4()}"
        with self.connect() as c:
            c.execute("INSERT INTO instances(instance_id,entity_id,lifecycle,work_mode) VALUES (?,?,?,?)",
                      (instance_id,entity_id,lifecycle,work_mode))
        return instance_id

    def add_authority(self, holder, issuer_kind, issuer_ref, action, scope, evidence_version="pilot-fixture", ref=None):
        ref = ref or oid("auth")
        with self.connect() as c:
            c.execute("""INSERT INTO authority_refs(authority_ref,holder_entity_id,issuer_kind,issuer_ref,action,object_scope,evidence_version)
                         VALUES (?,?,?,?,?,?,?)""", (ref,holder,issuer_kind,issuer_ref,action,scope,evidence_version))
        return ref

    def authority(self, c, actor_entity, action, object_scope):
        rows = c.execute("SELECT * FROM authority_refs WHERE holder_entity_id=? AND action=? AND state='active'", (actor_entity,action)).fetchall()
        for r in rows:
            if r["object_scope"] in (object_scope, "*") or (r["object_scope"].endswith(":*") and object_scope.startswith(r["object_scope"][:-1])):
                return r["authority_ref"]
        raise PilotError("missing_authority", f"{actor_entity} lacks {action} on {object_scope}")

    def authority_ref(self, c, authority_ref, actor_entity, action, object_scope):
        r=c.execute("SELECT * FROM authority_refs WHERE authority_ref=? AND state='active'",(authority_ref,)).fetchone()
        if not r or r['holder_entity_id']!=actor_entity or r['action']!=action:
            raise PilotError('missing_authority','authority_ref does not match holder/action',subcode='authority_ref_mismatch')
        scope=r['object_scope']
        if not (scope in (object_scope,'*') or (scope.endswith(':*') and object_scope.startswith(scope[:-1]))):
            raise PilotError('missing_authority','authority_ref does not cover target scope',subcode='authority_ref_mismatch')
        return authority_ref

    @staticmethod
    def _semantic_fingerprint(data):
        return hashlib.sha256(json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")).hexdigest()

    def _idempotent_existing(self, c, table, id_col, key_where, key_values, semantic):
        row=c.execute(f"SELECT {id_col} FROM {table} WHERE {key_where}", key_values).fetchone()
        if not row:
            return None
        marker=c.execute("SELECT evidence_refs FROM audit_transitions WHERE object_type=? AND object_id=? AND action LIKE ? ORDER BY rowid LIMIT 1",
                         (table[:-1] if table.endswith("s") else table,row[0],"%.create" if table in ("requests","tasks") else "%")).fetchone()
        fp=self._semantic_fingerprint(semantic)
        if marker:
            try:
                ev=json.loads(marker[0] or "[]")
            except Exception:
                ev=[]
            stored=next((x.split("semantic:",1)[1] for x in ev if isinstance(x,str) and x.startswith("semantic:")),None)
            if stored == fp:
                return row[0]
        raise PilotError("conflict", "idempotency key reused with different semantic input", subcode="idempotency_semantic_mismatch")

    def _command_existing(self, c, operation, key, semantic):
        fp=self._semantic_fingerprint(semantic)
        row=c.execute("SELECT semantic_fingerprint,result_json FROM command_idempotency WHERE operation=? AND idempotency_key=?",(operation,key)).fetchone()
        if not row: return None
        if row["semantic_fingerprint"] != fp:
            raise PilotError("conflict","idempotency key reused with different semantic input",subcode="idempotency_semantic_mismatch")
        return json.loads(row["result_json"])

    def _command_store(self, c, operation, key, semantic, result):
        c.execute("INSERT INTO command_idempotency(operation,idempotency_key,semantic_fingerprint,result_json) VALUES (?,?,?,?)",
                  (operation,key,self._semantic_fingerprint(semantic),json.dumps(result,sort_keys=True,separators=(",",":"))))

    @staticmethod
    def _audit_key(operation, key, suffix=""):
        return f"audit:{operation}:{key}" + (f":{suffix}" if suffix else "")

    def _failure_audit(self, **kw):
        # Business transaction has already rolled back; persist only rejected-action evidence.
        with self.connect() as ac:
            return self._audit(ac, **kw)

    def create_request(self, requester, target, outcome, scope, idempotency_key):
        semantic={"requester":requester,"target":target,"outcome":outcome,"scope":scope}
        with self.connect() as c:
            oldcmd=self._command_existing(c,"request.create",idempotency_key,semantic)
            if oldcmd is not None: return oldcmd["request_id"]
            old=c.execute("SELECT request_id FROM requests WHERE requester_entity_id=? AND idempotency_key=?",(requester,idempotency_key)).fetchone()
            if old:
                audit=c.execute("SELECT evidence_refs FROM audit_transitions WHERE object_type='request' AND object_id=? AND action='request.create'",(old[0],)).fetchone()
                fp=self._semantic_fingerprint(semantic); ev=json.loads(audit[0] or '[]') if audit else []
                if f"semantic:{fp}" in ev: return old[0]
                raise PilotError("conflict",subcode="idempotency_semantic_mismatch")
            rid=oid("request")
            c.execute("INSERT INTO requests VALUES (?,?,?,?,?,'created',1,?)",(rid,requester,target,outcome,scope,idempotency_key))
            self._audit(c,obj_type="request",obj_id=rid,prev_v=None,prev_s=None,new_v=1,new_s="created",actor_entity=requester,actor_instance=None,action="request.create",authority="not_required",evidence=[f"semantic:{self._semantic_fingerprint(semantic)}"],result="allowed",ikey=self._audit_key("request.create",idempotency_key))
            self._command_store(c,"request.create",idempotency_key,semantic,{"request_id":rid})
            return rid

    def create_task(self, owner, source, origin_request_id, criterion, required_acceptance, actor_entity, idempotency_key):
        semantic={"owner":owner,"source":source,"origin_request_id":origin_request_id,"criterion":criterion,"required_acceptance":bool(required_acceptance)}
        with self.connect() as c:
            oldcmd=self._command_existing(c,"task.create",idempotency_key,semantic)
            if oldcmd is not None: return oldcmd["task_id"]
            old=c.execute("SELECT task_id FROM tasks WHERE owner_entity_id=? AND idempotency_key=?",(owner,idempotency_key)).fetchone()
            if old:
                audit=c.execute("SELECT evidence_refs FROM audit_transitions WHERE object_type='task' AND object_id=? AND action='task.create'",(old[0],)).fetchone()
                fp=self._semantic_fingerprint(semantic); ev=json.loads(audit[0] or '[]') if audit else []
                if f"semantic:{fp}" in ev: return old[0]
                raise PilotError("conflict",subcode="idempotency_semantic_mismatch")
            req=c.execute("SELECT * FROM requests WHERE request_id=?",(origin_request_id,)).fetchone()
            if not req: raise PilotError("unknown","origin request missing")
            if req['requester_entity_id']!=source or req['target_entity_id']!=owner:
                raise PilotError("conflict","origin request does not match task source/owner",subcode="origin_request_mismatch")
            auth=self.authority(c,actor_entity,"task.create",f"entity:{owner}")
            tid=oid("task")
            c.execute("""INSERT INTO tasks(task_id,owner_entity_id,source_entity_id,origin_request_id,task_state,terminal_criterion,required_acceptance,row_version,idempotency_key) VALUES (?,?,?,?, 'created',?,?,1,?)""",(tid,owner,source,origin_request_id,criterion,int(required_acceptance),idempotency_key))
            self._audit(c,obj_type="task",obj_id=tid,prev_v=None,prev_s=None,new_v=1,new_s="created",actor_entity=actor_entity,actor_instance=None,action="task.create",authority=auth,evidence=[origin_request_id,f"semantic:{self._semantic_fingerprint(semantic)}"],result="allowed",ikey=self._audit_key("task.create",idempotency_key))
            self._command_store(c,"task.create",idempotency_key,semantic,{"task_id":tid})
            return tid

    def assign(self, task_id, assignee_entity, assignee_instance, actor_entity, idempotency_key):
        semantic={"task_id":task_id,"assignee_entity":assignee_entity,"assignee_instance":assignee_instance,"actor_entity":actor_entity}
        with self.connect() as c:
            oldcmd=self._command_existing(c,"assignment.create",idempotency_key,semantic)
            if oldcmd is not None: return oldcmd["assignment_id"]
            old=c.execute("SELECT assignment_id FROM assignments WHERE task_id=? AND assignee_entity_id=? AND idempotency_key=?",(task_id,assignee_entity,idempotency_key)).fetchone()
            if old: raise PilotError("conflict",subcode="idempotency_semantic_mismatch")
            if assignee_instance:
                inst=c.execute("SELECT entity_id,lifecycle FROM instances WHERE instance_id=?",(assignee_instance,)).fetchone()
                if not inst or inst['entity_id']!=assignee_entity:
                    raise PilotError('out_of_role','assignee instance does not belong to assignee entity',subcode='assignee_instance_mismatch')
                if inst['lifecycle']!='active':
                    raise PilotError('stale_instance','assignee instance is not active')
            task=c.execute("SELECT * FROM tasks WHERE task_id=?",(task_id,)).fetchone()
            if not task: raise PilotError('unknown','task missing')
            if task['task_state']!='created':
                raise PilotError('conflict','task is not assignable',subcode='task_not_assignable')
            if assignee_entity!=task['owner_entity_id']:
                raise PilotError('out_of_role','pilot task assignee must equal task owner',subcode='pilot_foreign_assignee')
            auth=self.authority(c,actor_entity,"task.assign",f"task:{task_id}")
            aid=oid("assignment")
            c.execute("INSERT INTO assignments VALUES (?,?,?,?, 'assigned',1,?)",(aid,task_id,assignee_entity,assignee_instance,idempotency_key))
            self._audit(c,obj_type="assignment",obj_id=aid,prev_v=None,prev_s=None,new_v=1,new_s="assigned",actor_entity=actor_entity,actor_instance=None,action="task.assign",authority=auth,evidence=[task_id],result="allowed",ikey=self._audit_key("assignment.create",idempotency_key))
            self._command_store(c,"assignment.create",idempotency_key,semantic,{"assignment_id":aid})
            return aid

    def accept_assignment(self, assignment_id, actor_entity, actor_instance, idempotency_key):
        semantic={"assignment_id":assignment_id,"actor_entity":actor_entity,"actor_instance":actor_instance}
        with self.connect() as c:
            oldcmd=self._command_existing(c,"assignment.accept",idempotency_key,semantic)
            if oldcmd is not None: return oldcmd.get("result")
            a=c.execute("SELECT * FROM assignments WHERE assignment_id=?",(assignment_id,)).fetchone()
            if not a: raise PilotError("unknown", "assignment missing")
            if a["assignee_entity_id"]!=actor_entity or (a["assignee_instance_id"] and a["assignee_instance_id"]!=actor_instance):
                raise PilotError("out_of_role", "assignment actor mismatch")
            inst=c.execute("SELECT entity_id,lifecycle FROM instances WHERE instance_id=?",(actor_instance,)).fetchone()
            if not inst or inst["entity_id"]!=actor_entity or inst["lifecycle"]!="active":
                raise PilotError("stale_instance", "actor instance is not active for assignee entity")
            blockers=c.execute("SELECT COUNT(*) FROM dependencies WHERE task_id=? AND evaluation_state!='satisfied'",(a['task_id'],)).fetchone()[0]
            if blockers: raise PilotError("dependency_unsatisfied")
            auth=self.authority(c,actor_entity,"assignment.accept",f"task:{a['task_id']}")
            v=a["row_version"]
            n=c.execute("UPDATE assignments SET assignment_state='accepted',row_version=row_version+1 WHERE assignment_id=? AND row_version=? AND assignment_state='assigned'",(assignment_id,v)).rowcount
            if n!=1: raise PilotError("conflict")
            task=c.execute("SELECT * FROM tasks WHERE task_id=?",(a['task_id'],)).fetchone()
            if task['task_state'] not in ('created','routed','delivered','received','accepted_for_work'):
                raise PilotError("conflict", "task is not pre-active")
            tv=task['row_version']
            n=c.execute("UPDATE tasks SET task_state='active',row_version=row_version+1 WHERE task_id=? AND row_version=?",(a['task_id'],tv)).rowcount
            if n!=1: raise PilotError("conflict")
            self._audit(c,obj_type="assignment",obj_id=assignment_id,prev_v=v,prev_s=a["assignment_state"],new_v=v+1,new_s="accepted",actor_entity=actor_entity,actor_instance=actor_instance,action="assignment.accept",authority=auth,evidence=[],result="allowed",ikey=self._audit_key("assignment.accept",idempotency_key))
            self._audit(c,obj_type="task",obj_id=a['task_id'],prev_v=tv,prev_s=task['task_state'],new_v=tv+1,new_s="active",actor_entity=actor_entity,actor_instance=actor_instance,action="task.activate",authority=auth,evidence=[assignment_id],result="allowed",ikey=self._audit_key("assignment.accept",idempotency_key,"task-active"))
            self._command_store(c,"assignment.accept",idempotency_key,semantic,{"result":"accepted"})
            return "accepted"

    def grant_writer(self, entity_id, instance_id, scope, actor_entity, authority_ref, evidence_ref, grant_id=None, idempotency_key=None):
        idempotency_key=idempotency_key or grant_id or oid("cmd")
        semantic={"entity_id":entity_id,"instance_id":instance_id,"scope":scope,"actor_entity":actor_entity,"authority_ref":authority_ref,"evidence_ref":evidence_ref}
        with self.connect() as c:
            oldcmd=self._command_existing(c,"writer.grant",idempotency_key,semantic)
            if oldcmd is not None: return oldcmd["grant_id"],oldcmd["generation"]
            grant_id=grant_id or oid("wg")
            exact=self.authority_ref(c,authority_ref,actor_entity,"writer.grant",scope)
            inst=c.execute("SELECT entity_id,lifecycle FROM instances WHERE instance_id=?",(instance_id,)).fetchone()
            if not inst or inst['entity_id']!=entity_id or inst['lifecycle']!='active':
                raise PilotError("stale_instance")
            prev=c.execute("SELECT COALESCE(MAX(generation),0) FROM writer_grants WHERE entity_id=? AND scope=?",(entity_id,scope)).fetchone()[0]
            gen=prev+1
            try:
                c.execute("INSERT INTO writer_grants VALUES (?,?,?,?,?,?,'active',?,1)",(grant_id,entity_id,instance_id,authority_ref,scope,gen,evidence_ref))
            except sqlite3.IntegrityError as e:
                raise PilotError("writer_conflict", "competing active writer grant") from e
            c.execute("UPDATE instances SET writer_grant_ref=?,writer_generation=?,writer_scope=?,row_version=row_version+1 WHERE instance_id=?",(grant_id,gen,scope,instance_id))
            self._audit(c,obj_type="writer_grant",obj_id=grant_id,prev_v=None,prev_s=None,new_v=1,new_s="active",actor_entity=actor_entity,actor_instance=None,action="writer.grant",authority=exact,evidence=[evidence_ref],result="allowed",ikey=self._audit_key("writer.grant",idempotency_key))
            self._command_store(c,"writer.grant",idempotency_key,semantic,{"grant_id":grant_id,"generation":gen})
            return grant_id,gen

    def publish_artifact(self, task_id, source_entity, instance_id, data: bytes, actor_entity, idempotency_key, currentness="candidate"):
        # Pilot invariant: artifact.publish creates candidates only. Current-state is a
        # separate authoritative transition guarded by authority + writer fencing.
        if currentness != "candidate":
            raise PilotError("conflict", "artifact.publish only permits candidate currentness", subcode="invalid_artifact_currentness")
        semantic={"task_id":task_id,"source_entity":source_entity,"instance_id":instance_id,"data_sha256":self.files.digest(data),"actor_entity":actor_entity,"currentness":currentness}
        with self.connect() as c:
            oldcmd=self._command_existing(c,"artifact.publish",idempotency_key,semantic)
            if oldcmd is not None: return oldcmd["artifact_id"],oldcmd["artifact_version_id"]
            task=c.execute("SELECT * FROM tasks WHERE task_id=?",(task_id,)).fetchone()
            if not task: raise PilotError("unknown","task missing")
            if task['task_state']!='active': raise PilotError("conflict","task result publication requires active task",subcode="task_not_active")
            inst=c.execute("SELECT * FROM instances WHERE instance_id=?",(instance_id,)).fetchone()
            if not inst or inst['lifecycle']!='active': raise PilotError("stale_instance")
            if inst['entity_id']!=actor_entity or source_entity!=actor_entity or source_entity!=task['owner_entity_id']:
                raise PilotError("out_of_role","artifact producer provenance mismatch",subcode="artifact_producer_mismatch")
            accepted=c.execute("""SELECT * FROM assignments WHERE task_id=? AND assignment_state='accepted' ORDER BY rowid DESC LIMIT 1""",(task_id,)).fetchone()
            if not accepted:
                raise PilotError('out_of_role','task result requires accepted assignment',subcode='accepted_assignment_missing')
            if accepted['assignee_entity_id']!=actor_entity or (accepted['assignee_instance_id'] and accepted['assignee_instance_id']!=instance_id):
                raise PilotError('out_of_role','result producer does not match accepted assignment',subcode='assignment_producer_mismatch')
            auth=self.authority(c,actor_entity,"artifact.publish",f"task:{task_id}")
            artifact_id=oid("artifact"); locator,sha,size=self.files.publish(data); version_id=oid("av")
            c.execute("INSERT INTO artifacts VALUES (?,?,?,?,?,?,0,1)",(artifact_id,source_entity,task_id,"task-result",currentness,"not_normative"))
            c.execute("INSERT INTO artifact_versions VALUES (?,?,?,?,?,'published',?)",(version_id,artifact_id,sha,size,locator,instance_id))
            self._audit(c,obj_type="artifact",obj_id=artifact_id,prev_v=None,prev_s=None,new_v=1,new_s=currentness,actor_entity=actor_entity,actor_instance=instance_id,action="artifact.publish",authority=auth,evidence=[version_id],result="allowed",ikey=self._audit_key("artifact.publish",idempotency_key))
            self._command_store(c,"artifact.publish",idempotency_key,semantic,{"artifact_id":artifact_id,"artifact_version_id":version_id})
            return artifact_id,version_id

    def authoritative_commit(self, artifact_id, actor_entity, actor_instance, writer_grant_ref, writer_generation, expected_version, idempotency_key):
        semantic={"artifact_id":artifact_id,"actor_entity":actor_entity,"actor_instance":actor_instance,"writer_grant_ref":writer_grant_ref,"writer_generation":writer_generation,"expected_version":expected_version}
        failure=None
        try:
            with self.connect() as c:
                oldcmd=self._command_existing(c,"artifact.authoritative_commit",idempotency_key,semantic)
                if oldcmd is not None: return oldcmd.get("result","current")
                art=c.execute("SELECT * FROM artifacts WHERE artifact_id=?",(artifact_id,)).fetchone()
                if not art: raise PilotError("artifact_missing")
                auth=self.authority(c,actor_entity,"artifact.authoritative_commit",f"artifact:{artifact_id}")
                inst=c.execute("SELECT * FROM instances WHERE instance_id=?",(actor_instance,)).fetchone()
                if not inst or inst['lifecycle'] in ('stale','retired'): raise PilotError('stale_instance')
                if inst['entity_id']!=actor_entity or art['source_entity_id']!=actor_entity: raise PilotError('writer_conflict','writer entity mismatch')
                required_scope=f"entity-current-state:{art['source_entity_id']}"
                grant=c.execute("SELECT * FROM writer_grants WHERE writer_grant_id=? AND state='active'",(writer_grant_ref,)).fetchone() if writer_grant_ref else None
                valid=grant and grant['instance_id']==actor_instance and grant['entity_id']==actor_entity and grant['generation']==writer_generation and grant['scope']==required_scope
                if not valid:
                    failure=dict(obj_type='artifact',obj_id=artifact_id,prev_v=expected_version,prev_s=art['artifact_currentness'],new_v=expected_version,new_s=art['artifact_currentness'],actor_entity=actor_entity,actor_instance=actor_instance,action='artifact.authoritative_commit',authority=auth,evidence=[writer_grant_ref] if writer_grant_ref else [],result='writer_conflict',ikey=self._audit_key('artifact.authoritative_commit',idempotency_key))
                    raise PilotError('writer_conflict',subcode='writer_grant_missing' if not grant else 'writer_scope_or_identity_mismatch')
                if art['row_version']!=expected_version: raise PilotError('conflict')
                n=c.execute("UPDATE artifacts SET artifact_currentness='current',authoritative=1,row_version=row_version+1 WHERE artifact_id=? AND row_version=?",(artifact_id,expected_version)).rowcount
                if n!=1: raise PilotError('conflict')
                self._audit(c,obj_type='artifact',obj_id=artifact_id,prev_v=expected_version,prev_s=art['artifact_currentness'],new_v=expected_version+1,new_s='current',actor_entity=actor_entity,actor_instance=actor_instance,action='artifact.authoritative_commit',authority=auth,evidence=[writer_grant_ref],result='allowed',ikey=self._audit_key('artifact.authoritative_commit',idempotency_key))
                self._command_store(c,'artifact.authoritative_commit',idempotency_key,semantic,{'result':'current'})
                return 'current'
        except PilotError:
            if failure: self._failure_audit(**failure)
            raise

    def create_route(self, payload_type, payload_id, sender, recipient, idempotency_key):
        semantic={"payload_type":payload_type,"payload_id":payload_id,"sender":sender,"recipient":recipient}
        with self.connect() as c:
            oldcmd=self._command_existing(c,"route.create",idempotency_key,semantic)
            if oldcmd is not None: return oldcmd["route_id"]
            old=c.execute("SELECT route_id FROM routes WHERE sender_entity_id=? AND idempotency_key=?",(sender,idempotency_key)).fetchone()
            if old:
                audit=c.execute("SELECT evidence_refs FROM audit_transitions WHERE object_type='route' AND object_id=? AND action='route.dispatch'",(old[0],)).fetchone()
                fp=self._semantic_fingerprint(semantic); ev=json.loads(audit[0] or '[]') if audit else []
                if f"semantic:{fp}" in ev: return old[0]
                raise PilotError("conflict",subcode="idempotency_semantic_mismatch")
            auth=self.authority(c,sender,"route.dispatch",f"entity:{recipient}"); required=None
            if payload_type=="artifact_version":
                payload=c.execute("""SELECT a.source_entity_id FROM artifact_versions av JOIN artifacts a ON a.artifact_id=av.artifact_id WHERE av.artifact_version_id=?""",(payload_id,)).fetchone()
                if not payload: raise PilotError("unknown","dangling payload")
                if payload['source_entity_id']!=sender:
                    raise PilotError('missing_authority','sender cannot dispatch foreign artifact',subcode='foreign_artifact_dispatch')
                required=payload_id
            elif payload_type=="request":
                req=c.execute("SELECT requester_entity_id,target_entity_id FROM requests WHERE request_id=?",(payload_id,)).fetchone()
                if not req: raise PilotError("unknown","dangling payload")
                if req['requester_entity_id']!=sender or req['target_entity_id']!=recipient:
                    raise PilotError('conflict','request route provenance/direction mismatch',subcode='request_route_mismatch')
            else: raise PilotError("unknown","unsupported payload type")
            rid=oid("route"); outid=oid("outbox")
            c.execute("INSERT INTO routes VALUES (?,?,?,?,?,?, 'created',1,?)",(rid,payload_type,payload_id,sender,recipient,required,idempotency_key))
            c.execute("INSERT INTO outbox VALUES (?,?, 'pending',0,NULL,1,?)",(outid,rid,f"outbox:{idempotency_key}"))
            self._audit(c,obj_type="route",obj_id=rid,prev_v=None,prev_s=None,new_v=1,new_s="created",actor_entity=sender,actor_instance=None,action="route.dispatch",authority=auth,evidence=[payload_id,f"semantic:{self._semantic_fingerprint(semantic)}"],result="allowed",ikey=self._audit_key("route.create",idempotency_key))
            self._command_store(c,"route.create",idempotency_key,semantic,{"route_id":rid})
            return rid

    def dispatch_route(self, route_id, transport_message_id=None):
        transport_message_id=transport_message_id or oid("tm")
        with self.connect() as c:
            r=c.execute("SELECT * FROM routes WHERE route_id=?",(route_id,)).fetchone()
            if not r: raise PilotError("unknown","route missing")
            if r['route_state']=='received': return transport_message_id
            if r['route_state'] not in ('created','delivered'): raise PilotError("conflict",subcode="invalid_route_state")
            c.execute("UPDATE outbox SET dispatch_state='dispatched',attempt_count=attempt_count+1,row_version=row_version+1 WHERE route_id=?",(route_id,))
            transitioned=False
            if r['route_state']=='created':
                n=c.execute("UPDATE routes SET route_state='delivered',row_version=row_version+1 WHERE route_id=? AND row_version=? AND route_state='created'",(route_id,r['row_version'])).rowcount
                if n!=1: raise PilotError('conflict','route dispatch CAS failed')
                creation=c.execute("SELECT authority_ref_or_not_required FROM audit_transitions WHERE object_type='route' AND object_id=? AND action='route.dispatch' ORDER BY rowid LIMIT 1",(route_id,)).fetchone()
                auth=creation[0] if creation else 'not_required'
                self._audit(c,obj_type='route',obj_id=route_id,prev_v=r['row_version'],prev_s='created',new_v=r['row_version']+1,new_s='delivered',actor_entity=r['sender_entity_id'],actor_instance=None,action='route.deliver',authority=auth,evidence=[transport_message_id],result='allowed',ikey=f"audit:route.deliver:{route_id}:{transport_message_id}")
                transitioned=True
            try:
                c.execute("INSERT INTO inbox VALUES (?,?,?,?,?,1)",(oid("inbox"),r['recipient_entity_id'],transport_message_id,route_id,"pending"))
            except sqlite3.IntegrityError as e:
                existing=c.execute("SELECT route_id FROM inbox WHERE recipient_entity_id=? AND transport_message_id=?",(r['recipient_entity_id'],transport_message_id)).fetchone()
                if existing and existing['route_id']==route_id: return transport_message_id
                raise PilotError("conflict","inbox_integrity_failure",subcode="inbox_integrity_failure") from e
            return transport_message_id

    def receive_route(self, route_id, recipient_entity, idempotency_key, locator_override=None):
        semantic={"route_id":route_id,"recipient_entity":recipient_entity,"locator_override":locator_override}
        failure=None
        try:
            with self.connect() as c:
                oldcmd=self._command_existing(c,"receipt.register",idempotency_key,semantic)
                if oldcmd is not None: return oldcmd
                r=c.execute("SELECT * FROM routes WHERE route_id=?",(route_id,)).fetchone()
                if not r or r['recipient_entity_id']!=recipient_entity: raise PilotError("unknown")
                if r['route_state']!='delivered': raise PilotError("conflict","receipt before dispatch/delivery",subcode="route_not_delivered")
                if r['payload_type']!='artifact_version': raise PilotError("unknown")
                av=c.execute("SELECT * FROM artifact_versions WHERE artifact_version_id=?",(r['required_artifact_version_id'],)).fetchone(); locator=locator_override or av['locator']
                verification,gotsha,_=self.files.verify(locator,av['sha256'])
                if verification!='verified':
                    failure=dict(obj_type='route',obj_id=route_id,prev_v=r['row_version'],prev_s=r['route_state'],new_v=r['row_version'],new_s=r['route_state'],actor_entity=recipient_entity,actor_instance=None,action='receipt.register',authority='not_required',evidence=[locator],result=verification,ikey=self._audit_key('receipt.register.failure',idempotency_key,oid('attempt')))
                    raise PilotError(verification)
                recid=oid('receipt')
                c.execute("INSERT INTO receipts VALUES (?,?,?,?,?,'verified',NULL,'valid',?)",(recid,route_id,recipient_entity,av['artifact_version_id'],gotsha,idempotency_key))
                c.execute("UPDATE routes SET route_state='received',row_version=row_version+1 WHERE route_id=? AND route_state='delivered'",(route_id,))
                self._audit(c,obj_type='receipt',obj_id=recid,prev_v=None,prev_s=None,new_v=1,new_s='valid',actor_entity=recipient_entity,actor_instance=None,action='receipt.register',authority='not_required',evidence=[route_id,av['artifact_version_id']],result='allowed',ikey=self._audit_key('receipt.register.success',idempotency_key))
                self._audit(c,obj_type='route',obj_id=route_id,prev_v=r['row_version'],prev_s='delivered',new_v=r['row_version']+1,new_s='received',actor_entity=recipient_entity,actor_instance=None,action='route.receive',authority='not_required',evidence=[recid,av['artifact_version_id']],result='allowed',ikey=self._audit_key('route.receive',idempotency_key))
                result={'receipt_id':recid,'verification_result':'verified'}
                self._command_store(c,'receipt.register',idempotency_key,semantic,result)
                return result
        except PilotError:
            if failure: self._failure_audit(**failure)
            raise

    def accept_and_close(self, task_id, receipt_id, actor_entity, idempotency_key):
        semantic={"task_id":task_id,"receipt_id":receipt_id,"actor_entity":actor_entity}
        with self.connect() as c:
            oldcmd=self._command_existing(c,"result.accept",idempotency_key,semantic)
            if oldcmd is not None: return oldcmd["acceptance_id"]
            task=c.execute("SELECT * FROM tasks WHERE task_id=?",(task_id,)).fetchone()
            if not task: raise PilotError("unknown", "task missing")
            if task['task_state']!='active': raise PilotError('conflict','task close requires active state',subcode='task_not_active')
            rec=c.execute("SELECT * FROM receipts WHERE receipt_id=? AND validity_state='valid' AND verification_result='verified'",(receipt_id,)).fetchone()
            if not rec: raise PilotError("receipt_missing")
            chain=c.execute("""SELECT r.required_artifact_version_id,av.artifact_id,a.task_id
                FROM routes r JOIN artifact_versions av ON av.artifact_version_id=r.required_artifact_version_id
                JOIN artifacts a ON a.artifact_id=av.artifact_id
                WHERE r.route_id=? AND r.payload_type='artifact_version' AND r.payload_id=av.artifact_version_id""",(rec['route_id'],)).fetchone()
            if not chain or chain['task_id']!=task_id or rec['received_artifact_version_id']!=chain['required_artifact_version_id']:
                raise PilotError("receipt_missing", "invalid_receipt: receipt is not evidence for this task", subcode="invalid_receipt")
            auth=self.authority(c,actor_entity,"result.accept",f"task:{task_id}")
            aid=oid("acceptance")
            c.execute("INSERT INTO acceptances VALUES (?,?,?,?,?,'accepted',?)",(aid,task_id,receipt_id,actor_entity,auth,idempotency_key))
            if task["terminal_criterion"]=="accepted-result" and task["required_acceptance"]:
                n=c.execute("UPDATE tasks SET task_state='closed',result_artifact_id=?,row_version=row_version+1 WHERE task_id=? AND row_version=?",(chain['artifact_id'],task_id,task["row_version"])).rowcount
                if n!=1: raise PilotError("conflict")
                self._audit(c,obj_type="task",obj_id=task_id,prev_v=task["row_version"],prev_s=task["task_state"],new_v=task["row_version"]+1,new_s="closed",actor_entity=actor_entity,actor_instance=None,action="task.close",authority=auth,evidence=[receipt_id,aid],result="allowed",ikey=self._audit_key("result.accept",idempotency_key,"task-close"))
            self._audit(c,obj_type="acceptance",obj_id=aid,prev_v=None,prev_s=None,new_v=1,new_s="accepted",actor_entity=actor_entity,actor_instance=None,action="result.accept",authority=auth,evidence=[receipt_id],result="allowed",ikey=self._audit_key("result.accept",idempotency_key))
            self._command_store(c,"result.accept",idempotency_key,semantic,{"acceptance_id":aid})
            return aid

    def recovery_projection(self, entity_id):
        with self.connect() as c:
            inst=[dict(r) for r in c.execute("SELECT instance_id,lifecycle,work_mode,writer_grant_ref,writer_generation,writer_scope FROM instances WHERE entity_id=? AND lifecycle='active'",(entity_id,))]
            grants=[dict(r) for r in c.execute("SELECT writer_grant_id,instance_id,scope,generation FROM writer_grants WHERE entity_id=? AND state='active'",(entity_id,))]
            tasks=[dict(r) for r in c.execute("SELECT task_id,task_state,row_version FROM tasks WHERE owner_entity_id=? AND task_state!='closed'",(entity_id,))]
            arts=[dict(r) for r in c.execute("""SELECT a.artifact_id,v.artifact_version_id,v.sha256,v.locator FROM artifacts a JOIN artifact_versions v ON v.artifact_id=a.artifact_id WHERE a.source_entity_id=?""",(entity_id,))]
            routes=[dict(r) for r in c.execute("SELECT route_id,route_state FROM routes WHERE (sender_entity_id=? OR recipient_entity_id=?) AND route_state!='received'",(entity_id,entity_id))]
            deps=[dict(r) for r in c.execute("""SELECT d.dependency_id,d.task_id,d.predicate_kind,d.predicate_spec,d.evaluation_state,d.evidence_ref FROM dependencies d JOIN tasks t ON t.task_id=d.task_id WHERE t.owner_entity_id=? AND d.evaluation_state!='satisfied'""",(entity_id,))]
            return {"entity":{"entity_id":entity_id},"instances":{"active":inst},"writer_grants":grants,"unfinished_tasks":tasks,"significant_artifacts":arts,"pending_routes":routes,"unresolved_dependencies":deps,"open_conflicts":[],"unknown":[],"provenance":{"time_source":"unknown"}}
