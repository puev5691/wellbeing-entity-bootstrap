from __future__ import annotations
import argparse, json
from pathlib import Path
from .core import CoordinationService, PilotError

def service(args):
    runtime=Path(args.root)
    runtime.mkdir(parents=True, exist_ok=True)
    package_root=Path(__file__).resolve().parents[1]
    return CoordinationService(runtime/'pilot.sqlite3', package_root/'schema.sql', runtime/'file_field')

def main(argv=None):
    p=argparse.ArgumentParser(prog='entity-env')
    p.add_argument('--root', default='.')
    sub=p.add_subparsers(dest='cmd',required=True)
    sub.add_parser('init')
    s=sub.add_parser('state'); s.add_argument('--entity',required=True)
    s=sub.add_parser('audit'); s.add_argument('--object')
    s=sub.add_parser('recovery-export'); s.add_argument('--entity',required=True)
    a=p.parse_args(argv)
    try:
        svc=service(a)
        if a.cmd=='init': out={'status':'ok','db':str(svc.db_path)}
        elif a.cmd=='state': out=svc.recovery_projection(a.entity)
        elif a.cmd=='recovery-export': out=svc.recovery_projection(a.entity)
        else:
            with svc.connect() as c:
                q='SELECT * FROM audit_transitions' + (' WHERE object_id=?' if a.object else '') + ' ORDER BY rowid'
                rows=c.execute(q,(a.object,)) if a.object else c.execute(q)
                out=[dict(r) for r in rows]
        print(json.dumps(out,ensure_ascii=False,indent=2)); return 0
    except PilotError as e:
        print(json.dumps({'status':'error','failure':e.code,'subcode':e.subcode},ensure_ascii=False)); return 2

if __name__=='__main__': raise SystemExit(main())
