import unittest,tempfile,threading,time,hashlib,urllib.error,json
from pathlib import Path
from entity_env_server.sandbox import SandboxService,SandboxError
from entity_env_server.httpd import serve
from entity_env_server.client import HTTPClient
class S6S10(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory(); self.s=SandboxService(Path(self.t.name))
  for e in ('ent:KOO','ent:KOD','ent:FOO'): self.s.register_entity(e)
  self.koo=self.s.register_instance('ent:KOO'); self.kod=self.s.register_instance('ent:KOD'); self.foo=self.s.register_instance('ent:FOO')
  self.tk=self.s.issue_credential(self.s.create_principal('instance',self.koo))['token']; self.td=self.s.issue_credential(self.s.create_principal('instance',self.kod))['token']; self.tf=self.s.issue_credential(self.s.create_principal('instance',self.foo))['token']
  for ent,act,scope in [('ent:KOO','task.create','entity:ent:KOD'),('ent:KOD','task.assign','task:*'),('ent:KOD','assignment.accept','task:*'),('ent:KOD','artifact.publish','task:*'),('ent:KOD','route.dispatch','entity:ent:KOO'),('ent:KOO','result.accept','task:*')]: self.s.add_authority(ent,'operator','ev',act,scope)
  self.srv,_=serve(self.s); self.base='http://127.0.0.1:'+str(self.srv.server_address[1]); self.ck=HTTPClient(self.base,self.tk); self.cd=HTTPClient(self.base,self.td); self.cf=HTTPClient(self.base,self.tf)
 def tearDown(self): self.srv.shutdown(); self.t.cleanup()
 def flow(self,data=b'GOOD'):
  r=self.s.create_request('ent:KOO','ent:KOD','x','s','r'+str(time.time_ns())); t=self.s.create_task('ent:KOD','ent:KOO',r,'x',1,'ent:KOO','t'+str(time.time_ns())); a=self.s.assign(t,'ent:KOD',self.kod,'ent:KOD','a'+str(time.time_ns())); self.s.accept_assignment(a,'ent:KOD',self.kod,'aa'+str(time.time_ns())); u=self.s.upload_init(t,'ent:KOD',self.kod,'u'+str(time.time_ns())); self.s.upload_bytes(u,data,self.kod,'ent:KOD'); p=self.s.publish_upload(u,'p'+str(time.time_ns()),self.kod,'ent:KOD'); return t,p
 def test_S6_upload_bytes_without_verified_caller_rejected(self):
  t,p0=self.flow(); u=self.s.upload_init(t,'ent:KOD',self.kod,'u2');
  with self.assertRaises(TypeError): self.s.upload_bytes(u,b'EVIL')
 def test_S6_publish_without_verified_caller_rejected(self):
  t,p0=self.flow(); u=self.s.upload_init(t,'ent:KOD',self.kod,'u3'); self.s.upload_bytes(u,b'x',self.kod,'ent:KOD')
  with self.assertRaises(TypeError): self.s.publish_upload(u,'pp')
 def test_S7_foreign_instance_cannot_dispatch_route(self):
  t,p=self.flow(); rt=self.s.create_route('artifact_version',p['artifact_version_id'],'ent:KOD','ent:KOO','rr')
  with self.assertRaises(urllib.error.HTTPError): self.cf.command('route.dispatch',route_id=rt,idempotency_key='d')
 def test_S7_dispatch_exact_retry_one_inbox_effect(self):
  t,p=self.flow(); rt=self.s.create_route('artifact_version',p['artifact_version_id'],'ent:KOD','ent:KOO','r2'); a=self.cd.command('route.dispatch',route_id=rt,idempotency_key='d2'); b=self.cd.command('route.dispatch',route_id=rt,idempotency_key='d2'); self.assertEqual(a,b)
  with self.s.connect() as c:self.assertEqual(c.execute('select count(*) from inbox where route_id=?',(rt,)).fetchone()[0],1)
 def test_S7_dispatch_semantic_mismatch_conflict(self):
  t,p=self.flow(); rt=self.s.create_route('artifact_version',p['artifact_version_id'],'ent:KOD','ent:KOO','r3'); self.cd.command('route.dispatch',route_id=rt,transport_message_id='m1',idempotency_key='d3')
  with self.assertRaises(urllib.error.HTTPError): self.cd.command('route.dispatch',route_id=rt,transport_message_id='m2',idempotency_key='d3')
 def test_S7_dispatch_response_contract(self):
  t,p=self.flow(); rt=self.s.create_route('artifact_version',p['artifact_version_id'],'ent:KOD','ent:KOO','r4'); o=self.cd.command('route.dispatch',route_id=rt,idempotency_key='d4'); self.assertEqual(o['route_id'],rt); self.assertIn('transport_message_id',o)
 def test_S8_recipient_fetch_before_delivery_rejected(self):
  t,p=self.flow(); self.s.create_route('artifact_version',p['artifact_version_id'],'ent:KOD','ent:KOO','r5')
  with self.assertRaises(urllib.error.HTTPError): self.ck.get('/files/v1/sha256/'+p['sha256'])
 def test_S8_receipt_requires_recipient_version_evidence(self):
  t,p=self.flow(); rt=self.s.create_route('artifact_version',p['artifact_version_id'],'ent:KOD','ent:KOO','r6'); self.cd.command('route.dispatch',route_id=rt,idempotency_key='d6')
  with self.assertRaises(urllib.error.HTTPError): self.ck.command('receipt.register',route_id=rt,idempotency_key='rec6')
 def test_S8_wrong_received_digest_rejected(self):
  t,p=self.flow(); rt=self.s.create_route('artifact_version',p['artifact_version_id'],'ent:KOD','ent:KOO','r7'); self.cd.command('route.dispatch',route_id=rt,idempotency_key='d7')
  with self.assertRaises(urllib.error.HTTPError): self.ck.command('receipt.register',route_id=rt,received_sha256='0'*64,idempotency_key='rec7')
 def test_S8_missing_object_returns_deterministic_failure(self):
  t,p=self.flow(); rt=self.s.create_route('artifact_version',p['artifact_version_id'],'ent:KOD','ent:KOO','r8'); self.cd.command('route.dispatch',route_id=rt,idempotency_key='d8'); (self.s.objects/p['sha256'][:2]/p['sha256'][2:4]/p['sha256']).unlink()
  with self.assertRaises(urllib.error.HTTPError) as x:self.ck.get('/files/v1/sha256/'+p['sha256']); self.assertEqual(x.exception.code,409)
 def test_S9_migration_checksum_mismatch_not_ready(self):
  with self.s.connect() as c:c.execute("update migration_history set checksum='BAD' where version=2")
  self.assertFalse(self.s.health()['ready'])
 def test_S9_backup_barrier_serializes_mutation(self):
  done=[]
  self.s._mutation_lock.acquire(); th=threading.Thread(target=lambda:(self.s.create_request('ent:KOO','ent:KOD','b','s','bar'),done.append(1))); th.start(); time.sleep(.1); self.assertFalse(done); self.s._mutation_lock.release(); th.join(2); self.assertTrue(done)
 def test_S9_restored_root_reopens_same_state(self):
  rid=self.s.create_request('ent:KOO','ent:KOD','restore','s','rest'); b=Path(self.t.name)/'b'; self.s.backup(b); out=self.s.restore_to_staging(b,Path(self.t.name)/'restored'); self.assertTrue(out['ready']); rs=SandboxService(Path(out['staging_root']));
  with rs.connect() as c:self.assertEqual(c.execute('select count(*) from requests where request_id=?',(rid,)).fetchone()[0],1)
 def test_S9_restore_preserves_artifact_paths_hashes(self):
  t,p=self.flow(); b=Path(self.t.name)/'b2'; self.s.backup(b); out=self.s.restore_to_staging(b,Path(self.t.name)/'restored2'); q=Path(out['staging_root'])/'files'/'objects'/'sha256'/p['sha256'][:2]/p['sha256'][2:4]/p['sha256']; self.assertEqual(hashlib.sha256(q.read_bytes()).hexdigest(),p['sha256'])
 def test_S10_foreign_instance_cannot_read_unrelated_recovery_by_default(self):
  with self.assertRaises(urllib.error.HTTPError): self.cf.get('/api/v1/recovery/ent:KOO')
 def test_S10_foreign_instance_cannot_read_global_audit_by_default(self):
  self.s.create_request('ent:KOO','ent:KOD','audit','s','aud'); out=self.cf.get('/api/v1/audit'); self.assertFalse(any(x.get('actor_entity_id')=='ent:KOO' for x in out))
 def test_S10_object_participant_can_read_required_task_route_state(self):
  t,p=self.flow(); rt=self.s.create_route('artifact_version',p['artifact_version_id'],'ent:KOD','ent:KOO','r10'); self.assertEqual(self.ck.get('/api/v1/tasks/'+t)['task_id'],t); self.assertEqual(self.ck.get('/api/v1/routes/'+rt)['route_id'],rt)
 def test_S10_authorized_own_state_inspection(self): self.assertIn('entity',self.ck.get('/api/v1/state?entity_id=ent:KOO'))
if __name__=='__main__':unittest.main()
