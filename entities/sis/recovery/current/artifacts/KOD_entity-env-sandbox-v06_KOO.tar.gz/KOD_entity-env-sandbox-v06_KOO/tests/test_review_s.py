import unittest,tempfile,json,urllib.request,urllib.error,hashlib,sqlite3
from pathlib import Path
from entity_env_server.sandbox import SandboxService,SandboxError
from entity_env_server.httpd import serve
from entity_env_server.client import HTTPClient
class ReviewS(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory(); self.s=SandboxService(Path(self.t.name))
  for e in ('ent:KOO','ent:KOD','ent:FOO'): self.s.register_entity(e)
  self.koo=self.s.register_instance('ent:KOO'); self.kod=self.s.register_instance('ent:KOD'); self.foo=self.s.register_instance('ent:FOO')
  self.tk=self.s.issue_credential(self.s.create_principal('instance',self.koo))['token']; self.td=self.s.issue_credential(self.s.create_principal('instance',self.kod))['token']; self.tf=self.s.issue_credential(self.s.create_principal('instance',self.foo))['token']
  for ent,act,scope in [('ent:KOO','task.create','entity:ent:KOD'),('ent:KOD','task.assign','task:*'),('ent:KOD','assignment.accept','task:*'),('ent:KOD','artifact.publish','task:*'),('ent:KOD','route.dispatch','entity:ent:KOO'),('ent:KOO','result.accept','task:*')]: self.s.add_authority(ent,'operator','ev',act,scope)
  self.srv,_=serve(self.s); self.base='http://127.0.0.1:'+str(self.srv.server_address[1]); self.ck=HTTPClient(self.base,self.tk); self.cd=HTTPClient(self.base,self.td); self.cf=HTTPClient(self.base,self.tf)
 def tearDown(self): self.srv.shutdown(); self.t.cleanup()
 def flow(self):
  r=self.s.create_request('ent:KOO','ent:KOD','x','s','r'); t=self.s.create_task('ent:KOD','ent:KOO',r,'x',1,'ent:KOO','t'); a=self.s.assign(t,'ent:KOD',self.kod,'ent:KOD','a'); self.s.accept_assignment(a,'ent:KOD',self.kod,'aa'); u=self.s.upload_init(t,'ent:KOD',self.kod,'u'); return t,u
 def test_S1_foreign_instance_cannot_write_upload_bytes(self):
  t,u=self.flow()
  with self.assertRaises(urllib.error.HTTPError): self.cf.request('PUT','/api/v1/artifacts/uploads/'+u,raw=b'EVIL')
 def test_S1_foreign_instance_cannot_publish_upload(self):
  t,u=self.flow(); self.s.upload_bytes(u,b'good',self.kod,'ent:KOD')
  with self.assertRaises(urllib.error.HTTPError): self.cf.request('POST',f'/api/v1/artifacts/uploads/{u}/publish',{'idempotency_key':'p'})
 def test_S1_foreign_attempt_cannot_change_artifact_provenance(self):
  t,u=self.flow()
  try:self.cf.request('PUT','/api/v1/artifacts/uploads/'+u,raw=b'EVIL')
  except urllib.error.HTTPError:pass
  self.cd.request('PUT','/api/v1/artifacts/uploads/'+u,raw=b'GOOD'); p=self.cd.request('POST',f'/api/v1/artifacts/uploads/{u}/publish',{'idempotency_key':'p'})
  with self.s.connect() as c:r=c.execute('select a.source_entity_id,v.created_by_instance_id from artifacts a join artifact_versions v on v.artifact_id=a.artifact_id where a.artifact_id=?',(p['artifact_id'],)).fetchone(); self.assertEqual(tuple(r),('ent:KOD',self.kod))
 def test_S2_stale_instance_command_rejected(self):
  with self.s.connect() as c:c.execute("update instances set lifecycle='stale' where instance_id=?",(self.koo,))
  with self.assertRaises(urllib.error.HTTPError): self.ck.command('request.create',target_entity_id='ent:KOD',requested_outcome='x',idempotency_key='s2')
 def test_S2_stale_instance_protected_fetch_rejected(self):
  t,u=self.flow(); self.s.upload_bytes(u,b'x',self.kod,'ent:KOD'); p=self.s.publish_upload(u,'p',self.kod,'ent:KOD'); self.s.create_route('artifact_version',p['artifact_version_id'],'ent:KOD','ent:KOO','rr')
  with self.s.connect() as c:c.execute("update instances set lifecycle='stale' where instance_id=?",(self.koo,))
  with self.assertRaises(urllib.error.HTTPError): self.ck.get('/files/v1/sha256/'+p['sha256'])
 def test_S2_history_admin_separation(self): self.assertTrue(self.s.inspect_audit() is not None)
 def test_S3_entity_registration_is_audited(self):
  ar=self.s.add_authority('ent:KOO','operator','e','entity.register','entity:ent:NEW'); self.s.register_entity_operational('ent:NEW','ent:KOO',ar,'er')
  self.assertTrue(any(x['object_id']=='ent:NEW' for x in self.s.inspect_audit()))
 def test_S3_instance_registration_is_audited(self):
  ar=self.s.add_authority('ent:KOO','operator','e','instance.register','entity:ent:KOD'); i=self.s.register_instance_operational('ent:KOD','ent:KOO',ar,idempotency_key='ir'); self.assertTrue(any(x['object_id']==i for x in self.s.inspect_audit()))
 def _wg(self):
  ag=self.s.add_authority('ent:KOO','operator','e','writer.grant','entity-current-state:ent:KOD'); ah=self.s.add_authority('ent:KOO','operator','e','writer.handoff','entity-current-state:ent:KOD'); af=self.s.add_authority('ent:KOO','operator','e','writer.failover','entity-current-state:ent:KOD'); ar=self.s.add_authority('ent:KOO','operator','e','writer.release','entity-current-state:ent:KOD'); g,n=self.s.grant_writer('ent:KOD',self.kod,'entity-current-state:ent:KOD','ent:KOO',ag,'e',idempotency_key='wg'); return g,n,ah,af,ar
 def test_S3_writer_release_audited_idempotent(self):
  g,n,ah,af,ar=self._wg(); self.assertEqual(self.s.writer_release(g,'ent:KOO',ar,'rel'),self.s.writer_release(g,'ent:KOO',ar,'rel')); self.assertTrue(any(x['action']=='writer.release' for x in self.s.inspect_audit()))
 def test_S3_handoff_retry_projection(self):
  g,n,ah,af,ar=self._wg(); ni=self.s.register_instance('ent:KOD'); x=self.s.writer_handoff(g,ni,'ent:KOO',ah,'e','hh'); self.assertEqual(x,self.s.writer_handoff(g,ni,'ent:KOO',ah,'e','hh'))
  with self.s.connect() as c:o=c.execute('select writer_grant_ref from instances where instance_id=?',(self.kod,)).fetchone()[0]; q=c.execute('select writer_grant_ref,writer_generation from instances where instance_id=?',(ni,)).fetchone(); self.assertIsNone(o); self.assertEqual((q[0],q[1]),x)
 def test_S3_failover_retry(self):
  g,n,ah,af,ar=self._wg(); ni=self.s.register_instance('ent:KOD'); x=self.s.writer_failover(g,ni,'ent:KOO',af,'e','ff'); self.assertEqual(x,self.s.writer_failover(g,ni,'ent:KOO',af,'e','ff'))
 def test_S4_http_recipient_polling(self): self.assertEqual(self.ck.get('/api/v1/inbox'),[])
 def test_S4_http_registration_activation(self):
  er=self.s.add_authority('ent:KOO','operator','e','entity.register','entity:ent:NEW'); self.assertEqual(self.ck.command('entity.register',entity_id='ent:NEW',authority_ref=er,idempotency_key='er')['entity_id'],'ent:NEW')
 def test_S4_http_writer_handoff(self):
  g,n,ah,af,ar=self._wg(); ni=self.s.register_instance('ent:KOD'); out=self.ck.command('writer.handoff',grant_id=g,new_instance_id=ni,authority_ref=ah,evidence_ref='e',idempotency_key='hhttp'); self.assertEqual(out['generation'],n+1)
 def test_S4_http_cross_client_E1(self):
  r=self.ck.command('request.create',target_entity_id='ent:KOD',requested_outcome='x',scope='s',idempotency_key='hr')['request_id']; t=self.ck.command('task.create',owner_entity_id='ent:KOD',origin_request_id=r,terminal_criterion='x',idempotency_key='ht')['task_id']; a=self.cd.command('assignment.create',task_id=t,assignee_entity_id='ent:KOD',assignee_instance_id=self.kod,idempotency_key='ha')['assignment_id']; self.cd.command('assignment.accept',assignment_id=a,idempotency_key='haa'); self.assertEqual(self.ck.get('/api/v1/tasks/'+t)['task_state'],'active')
 def test_S4_cli_client_is_http(self): self.assertEqual(self.ck.get('/health/ready')['ready'],True)
 def test_S5_restore_staging(self):
  b=Path(self.t.name)/'backup'; self.s.backup(b); out=self.s.restore_to_staging(b,Path(self.t.name)/'restore'); self.assertTrue(out['ready'])
 def test_S5_unknown_newer_schema_not_ready(self):
  with self.s.connect() as c:c.execute("update sandbox_meta set value='999' where key='schema_version'")
  self.assertFalse(self.s.health()['ready'])
 def test_S5_migration_history(self):
  with self.s.connect() as c:self.assertIsNotNone(c.execute('select * from migration_history where version=2').fetchone())
 def test_S5_structured_log_no_token(self):
  self.ck.get('/api/v1/inbox'); txt=self.s.log_path.read_text(); self.assertIn('correlation_id',txt); self.assertNotIn(self.tk,txt)
if __name__=='__main__':unittest.main()
