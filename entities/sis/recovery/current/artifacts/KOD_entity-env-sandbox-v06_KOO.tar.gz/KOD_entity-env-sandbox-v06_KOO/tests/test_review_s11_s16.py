import unittest,tempfile,time,hashlib,subprocess,sys,json,os
from pathlib import Path
from unittest import mock
from entity_env_server.sandbox import SandboxService,SandboxError
from entity_env_server.httpd import serve
from entity_env_server.client import HTTPClient
from entity_env_server.pilot_core import CoordinationService

class S11S16(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory(); self.root=Path(self.t.name); self.s=SandboxService(self.root)
  for e in ('ent:KOO','ent:KOD','ent:FOO'): self.s.register_entity(e)
  self.koo=self.s.register_instance('ent:KOO'); self.kod=self.s.register_instance('ent:KOD'); self.foo=self.s.register_instance('ent:FOO')
  self.tk=self.s.issue_credential(self.s.create_principal('instance',self.koo))['token']; self.td=self.s.issue_credential(self.s.create_principal('instance',self.kod))['token']; self.tf=self.s.issue_credential(self.s.create_principal('instance',self.foo))['token']
  for ent,act,scope in [('ent:KOO','task.create','entity:ent:KOD'),('ent:KOD','task.assign','task:*'),('ent:KOD','assignment.accept','task:*'),('ent:KOD','artifact.publish','task:*'),('ent:KOD','route.dispatch','entity:ent:KOO'),('ent:KOO','result.accept','task:*')]: self.s.add_authority(ent,'operator','ev',act,scope)
  self.srv,_=serve(self.s); self.base='http://127.0.0.1:'+str(self.srv.server_address[1]); self.ck=HTTPClient(self.base,self.tk); self.cd=HTTPClient(self.base,self.td)
 def tearDown(self): self.srv.shutdown(); self.t.cleanup()
 def flow(self,data=b'GOOD'):
  z=str(time.time_ns()); r=self.s.create_request('ent:KOO','ent:KOD','x','s','r'+z); t=self.s.create_task('ent:KOD','ent:KOO',r,'x',1,'ent:KOO','t'+z); a=self.s.assign(t,'ent:KOD',self.kod,'ent:KOD','a'+z); self.s.accept_assignment(a,'ent:KOD',self.kod,'aa'+z); u=self.s.upload_init(t,'ent:KOD',self.kod,'u'+z); self.s.upload_bytes(u,data,self.kod,'ent:KOD'); return t,u
 def published(self,data=b'GOOD'):
  t,u=self.flow(data); return t,self.s.publish_upload(u,'p'+str(time.time_ns()),self.kod,'ent:KOD')
 def test_S11_foreign_instance_cannot_impersonate_route_sender_at_service_boundary(self):
  t,p=self.published(); rt=self.s.create_route('artifact_version',p['artifact_version_id'],'ent:KOD','ent:KOO','r11')
  with self.assertRaises(SandboxError): self.s.dispatch_route(rt,caller_instance=self.foo,caller_entity='ent:KOD',idempotency_key='d11')
 def test_S11_foreign_instance_cannot_impersonate_route_recipient_at_service_boundary(self):
  t,p=self.published(); rt=self.s.create_route('artifact_version',p['artifact_version_id'],'ent:KOD','ent:KOO','r12'); self.s.dispatch_route(rt,caller_instance=self.kod,caller_entity='ent:KOD',idempotency_key='d12')
  with self.assertRaises(SandboxError): self.s.receive_route_external(rt,'ent:KOO',self.foo,'rec12',p['sha256'])
 def test_S12_object_commit_failure_creates_no_published_artifact_version(self):
  t,u=self.flow();
  with mock.patch('entity_env_server.sandbox.os.replace',side_effect=OSError('boom')):
   with self.assertRaises(OSError): self.s.publish_upload(u,'s12a',self.kod,'ent:KOD')
  with self.s.connect() as c:self.assertEqual(c.execute('select count(*) from artifacts where task_id=?',(t,)).fetchone()[0],0)
 def test_S12_db_failure_after_object_commit_leaves_only_detectable_orphan(self):
  t,u=self.flow(b'ORPHAN'); digest=hashlib.sha256(b'ORPHAN').hexdigest()
  with mock.patch.object(self.s,'_finalize_external_publish',side_effect=RuntimeError('db fail')):
   with self.assertRaises(RuntimeError): self.s.publish_upload(u,'s12b',self.kod,'ent:KOD')
  self.assertIn(digest,self.s.scan_orphans())
  with self.s.connect() as c:self.assertEqual(c.execute('select count(*) from artifacts where task_id=?',(t,)).fetchone()[0],0)
 def test_S13_published_upload_cannot_be_reopened(self):
  t,u=self.flow(); self.s.publish_upload(u,'s13a',self.kod,'ent:KOD')
  with self.assertRaises(SandboxError): self.s.upload_bytes(u,b'NEW',self.kod,'ent:KOD')
 def test_S13_published_upload_cannot_create_second_artifact_with_new_key(self):
  t,u=self.flow(); self.s.publish_upload(u,'s13b',self.kod,'ent:KOD')
  with self.assertRaises(SandboxError): self.s.publish_upload(u,'s13b-new',self.kod,'ent:KOD')
  with self.s.connect() as c:self.assertEqual(c.execute('select count(*) from artifacts where task_id=?',(t,)).fetchone()[0],1)
 def test_S13_publish_result_is_bound_to_actual_digest(self):
  t,u=self.flow(b'DIGEST'); p=self.s.publish_upload(u,'s13c',self.kod,'ent:KOD'); self.assertEqual(p['sha256'],hashlib.sha256(b'DIGEST').hexdigest())
  with self.s.connect() as c:r=c.execute("select semantic_fingerprint from command_idempotency where operation='sandbox.artifact.publish' and idempotency_key='s13c'").fetchone(); self.assertIsNotNone(r)
 def _activation(self):
  ar=self.s.add_authority('ent:KOO','operator','reg','instance.register','entity:ent:KOD'); aa=self.s.add_authority('ent:KOO','operator','act','instance.activate','entity:ent:KOD'); basis=self.s.add_authority('ent:KOD','operator','rec','initiation.recovery_basis','entity:ent:KOD'); i=self.s.register_instance_operational('ent:KOD','ent:KOO',ar,idempotency_key='regx'); return i,aa,basis
 def test_S14_instance_activate_exact_retry_returns_same_result(self):
  i,aa,b=self._activation(); a=self.s.activate_instance(i,'ent:KOO',aa,b,'actx'); z=self.s.activate_instance(i,'ent:KOO',aa,b,'actx'); self.assertEqual(a,z)
 def test_S14_instance_activate_semantic_mismatch_conflicts(self):
  i,aa,b=self._activation(); self.s.activate_instance(i,'ent:KOO',aa,b,'acty')
  with self.assertRaises(SandboxError) as x:self.s.activate_instance(i,'ent:KOO',aa,b+'x','acty'); self.assertEqual(x.exception.subcode,'idempotency_semantic_mismatch')
 def test_S14_empty_or_unverifiable_basis_rejected(self):
  i,aa,b=self._activation()
  for bad in ('','nonsense'):
   with self.assertRaises(SandboxError): self.s.activate_instance(i,'ent:KOO',aa,bad,'bad'+bad)
 def test_S15_same_digest_multiple_artifacts_authorized_version_fetches_independent_of_row_order(self):
  # FOO version first, then KOD version with delivered route to KOO.
  self.s.add_authority('ent:KOO','operator','ev','task.create','entity:ent:FOO'); self.s.add_authority('ent:FOO','operator','ev','task.assign','task:*'); self.s.add_authority('ent:FOO','operator','ev','assignment.accept','task:*'); self.s.add_authority('ent:FOO','operator','ev','artifact.publish','task:*')
  z=str(time.time_ns()); r=self.s.create_request('ent:KOO','ent:FOO','x','s','rf'+z); t=self.s.create_task('ent:FOO','ent:KOO',r,'x',1,'ent:KOO','tf'+z); a=self.s.assign(t,'ent:FOO',self.foo,'ent:FOO','af'+z); self.s.accept_assignment(a,'ent:FOO',self.foo,'aaf'+z); u=self.s.upload_init(t,'ent:FOO',self.foo,'uf'+z); self.s.upload_bytes(u,b'SAME',self.foo,'ent:FOO'); self.s.publish_upload(u,'pf'+z,self.foo,'ent:FOO')
  t2,p=self.published(b'SAME'); rt=self.s.create_route('artifact_version',p['artifact_version_id'],'ent:KOD','ent:KOO','same-route'); self.s.dispatch_route(rt,caller_instance=self.kod,caller_entity='ent:KOD',idempotency_key='same-dispatch'); self.assertEqual(self.s.protected_fetch(p['sha256'],self.tk),b'SAME')
 def test_S15_same_digest_without_any_authorized_version_still_denied(self):
  t,p=self.published(b'PRIVATE')
  with self.assertRaises(SandboxError): self.s.protected_fetch(p['sha256'],self.tf)
 def _admin(self):
  pid=self.s.create_principal('operator_admin','local:operator'); return self.s.issue_credential(pid)['token']
 def _ev(self,path,holder,action,scope,issuer='OPR'):
  o={'schema_version':'authority-evidence/v1','evidence_kind':'project_authority','issuer_kind':'operator','issuer_ref':issuer,'holder_entity_id':holder,'action':action,'object_scope':scope}; raw=(json.dumps(o,sort_keys=True,separators=(',',':'))+'\n').encode(); path.write_bytes(raw); return path,'sha256:'+hashlib.sha256(raw).hexdigest()
 def test_S16_nonexistent_or_wrong_scope_admin_authority_basis_rejected(self):
  tok=self._admin()
  with self.assertRaises(SandboxError): self.s.admin_project_action(tok,'missing','entity.register','entity:ent:X','ent:KOO')
 def test_S16_authorized_admin_or_read_scope_can_inspect_allowed_state(self):
  tok=self._admin(); ep,ev=self._ev(self.root/'opr-evidence.json','ent:KOO','recovery.read','entity:ent:KOO','OPR-decision'); ar=self.s.admin_import_authority(tok,'ent:KOO','operator','OPR-decision','recovery.read','entity:ent:KOO',ev,evidence_path=ep); out=self.s.admin_read_recovery(tok,'ent:KOO',ar); self.assertEqual(out['entity']['entity_id'],'ent:KOO')
 def test_S16_operator_admin_cannot_self_issue_project_authority(self):
  tok=self._admin()
  with self.assertRaises(SandboxError): self.s.admin_import_authority(tok,'ent:KOO','entity','self','recovery.read','entity:ent:KOO','x')
 def test_S16_local_admin_bootstrap_does_not_require_direct_python_fixture_calls(self):
  tok=self._admin(); ep,ev=self._ev(self.root/'cli-evidence.json','ent:KOO','entity.register','entity:ent:NEW'); self.s.close(); env=dict(os.environ); env['PYTHONPATH']=str(Path(__file__).resolve().parents[1]); cmd=[sys.executable,'-m','entity_env_server.cli','--root',str(self.root),'--admin-token',tok,'admin-import-authority','--json',json.dumps({'holder':'ent:KOO','issuer_kind':'operator','issuer_ref':'OPR','action':'entity.register','scope':'entity:ent:NEW','evidence_version':ev,'evidence_path':str(ep)})]; out=json.loads(subprocess.check_output(cmd,env=env)); ar=out['authority_ref']; cmd=[sys.executable,'-m','entity_env_server.cli','--root',str(self.root),'--admin-token',tok,'admin-register-entity','--json',json.dumps({'entity_id':'ent:NEW','authority_ref':ar,'idempotency_key':'cli-new'})]; out=json.loads(subprocess.check_output(cmd,env=env)); self.assertEqual(out['entity_id'],'ent:NEW')
if __name__=='__main__': unittest.main()
