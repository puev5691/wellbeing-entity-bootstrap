import hashlib,json,os,sqlite3,tempfile,unittest,urllib.request,urllib.error
from pathlib import Path
from entity_env_server.sandbox import SandboxService,SandboxError
from entity_env_server.httpd import serve

class ExternalTests(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory(); self.s=SandboxService(Path(self.t.name))
  for e in ('ent:KOO','ent:KOD','ent:FOO'): self.s.register_entity(e)
  self.koo=self.s.register_instance('ent:KOO'); self.kod=self.s.register_instance('ent:KOD'); self.foo=self.s.register_instance('ent:FOO')
  # principals/credentials
  self.pk=self.s.create_principal('instance',self.koo); self.ck=self.s.issue_credential(self.pk)
  self.pd=self.s.create_principal('instance',self.kod); self.cd=self.s.issue_credential(self.pd)
  self.pf=self.s.create_principal('instance',self.foo); self.cf=self.s.issue_credential(self.pf)
  # broad fixture authority for baseline operations
  acts=[('ent:KOO','task.create','entity:ent:KOD'),('ent:KOO','route.dispatch','entity:ent:KOD'),('ent:KOD','route.dispatch','entity:ent:KOO'),('ent:KOO','result.accept','task:*'),
        ('ent:KOD','task.assign','task:*'),('ent:KOD','assignment.accept','task:*'),('ent:KOD','artifact.publish','task:*')]
  # pilot authority matcher supports exact or * suffix
  for ent,act,scope in acts: self.s.add_authority(ent,'operator','evidence:'+act,act,scope)
 def tearDown(self): self.t.cleanup()
 def flow(self,data=b'hello'):
  r=self.s.create_request('ent:KOO','ent:KOD','deliver','scope','r1')
  t=self.s.create_task('ent:KOD','ent:KOO',r,'accepted-result',1,'ent:KOO','t1')
  a=self.s.assign(t,'ent:KOD',self.kod,'ent:KOD','a1'); self.s.accept_assignment(a,'ent:KOD',self.kod,'aa1')
  up=self.s.upload_init(t,'ent:KOD',self.kod,'u1'); self.s.upload_bytes(up,data,self.kod,'ent:KOD'); pub=self.s.publish_upload(up,'p1',self.kod,'ent:KOD')
  return r,t,a,pub
 def test_E1_cross_client_success(self):
  r,t,a,p=self.flow(); route=self.s.create_route('artifact_version',p['artifact_version_id'],'ent:KOD','ent:KOO','rt1'); self.s.dispatch_route(route,'m1',True,self.kod,'ent:KOD','disp:'+str('m1')); rec=self.s.receive_route(route,'ent:KOO','rc1');
  self.s.add_authority('ent:KOO','operator','acc','result.accept',f'task:{t}'); ac=self.s.accept_and_close(t,rec['receipt_id'],'ent:KOO','ac1');
  with self.s.connect() as c: self.assertEqual(c.execute('select task_state from tasks where task_id=?',(t,)).fetchone()[0],'closed')
 def test_E2_external_version_mismatch(self):
  _,t,_,p=self.flow(); route=self.s.create_route('artifact_version',p['artifact_version_id'],'ent:KOD','ent:KOO','rt2'); self.s.dispatch_route(route,'m2',True,self.kod,'ent:KOD','disp:'+str('m2')); Path(self.s.objects/p['sha256'][:2]/p['sha256'][2:4]/p['sha256']).write_bytes(b'bad')
  with self.assertRaises(SandboxError) as x:self.s.receive_route(route,'ent:KOO','rc2')
  self.assertEqual(x.exception.code,'version_mismatch')
 def test_E3_unauthorized_artifact_fetch(self):
  _,_,_,p=self.flow();
  with self.assertRaises(SandboxError): self.s.protected_fetch(p['sha256'],self.cf['token'])
 def test_E4_authenticated_but_unauthorized_command(self):
  self.s.authenticate(self.cf['token'])
  with self.s.connect() as c:
   with self.assertRaises(SandboxError): self.s.authority(c,'ent:FOO','writer.grant','entity-current-state:ent:FOO')
 def _writer_setup(self):
  self.s.add_authority('ent:KOO','operator','wg','writer.grant','entity-current-state:ent:KOD'); ar=self.s.add_authority('ent:KOO','operator','wh','writer.handoff','entity-current-state:ent:KOD'); af=self.s.add_authority('ent:KOO','operator','wf','writer.failover','entity-current-state:ent:KOD')
  g,n=self.s.grant_writer('ent:KOD',self.kod,'entity-current-state:ent:KOD','ent:KOO',self.s.authority_ref(self.s.connect(), self.s.connect().execute("select authority_ref from authority_refs where action='writer.grant'").fetchone()[0], 'ent:KOO','writer.grant','entity-current-state:ent:KOD') if False else self.s.connect().execute("select authority_ref from authority_refs where action='writer.grant'").fetchone()[0],'ev',idempotency_key='wg1')
  return g,n,ar,af
 def test_E5_planned_writer_handoff(self):
  g,n,ar,af=self._writer_setup(); new=self.s.register_instance('ent:KOD'); ng,nn=self.s.writer_handoff(g,new,'ent:KOO',ar,'handoff','h1'); self.assertEqual(nn,n+1)
  with self.s.connect() as c:self.assertEqual(c.execute('select state from writer_grants where writer_grant_id=?',(g,)).fetchone()[0],'superseded')
 def test_E6_assisted_lost_writer_failover(self):
  g,n,ar,af=self._writer_setup(); new=self.s.register_instance('ent:KOD'); ng,nn=self.s.writer_failover(g,new,'ent:KOO',af,'operator-decision','f1'); self.assertEqual(nn,n+1)
 def test_E7_service_restart_persistence(self):
  _,t,_,p=self.flow(); root=Path(self.t.name); s2=SandboxService(root)
  with s2.connect() as c:self.assertIsNotNone(c.execute('select * from tasks where task_id=?',(t,)).fetchone())
 def test_E8_file_field_unavailable(self):
  self.s.objects.rename(self.s.root/'objects.off'); self.assertFalse(self.s.health()['ready'])
  with self.assertRaises(SandboxError): self.s.upload_init('x','ent:KOD',self.kod,'u8')
 def test_E9_coordination_unavailable(self):
  self.s._write_ready=False; self.assertFalse(self.s.health()['ready'])
 def test_E10_stageA_replacement_readiness(self):
  self.assertTrue(hasattr(self.s,'upload_init') and hasattr(self.s,'protected_fetch') and hasattr(self.s,'backup'))
 def test_E11_registration_self_escalation_rejected(self):
  with self.assertRaises(SandboxError): self.s.register_entity_operational('ent:NEW','ent:FOO','missing')
 def test_E12_foreign_stale_instance_activation_rejected(self):
  self.s.add_authority('ent:KOO','operator','ir','instance.register','entity:ent:KOD'); aa=self.s.add_authority('ent:KOO','operator','ia','instance.activate','entity:ent:KOD'); basis=self.s.add_authority('ent:KOD','operator','recovery','initiation.recovery_basis','entity:ent:KOD'); i=self.s.register_instance_operational('ent:KOD','ent:KOO',self.s.connect().execute("select authority_ref from authority_refs where action='instance.register'").fetchone()[0]); self.s.activate_instance(i,'ent:KOO',aa,basis)
  with self.assertRaises(SandboxError): self.s.activate_instance(i,'ent:KOO',aa,basis,'different-retry')
 def test_E13_revoked_credential_rejected_history_preserved(self):
  self.assertEqual(self.s.authenticate(self.cd['token'])['principal_ref'],self.kod); self.s.revoke_credential(self.cd['credential_id'])
  with self.assertRaises(SandboxError): self.s.authenticate(self.cd['token'])
  with self.s.connect() as c:self.assertIsNotNone(c.execute('select * from credentials where credential_id=?',(self.cd['credential_id'],)).fetchone())
 def test_E14_exact_idempotent_retry_after_restart(self):
  r1=self.s.create_request('ent:KOO','ent:KOD','x','s','e14'); s2=SandboxService(Path(self.t.name)); r2=s2.create_request('ent:KOO','ent:KOD','x','s','e14'); self.assertEqual(r1,r2)
 def test_E15_same_key_semantic_mismatch_conflict(self):
  self.s.create_request('ent:KOO','ent:KOD','x','s','e15')
  with self.assertRaises(SandboxError): self.s.create_request('ent:KOO','ent:KOD','DIFF','s','e15')
 def test_E16_interrupted_upload_no_artifact(self):
  r=self.s.create_request('ent:KOO','ent:KOD','x','s','e16r'); t=self.s.create_task('ent:KOD','ent:KOO',r,'x',1,'ent:KOO','e16t'); up=self.s.upload_init(t,'ent:KOD',self.kod,'e16u'); self.s.upload_bytes(up,b'x',self.kod,'ent:KOD')
  with self.s.connect() as c:self.assertEqual(c.execute('select count(*) from artifacts').fetchone()[0],0)
 def test_E17_orphan_detectable(self):
  data=b'orphan'; d=hashlib.sha256(data).hexdigest(); p=self.s.objects/d[:2]/d[2:4]/d; p.parent.mkdir(parents=True); p.write_bytes(data); self.assertIn(d,self.s.scan_orphans())
 def test_E18_disk_full_write_not_ready(self):
  self.s._write_ready=False
  with self.assertRaises(SandboxError): self.s.upload_init('x','ent:KOD',self.kod,'e18')
 def test_E19_backup_restore_unknown(self):
  _,_,_,p=self.flow(); b=Path(self.t.name)/'bkp'; m=self.s.backup(b); self.assertTrue(self.s.verify_backup(b)['ok']); (b/'objects'/p['sha256']).unlink(); self.assertIn(p['sha256'],self.s.verify_backup(b)['unknown'])
 def test_E20_fetch_tied_to_recipient(self):
  _,_,_,p=self.flow(); route=self.s.create_route('artifact_version',p['artifact_version_id'],'ent:KOD','ent:KOO','e20'); self.s.dispatch_route(route,'e20tm',True,self.kod,'ent:KOD','e20d'); self.assertEqual(self.s.protected_fetch(p['sha256'],self.ck['token']),b'hello')
  with self.assertRaises(SandboxError): self.s.protected_fetch(p['sha256'],self.cf['token'])
 def test_E21_audit_required_mutation_rollback(self):
  # duplicate audit collision with different semantics must reject without second request row
  self.s.create_request('ent:KOO','ent:KOD','x','s','e21')
  with self.assertRaises(SandboxError): self.s.create_request('ent:KOO','ent:KOD','y','s','e21')
  with self.s.connect() as c:self.assertEqual(c.execute("select count(*) from requests where idempotency_key='e21'").fetchone()[0],1)
 def test_E23_durable_delivery_boundary(self):
  _,_,_,p=self.flow(); rt=self.s.create_route('artifact_version',p['artifact_version_id'],'ent:KOD','ent:KOO','e23'); self.s.dispatch_route(rt,'m23',durable=False,caller_instance=self.kod,caller_entity='ent:KOD',idempotency_key='e23a')
  with self.s.connect() as c:self.assertEqual(c.execute('select route_state from routes where route_id=?',(rt,)).fetchone()[0],'created')
  self.s.dispatch_route(rt,'m23',durable=True,caller_instance=self.kod,caller_entity='ent:KOD',idempotency_key='e23b')
  with self.s.connect() as c:self.assertEqual(c.execute('select route_state from routes where route_id=?',(rt,)).fetchone()[0],'delivered')
 def test_E24_upload_publish_retry(self):
  r=self.s.create_request('ent:KOO','ent:KOD','x','s','e24r'); t=self.s.create_task('ent:KOD','ent:KOO',r,'x',1,'ent:KOO','e24t'); a=self.s.assign(t,'ent:KOD',self.kod,'ent:KOD','e24a'); self.s.accept_assignment(a,'ent:KOD',self.kod,'e24aa'); u=self.s.upload_init(t,'ent:KOD',self.kod,'e24u'); self.s.upload_bytes(u,b'z',self.kod,'ent:KOD'); p1=self.s.publish_upload(u,'e24p',self.kod,'ent:KOD'); p2=self.s.publish_upload(u,'e24p',self.kod,'ent:KOD'); self.assertEqual(p1,p2)
 def test_E25_operator_admin_not_entity_authority(self):
  pa=self.s.create_principal('operator_admin','operator:local'); ca=self.s.issue_credential(pa)
  with self.assertRaises(SandboxError): self.s.admin_project_action(ca['token'])
 def test_E26_locator_knowledge_insufficient(self):
  _,_,_,p=self.flow();
  with self.assertRaises(SandboxError): self.s.protected_fetch(p['sha256'],self.cf['token'])
 def test_HTTP_protected_fetch(self):
  _,_,_,p=self.flow(); rt=self.s.create_route('artifact_version',p['artifact_version_id'],'ent:KOD','ent:KOO','http-route'); self.s.dispatch_route(rt,'httptm',True,self.kod,'ent:KOD','httpd'); srv,_=serve(self.s); port=srv.server_address[1]
  req=urllib.request.Request(f'http://127.0.0.1:{port}/files/v1/sha256/{p["sha256"]}',headers={'Authorization':'Bearer '+self.ck['token']}); self.assertEqual(urllib.request.urlopen(req).read(),b'hello'); srv.shutdown()

if __name__=='__main__': unittest.main()
