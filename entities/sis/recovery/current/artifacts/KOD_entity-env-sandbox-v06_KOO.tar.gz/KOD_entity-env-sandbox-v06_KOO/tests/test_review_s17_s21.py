import hashlib,json,os,subprocess,sys,tempfile,unittest
from pathlib import Path
from unittest import mock
from entity_env_server.sandbox import SandboxService,SandboxError

class S17S21(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory(); self.root=Path(self.t.name); self.s=SandboxService(self.root)
  for e in ('ent:KOO','ent:KOD'): self.s.register_entity(e)
  self.koo=self.s.register_instance('ent:KOO'); self.kod=self.s.register_instance('ent:KOD')
  for h,a,sc in [('ent:KOO','request.create','entity:ent:KOD'),('ent:KOO','task.create','entity:ent:KOD'),('ent:KOD','task.assign','task:*'),('ent:KOD','assignment.accept','task:*'),('ent:KOD','artifact.publish','task:*')]: self.s.add_authority(h,'operator','fixture',a,sc)
 def tearDown(self):
  try:self.s.close()
  except:pass
  self.t.cleanup()
 def flow(self,data=b'X'):
  r=self.s.create_request('ent:KOO','ent:KOD','x','s','r'); t=self.s.create_task('ent:KOD','ent:KOO',r,'x',1,'ent:KOO','t'); a=self.s.assign(t,'ent:KOD',self.kod,'ent:KOD','a'); self.s.accept_assignment(a,'ent:KOD',self.kod,'aa'); u=self.s.upload_init(t,'ent:KOD',self.kod,'u'); self.s.upload_bytes(u,data,self.kod,'ent:KOD'); return t,u
 def test_S17_failure_rolls_back_coordination(self):
  t,u=self.flow(b'ORPH'); d=hashlib.sha256(b'ORPH').hexdigest()
  with mock.patch.object(self.s,'_finalize_external_publish',side_effect=RuntimeError('fail')):
   with self.assertRaises(RuntimeError): self.s.publish_upload(u,'p',self.kod,'ent:KOD')
  with self.s.connect() as c:self.assertEqual(c.execute('select count(*) from artifacts where task_id=?',(t,)).fetchone()[0],0)
  self.assertIn(d,self.s.scan_orphans())
 def test_S17_success_no_duplicate_staging(self):
  t,u=self.flow(b'ONE'); p=self.s.publish_upload(u,'p',self.kod,'ent:KOD'); self.assertEqual(list(self.s.staging.glob('*')),[]); self.assertTrue((self.s.objects/p['sha256'][:2]/p['sha256'][2:4]/p['sha256']).exists())
 def test_S17_canonical_locator_at_first_db_visibility(self):
  t,u=self.flow(b'CAN'); p=self.s.publish_upload(u,'p',self.kod,'ent:KOD')
  with self.s.connect() as c:r=c.execute('select locator from artifact_versions where artifact_version_id=?',(p['artifact_version_id'],)).fetchone(); self.assertIn('/objects/sha256/',r[0])
 def evidence(self,b=b'OPR'):
  p=self.root/'decision.json'; o={'schema_version':'authority-evidence/v1','evidence_kind':'project_authority','issuer_kind':'operator','issuer_ref':'OPR','holder_entity_id':'ent:KOO','action':'recovery.read','object_scope':'entity:ent:KOO'}; raw=(json.dumps(o,sort_keys=True,separators=(',',':'))+'\n').encode(); p.write_bytes(raw); return p,'sha256:'+hashlib.sha256(raw).hexdigest()
 def evfile(self,p,kind,holder,action,scope,issuer='OPR'):
  o={'schema_version':'authority-evidence/v1','evidence_kind':kind,'issuer_kind':'operator','issuer_ref':issuer,'holder_entity_id':holder,'action':action,'object_scope':scope}; raw=(json.dumps(o,sort_keys=True,separators=(',',':'))+'\n').encode(); p.write_bytes(raw); return p
 def test_S18_fresh_bootstrap_and_first_entity(self):
  self.s.close(); rr=self.root/'fresh'; ev=self.evfile(rr.parent/'opr-admin.json','operator_bootstrap',None,'sandbox.bootstrap.admin','sandbox:local'); fev=self.evfile(rr.parent/'opr-entity.json','project_authority','ent:KOO','entity.register','entity:ent:KOO'); env=dict(os.environ,PYTHONPATH=str(Path(__file__).resolve().parents[1])); cmd=[sys.executable,'-m','entity_env_server.cli','--root',str(rr),'bootstrap-admin','--json',json.dumps({'evidence_path':str(ev)})]; adm=json.loads(subprocess.check_output(cmd,env=env)); cmd=[sys.executable,'-m','entity_env_server.cli','--root',str(rr),'--admin-token',adm['token'],'bootstrap-first-entity','--json',json.dumps({'entity_id':'ent:KOO','evidence_path':str(fev)})]; out=json.loads(subprocess.check_output(cmd,env=env)); self.assertEqual(out['entity_id'],'ent:KOO')
 def test_S18_bootstrap_closes(self):
  rr=self.root/'fresh2'; ev=self.evfile(self.root/'opr2.json','operator_bootstrap',None,'sandbox.bootstrap.admin','sandbox:local'); x=SandboxService(rr); x.bootstrap_operator_admin(ev); x.close(); y=SandboxService(rr)
  with self.assertRaises(SandboxError): y.bootstrap_operator_admin(ev)
  y.close()
 def test_S19_nonexistent_evidence_rejected(self):
  pid=self.s.create_principal('operator_admin','adm'); tok=self.s.issue_credential(pid)['token']
  with self.assertRaises(SandboxError): self.s.admin_import_authority(tok,'ent:KOO','operator','OPR','recovery.read','entity:ent:KOO','sha256:x',evidence_path=self.root/'nope')
 def test_S19_version_mismatch_rejected(self):
  pid=self.s.create_principal('operator_admin','adm'); tok=self.s.issue_credential(pid)['token']; ep,_=self.evidence()
  with self.assertRaises(SandboxError): self.s.admin_import_authority(tok,'ent:KOO','operator','OPR','recovery.read','entity:ent:KOO','sha256:bad',evidence_path=ep)
 def test_S19_verified_evidence_authorizes(self):
  pid=self.s.create_principal('operator_admin','adm'); tok=self.s.issue_credential(pid)['token']; ep,v=self.evidence(); ar=self.s.admin_import_authority(tok,'ent:KOO','operator','OPR','recovery.read','entity:ent:KOO',v,evidence_path=ep); self.assertEqual(self.s.admin_read_recovery(tok,'ent:KOO',ar)['entity']['entity_id'],'ent:KOO')
 def test_S20_second_coordinator_not_write_ready(self):
  s2=SandboxService(self.root); self.assertFalse(s2.health()['ready']); s2.close()
 def test_S20_admin_cli_cannot_mutate_live_db(self):
  pid=self.s.create_principal('operator_admin','adm'); tok=self.s.issue_credential(pid)['token']; env=dict(os.environ,PYTHONPATH=str(Path(__file__).resolve().parents[1])); cmd=[sys.executable,'-m','entity_env_server.cli','--root',str(self.root),'--admin-token',tok,'admin-read-recovery','--json','{"target_entity":"ent:KOO","authority_ref":"x"}']; p=subprocess.run(cmd,env=env,capture_output=True); self.assertNotEqual(p.returncode,0)
 def test_S20_backup_second_owner_rejected(self):
  s2=SandboxService(self.root)
  with self.assertRaises(SandboxError): s2.backup(self.root/'b')
  s2.close()
 def test_S21_second_credential_same_principal(self):
  p=self.s.create_principal('instance',self.kod); a=self.s.issue_credential(p); b=self.s.issue_credential(self.s.create_principal('instance',self.kod)); self.assertNotEqual(a['credential_id'],b['credential_id'])
 def test_S21_rotate_revokes_old(self):
  p=self.s.create_principal('instance',self.kod); a=self.s.issue_credential(p); b=self.s.rotate_credential(p,a['credential_id']); self.assertEqual(self.s.authenticate(b['token'])['principal_ref'],self.kod)
  with self.assertRaises(SandboxError): self.s.authenticate(a['token'])
 def test_S21_reissue_after_revoke(self):
  p=self.s.create_principal('instance',self.kod); a=self.s.issue_credential(p); self.s.revoke_credential(a['credential_id']); b=self.s.issue_credential(p); self.assertEqual(self.s.authenticate(b['token'])['principal_ref'],self.kod)
 def test_S21_cli_revoke_offline(self):
  p=self.s.create_principal('operator_admin','adm'); adm=self.s.issue_credential(p); ip=self.s.create_principal('instance',self.kod); c=self.s.issue_credential(ip); self.s.close(); env=dict(os.environ,PYTHONPATH=str(Path(__file__).resolve().parents[1])); cmd=[sys.executable,'-m','entity_env_server.cli','--root',str(self.root),'--admin-token',adm['token'],'admin-revoke-credential','--json',json.dumps({'credential_id':c['credential_id']})]; out=json.loads(subprocess.check_output(cmd,env=env)); self.assertEqual(out['state'],'revoked')
