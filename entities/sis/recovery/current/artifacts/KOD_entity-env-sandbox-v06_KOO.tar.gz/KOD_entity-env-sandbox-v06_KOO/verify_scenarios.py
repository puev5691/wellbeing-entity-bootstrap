from __future__ import annotations
import json, tempfile
from pathlib import Path
from entity_env.core import CoordinationService, PilotError
ROOT=Path(__file__).resolve().parent

def setup(base):
    s=CoordinationService(base/'pilot.sqlite3',ROOT/'schema.sql',base/'file_field')
    for e in ('ent:KOO','ent:KOD'): s.register_entity(e)
    kod=s.register_instance('ent:KOD','worker'); koo=s.register_instance('ent:KOO','worker')
    auth={}
    for holder,action,scope,kind,ref in [
      ('ent:KOO','task.create','entity:ent:KOD','approved_process','pilot-process:v1'),
      ('ent:KOO','task.assign','task:*','approved_process','pilot-process:v1'),
      ('ent:KOD','assignment.accept','task:*','approved_process','pilot-process:v1'),
      ('ent:KOD','artifact.publish','task:*','approved_process','pilot-process:v1'),
      ('ent:KOD','artifact.authoritative_commit','artifact:*','operator','operator-decision:pilot-impl'),
      ('ent:KOD','route.dispatch','entity:ent:KOO','approved_process','pilot-process:v1'),
      ('ent:KOO','result.accept','task:*','approved_process','pilot-process:v1'),
      ('ent:KOO','writer.grant','entity-current-state:ent:KOD','operator','operator-decision:pilot-impl')]:
        auth[action]=s.add_authority(holder,kind,ref,action,scope)
    return s,kod,koo,auth

def task(s,kod,p):
    r=s.create_request('ent:KOO','ent:KOD','produce artifact','pilot',p+':req')
    t=s.create_task('ent:KOD','ent:KOO',r,'accepted-result',True,'ent:KOO',p+':task')
    a=s.assign(t,'ent:KOD',kod,'ent:KOO',p+':assign'); s.accept_assignment(a,'ent:KOD',kod,p+':aa')
    return r,t,a

out={'schema':'entity-env-pilot-scenario-report-v1','time_source':'unknown','scenarios':{}}
with tempfile.TemporaryDirectory() as td:
    s,kod,koo,auth=setup(Path(td)); r,t,a=task(s,kod,'A')
    art,av=s.publish_artifact(t,'ent:KOD',kod,b'pilot-A','ent:KOD','A:pub'); route=s.create_route('artifact_version',av,'ent:KOD','ent:KOO','A:route'); s.dispatch_route(route,'tm:A'); rec=s.receive_route(route,'ent:KOO','A:rec'); acc=s.accept_and_close(t,rec['receipt_id'],'ent:KOO','A:acc')
    with s.connect() as c:
        ts=c.execute('select task_state from tasks where task_id=?',(t,)).fetchone()[0]; rs=c.execute('select route_state from routes where route_id=?',(route,)).fetchone()[0]
    out['scenarios']['A']={'status':'pass','request_id':r,'task_id':t,'assignment_id':a,'artifact_id':art,'artifact_version_id':av,'route_id':route,'receipt_id':rec['receipt_id'],'acceptance_id':acc,'task_state':ts,'route_state':rs}
with tempfile.TemporaryDirectory() as td:
    s,kod,_,_=setup(Path(td)); _,t,_=task(s,kod,'B'); _,av=s.publish_artifact(t,'ent:KOD',kod,b'V1','ent:KOD','B:pub'); route=s.create_route('artifact_version',av,'ent:KOD','ent:KOO','B:route'); s.dispatch_route(route,'tm:B'); bad=Path(td)/'bad'; bad.write_bytes(b'V2')
    code=None
    try:s.receive_route(route,'ent:KOO','B:rec',str(bad))
    except PilotError as e:code=e.code
    with s.connect() as c: counts={'successful_receipts':c.execute("select count(*) from receipts where route_id=? and verification_result='verified'",(route,)).fetchone()[0],'acceptances':c.execute('select count(*) from acceptances where task_id=?',(t,)).fetchone()[0],'task_state':c.execute('select task_state from tasks where task_id=?',(t,)).fetchone()[0]}
    out['scenarios']['B']={'status':'pass','failure':code,**counts}
with tempfile.TemporaryDirectory() as td:
    s,kod,_,_=setup(Path(td)); _,t,_=task(s,kod,'C'); art,_=s.publish_artifact(t,'ent:KOD',kod,b'candidate','ent:KOD','C:pub')
    with s.connect() as c: before=dict(c.execute('select authoritative,row_version,artifact_currentness from artifacts where artifact_id=?',(art,)).fetchone())
    code=sub=None
    try:s.authoritative_commit(art,'ent:KOD',kod,None,None,before['row_version'],'C:commit')
    except PilotError as e:code,sub=e.code,e.subcode
    with s.connect() as c: after=dict(c.execute('select authoritative,row_version,artifact_currentness from artifacts where artifact_id=?',(art,)).fetchone())
    out['scenarios']['C']={'status':'pass','failure':code,'subcode':sub,'before':before,'after':after}
with tempfile.TemporaryDirectory() as td:
    s,kod,_,auth=setup(Path(td)); g1,_=s.grant_writer('ent:KOD',kod,'entity-current-state:ent:KOD','ent:KOO',auth['writer.grant'],'e1'); other=s.register_instance('ent:KOD','worker'); code=None
    try:s.grant_writer('ent:KOD',other,'entity-current-state:ent:KOD','ent:KOO',auth['writer.grant'],'e2')
    except PilotError as e:code=e.code
    with s.connect() as c: active=[x[0] for x in c.execute("select writer_grant_id from writer_grants where state='active'")]
    out['scenarios']['D']={'status':'pass','failure':code,'first_grant':g1,'active_grants':active}
with tempfile.TemporaryDirectory() as td:
    s,_,_,_=setup(Path(td)); code=None
    try:s.create_route('artifact_version','av:missing','ent:KOD','ent:KOO','E:route')
    except PilotError as e:code=e.code
    with s.connect() as c: rc=c.execute('select count(*) from routes').fetchone()[0]; oc=c.execute('select count(*) from outbox').fetchone()[0]
    out['scenarios']['E']={'status':'pass','failure':code,'routes_created':rc,'outbox_created':oc}
with tempfile.TemporaryDirectory() as td:
    s,kod,_,_=setup(Path(td)); r1=s.create_request('ent:KOO','ent:KOD','x','pilot','F:req'); r2=s.create_request('ent:KOO','ent:KOD','x','pilot','F:req'); t1=s.create_task('ent:KOD','ent:KOO',r1,'accepted-result',True,'ent:KOO','F:task'); t2=s.create_task('ent:KOD','ent:KOO',r1,'accepted-result',True,'ent:KOO','F:task'); a=s.assign(t1,'ent:KOD',kod,'ent:KOO','F:a'); s.accept_assignment(a,'ent:KOD',kod,'F:aa'); _,av=s.publish_artifact(t1,'ent:KOD',kod,b'idem','ent:KOD','F:pub'); q1=s.create_route('artifact_version',av,'ent:KOD','ent:KOO','F:route'); q2=s.create_route('artifact_version',av,'ent:KOD','ent:KOO','F:route'); s.dispatch_route(q1,'tm:F:1'); s.dispatch_route(q1,'tm:F:2'); z1=s.receive_route(q1,'ent:KOO','F:rec'); z2=s.receive_route(q1,'ent:KOO','F:rec')
    with s.connect() as c: attempts=c.execute('select attempt_count from outbox where route_id=?',(q1,)).fetchone()[0]
    out['scenarios']['F']={'status':'pass','same_request':r1==r2,'same_task':t1==t2,'same_route':q1==q2,'same_receipt':z1['receipt_id']==z2['receipt_id'],'transport_attempts':attempts}

(ROOT/'reports'/'scenario-report.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=False,indent=2))
