from __future__ import annotations
import json, threading, uuid
from urllib.parse import urlparse,parse_qs
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from .sandbox import SandboxError
class Handler(BaseHTTPRequestHandler):
 service=None
 def log_message(self,*a): pass
 def _token(self):
  h=self.headers.get('Authorization',''); return h[7:] if h.startswith('Bearer ') else ''
 def _principal(self): return self.service.authenticate(self._token())
 def _instance_actor(self):
  p=self._principal()
  if p['principal_kind']!='instance': raise SandboxError('missing_authority','instance_required')
  ent=self.service._active_instance(p['principal_ref']); return p['principal_ref'],ent
 def _body(self):
  n=int(self.headers.get('Content-Length','0')); return json.loads(self.rfile.read(n) or b'{}')
 def _json(self,code,obj):
  b=json.dumps(obj,default=str).encode(); self.send_response(code); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
 def _error(self,e): self._json(403 if e.code in ('missing_authority','stale_instance') else 409,{'error':e.code,'subcode':e.subcode})
 def _log(self,op,res,principal=None): self.service._log(op,res,self.headers.get('X-Correlation-ID') or uuid.uuid4().hex,principal)
 def do_GET(self):
  op='GET '+self.path
  try:
   if self.path=='/health/live': return self._json(200,{'live':True})
   if self.path=='/health/ready': return self._json(200,self.service.health())
   if self.path.startswith('/files/v1/sha256/'):
    d=self.path.rsplit('/',1)[-1]; data=self.service.protected_fetch(d,self._token()); self._log(op,'allowed'); self.send_response(200); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
   inst,actor=self._instance_actor(); u=urlparse(self.path); path=u.path
   if path.startswith('/api/v1/recovery/'):
    ent=path.rsplit('/',1)[-1]; out=self.service.read_recovery(actor,ent)
   elif path.startswith('/api/v1/tasks/'):
    out=self.service.read_task(actor,path.rsplit('/',1)[-1])
   elif path.startswith('/api/v1/routes/'):
    out=self.service.read_route(actor,path.rsplit('/',1)[-1])
   elif path=='/api/v1/inbox': out=self.service.poll_inbox(actor)
   elif path=='/api/v1/audit': out=self.service.read_audit(actor,int(parse_qs(u.query).get('limit',['100'])[0]))
   elif path=='/api/v1/state': out=self.service.read_recovery(actor,parse_qs(u.query).get('entity_id',[actor])[0])
   else:return self._json(404,{'error':'not_found'})
   self._log(op,'allowed',inst); return self._json(200,out)
  except SandboxError as e:self._log(op,e.code); self._error(e)
 def do_PUT(self):
  op='upload.bytes'
  try:
   inst,actor=self._instance_actor()
   if self.path.startswith('/api/v1/artifacts/uploads/'):
    up=self.path.rsplit('/',1)[-1]; n=int(self.headers.get('Content-Length','0')); self.service.upload_bytes(up,self.rfile.read(n),inst,actor); self._log(op,'allowed',inst); return self._json(200,{'upload_id':up,'state':'uploaded'})
   self._json(404,{'error':'not_found'})
  except SandboxError as e:self._log(op,e.code); self._error(e)
 def do_POST(self):
  op='POST '+self.path
  try:
   inst,actor=self._instance_actor(); b=self._body(); key=b.get('idempotency_key',''); p=self.path
   if p=='/api/v1/artifacts/upload-init': out={'upload_id':self.service.upload_init(b['task_id'],actor,inst,key)}
   elif p.endswith('/publish') and p.startswith('/api/v1/artifacts/uploads/'):
    out=self.service.publish_upload(p.split('/')[-2],key,inst,actor)
   elif p.startswith('/api/v1/commands/'):
    cmd=p.rsplit('/',1)[-1]; op=cmd
    if cmd=='request.create': out={'request_id':self.service.create_request(actor,b['target_entity_id'],b['requested_outcome'],b.get('scope',''),key)}
    elif cmd=='task.create': out={'task_id':self.service.create_task(b['owner_entity_id'],actor,b['origin_request_id'],b['terminal_criterion'],int(b.get('required_acceptance',1)),actor,key)}
    elif cmd=='assignment.create': out={'assignment_id':self.service.assign(b['task_id'],b['assignee_entity_id'],b.get('assignee_instance_id'),actor,key)}
    elif cmd=='assignment.accept': out={'assignment_id':self.service.accept_assignment(b['assignment_id'],actor,inst,key)}
    elif cmd=='route.create': out={'route_id':self.service.create_route(b['payload_type'],b['payload_id'],actor,b['recipient_entity_id'],key)}
    elif cmd=='route.dispatch': out=self.service.dispatch_route(b['route_id'],b.get('transport_message_id'),True,inst,actor,key)
    elif cmd=='receipt.register': out=self.service.receive_route_external(b['route_id'],actor,inst,key,b.get('received_sha256'))
    elif cmd=='result.accept': out={'acceptance_id':self.service.accept_and_close(b['task_id'],b['receipt_id'],actor,key)}
    elif cmd=='writer.grant': out=dict(zip(('grant_id','generation'),self.service.grant_writer(b['entity_id'],b['instance_id'],b['scope'],actor,b['authority_ref'],b['evidence_ref'],idempotency_key=key)))
    elif cmd=='writer.release': out={'grant_id':self.service.writer_release(b['grant_id'],actor,b['authority_ref'],key)}
    elif cmd=='writer.handoff': out=dict(zip(('grant_id','generation'),self.service.writer_handoff(b['grant_id'],b['new_instance_id'],actor,b['authority_ref'],b['evidence_ref'],key)))
    elif cmd=='writer.failover': out=dict(zip(('grant_id','generation'),self.service.writer_failover(b['grant_id'],b['new_instance_id'],actor,b['authority_ref'],b['evidence_ref'],key)))
    elif cmd=='artifact.authoritative_commit': out={'result':self.service.authoritative_commit(b['artifact_id'],actor,inst,b['writer_grant_ref'],int(b['writer_generation']),int(b['expected_version']),key)}
    elif cmd=='entity.register': out={'entity_id':self.service.register_entity_operational(b['entity_id'],actor,b['authority_ref'],key)}
    elif cmd=='instance.register': out={'instance_id':self.service.register_instance_operational(b['entity_id'],actor,b['authority_ref'],b.get('instance_id'),key)}
    elif cmd=='instance.activate': out={'instance_id':self.service.activate_instance(b['instance_id'],actor,b['authority_ref'],b['basis_ref'],key,inst)}
    else:return self._json(404,{'error':'unsupported_operation'})
   else:return self._json(404,{'error':'not_found'})
   self._log(op,'allowed',inst); self._json(200,out)
  except (SandboxError,KeyError) as e:
   if isinstance(e,SandboxError): self._log(op,e.code); self._error(e)
   else:self._json(400,{'error':'bad_request','field':str(e)})
def serve(service,host='127.0.0.1',port=0):
 cls=type('SandboxHandler',(Handler,),{}); cls.service=service; srv=ThreadingHTTPServer((host,port),cls); t=threading.Thread(target=srv.serve_forever,daemon=True); t.start(); return srv,t
