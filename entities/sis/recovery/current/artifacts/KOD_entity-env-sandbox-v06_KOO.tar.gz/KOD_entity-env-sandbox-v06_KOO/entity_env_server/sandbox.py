from __future__ import annotations
import hashlib, hmac, json, os, secrets, shutil, sqlite3, threading, uuid, time, fcntl
from pathlib import Path
from .pilot_core import CoordinationService, PilotError, oid

SandboxError = PilotError

def fp(obj):
    return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':')).encode()).hexdigest()

class ClosingConnection(sqlite3.Connection):
    def __exit__(self, exc_type, exc, tb):
        try:
            return super().__exit__(exc_type, exc, tb)
        finally:
            self.close()

class SandboxService(CoordinationService):
    def __init__(self, root: Path):
        self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True)
        self.state=self.root/'state'; self.files_root=self.root/'files'; self.staging=self.files_root/'staging'; self.objects=self.files_root/'objects'/'sha256'
        self.recovery=self.root/'recovery'/'exports'; self.backups=self.root/'backups'; self.secrets_root=self.root/'secrets'
        for p in (self.state,self.staging,self.objects,self.recovery,self.backups,self.secrets_root): p.mkdir(parents=True,exist_ok=True)
        schema=Path(__file__).resolve().parents[1]/'migrations'/'001_pilot.sql'
        super().__init__(self.state/'coordination.sqlite3', schema, self.staging)
        self._owner_fd=open(self.root/'.coordinator.lock','a+')
        self._owner_locked=False
        try:
            fcntl.flock(self._owner_fd.fileno(), fcntl.LOCK_EX|fcntl.LOCK_NB); self._owner_locked=True
        except BlockingIOError:
            pass
        if self._owner_locked: self._run_migrations()
        self._write_ready=self._owner_locked
        self._mutation_lock=threading.RLock()
        self.log_path=self.root/'operations.jsonl'
        self._schema_ok=self._validate_schema()
    def connect(self):
        c=sqlite3.connect(self.db_path, factory=ClosingConnection); c.row_factory=sqlite3.Row; c.execute('PRAGMA foreign_keys=ON'); c.execute('PRAGMA busy_timeout=3000'); return c
    def _run_migrations(self):
        known={1:Path(__file__).resolve().parents[1]/'migrations'/'001_pilot.sql',2:Path(__file__).resolve().parents[1]/'migrations'/'002_sandbox_v02.sql'}
        with self.connect() as c:
            r=c.execute("SELECT value FROM sandbox_meta WHERE key='schema_version'").fetchone(); current=int(r[0]) if r else 0
            if current>max(known): return
            for v in range(current+1,max(known)+1):
                sql=known[v].read_text(); c.executescript(sql)
                checksum=hashlib.sha256(sql.encode()).hexdigest()
                c.execute('INSERT OR REPLACE INTO migration_history(version,checksum) VALUES(?,?)',(v,checksum))
            # Base pilot schema is migration 001; migration_history itself arrives in 002.
            if c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='migration_history'").fetchone():
                sql1=known[1].read_text(); c.execute('INSERT OR IGNORE INTO migration_history(version,checksum) VALUES(1,?)',(hashlib.sha256(sql1.encode()).hexdigest(),))
    def _validate_schema(self):
        try:
            with self.connect() as c:
                r=c.execute("SELECT value FROM sandbox_meta WHERE key='schema_version'").fetchone()
                
                if not (r and int(r[0]) == 2): return False
                known={1:Path(__file__).resolve().parents[1]/'migrations'/'001_pilot.sql',2:Path(__file__).resolve().parents[1]/'migrations'/'002_sandbox_v02.sql'}
                for v,path in known.items():
                    h=c.execute('SELECT checksum FROM migration_history WHERE version=?',(v,)).fetchone()
                    if not h or h[0]!=hashlib.sha256(path.read_text().encode()).hexdigest(): return False
                return True
        except Exception:
            return False
    def _log(self, operation, result, correlation_id=None, principal_ref=None):
        rec={'time':time.time(),'correlation_id':correlation_id or uuid.uuid4().hex,'operation':operation,'result':result,'principal_ref':principal_ref}
        with self.log_path.open('a',encoding='utf-8') as f: f.write(json.dumps(rec,sort_keys=True)+'\n')
    def _active_instance(self, instance_id):
        with self.connect() as c: r=c.execute('SELECT entity_id,lifecycle FROM instances WHERE instance_id=?',(instance_id,)).fetchone()
        if not r or r['lifecycle']!='active': raise SandboxError('stale_instance','instance_not_active')
        return r['entity_id']
    def _upload_owner(self, c, upload_id, caller_instance, caller_entity):
        r=c.execute('SELECT * FROM upload_intents WHERE upload_id=?',(upload_id,)).fetchone()
        if not r: raise SandboxError('artifact_missing','upload missing')
        if r['instance_id']!=caller_instance or r['actor_entity_id']!=caller_entity:
            raise SandboxError('missing_authority','upload_owner_mismatch','upload_owner_mismatch')
        self._active_instance(caller_instance)
        return r
    def health(self):
        try:
            with self.connect() as c:
                c.execute('SELECT 1').fetchone()
                r=c.execute("SELECT value FROM sandbox_meta WHERE key='schema_version'").fetchone()
                schema_ok=bool(r and int(r[0])==2) and self._validate_schema()
            file_ok=self.objects.exists() and os.access(self.objects,os.W_OK|os.R_OK)
            disk_ok=shutil.disk_usage(self.root).free > 1024*1024
            return {'live':True,'ready':bool(self._write_ready and schema_ok and file_ok and disk_ok),'schema_version':int(r[0]) if r else None,'schema_ok':schema_ok,'file_field_ok':file_ok,'disk_ok':disk_ok}
        except Exception: return {'live':True,'ready':False,'schema_version':None,'schema_ok':False,'file_field_ok':False,'disk_ok':False}
    def _require_ready(self):
        if not self.health()['ready']: raise SandboxError('coordination_field_unavailable','service not ready')
    def create_principal(self, kind, ref):
        if kind not in ('instance','operator_admin'): raise SandboxError('conflict','bad principal kind')
        with self.connect() as c:
            r=c.execute('SELECT principal_id FROM principals WHERE principal_kind=? AND principal_ref=?',(kind,ref)).fetchone()
            if r: return r['principal_id']
            pid='principal:'+str(uuid.uuid4()); c.execute('INSERT INTO principals VALUES(?,?,?,?)',(pid,kind,ref,'active')); return pid
    def close(self):
        if getattr(self,'_owner_locked',False):
            fcntl.flock(self._owner_fd.fileno(),fcntl.LOCK_UN); self._owner_locked=False
        if getattr(self,'_owner_fd',None): self._owner_fd.close()
    def rotate_credential(self, principal_id, old_credential_id=None):
        new=self.issue_credential(principal_id)
        if old_credential_id: self.revoke_credential(old_credential_id)
        return new
    @staticmethod
    def _token_hash(token): return hashlib.sha256(token.encode()).hexdigest()
    def issue_credential(self, principal_id):
        token=secrets.token_hex(32); cid='cred:'+str(uuid.uuid4())
        with self.connect() as c: c.execute('INSERT INTO credentials VALUES(?,?,?,?,?)',(cid,principal_id,self._token_hash(token),'active',1))
        return {'credential_id':cid,'token':token}
    def authenticate(self, token):
        th=self._token_hash(token)
        with self.connect() as c:
            r=c.execute('SELECT p.principal_id,p.principal_kind,p.principal_ref,c.credential_id FROM credentials c JOIN principals p ON p.principal_id=c.principal_id WHERE c.token_hash=? AND c.state="active" AND p.state="active"',(th,)).fetchone()
        if not r: raise SandboxError('missing_authority','authentication_failed')
        return dict(r)
    def revoke_credential(self, credential_id):
        with self.connect() as c: c.execute('UPDATE credentials SET state="revoked" WHERE credential_id=?',(credential_id,))
    def _admin_principal(self, token):
        if not self._owner_locked: raise SandboxError('coordination_field_unavailable','coordinator_owner_lock_required')
        p=self.authenticate(token)
        if p['principal_kind']!='operator_admin': raise SandboxError('missing_authority','admin_boundary_required')
        return p
    def bootstrap_operator_admin(self, evidence_path, issuer_ref='OPR'):
        with self.connect() as c:
            st=c.execute('SELECT initialized FROM bootstrap_state WHERE singleton=1').fetchone()
            if st and st['initialized']: raise SandboxError('conflict','bootstrap_already_initialized')
        ev=self.register_evidence('operator',issuer_ref,evidence_path,{'evidence_kind':'operator_bootstrap','holder_entity_id':None,'action':'sandbox.bootstrap.admin','object_scope':'sandbox:local'})
        pid=self.create_principal('operator_admin','local-bootstrap'); cred=self.issue_credential(pid)
        with self.connect() as c: c.execute('UPDATE bootstrap_state SET initialized=1 WHERE singleton=1')
        return {**cred,**ev,'principal_id':pid}
    def bootstrap_first_entity(self, token, entity_id, evidence_path, issuer_ref='OPR'):
        self._admin_principal(token); ev=self.register_evidence('operator',issuer_ref,evidence_path,{'evidence_kind':'project_authority','holder_entity_id':entity_id,'action':'entity.register','object_scope':f'entity:{entity_id}'})
        with self.connect() as c:
            if c.execute('SELECT COUNT(*) FROM entities').fetchone()[0]!=0: raise SandboxError('conflict','first_entity_bootstrap_closed')
            c.execute('INSERT INTO entities(entity_id,display_name,state,row_version) VALUES(?,?,"active",1)',(entity_id,entity_id))
            ar=oid('auth'); c.execute('INSERT INTO authority_refs(authority_ref,holder_entity_id,issuer_kind,issuer_ref,action,object_scope,evidence_locator,evidence_version) VALUES(?,?,?,?,?,?,?,?)',(ar,entity_id,'operator',issuer_ref,'entity.register','entity:*',ev['locator'],ev['evidence_version']))
            self._audit(c,obj_type='entity',obj_id=entity_id,prev_v=None,prev_s=None,new_v=1,new_s='active',actor_entity=entity_id,actor_instance=None,action='bootstrap.entity.register',authority=ar,evidence=[ev['evidence_ref']],result='allowed',ikey='bootstrap:'+entity_id)
        return {'entity_id':entity_id,'authority_ref':ar,**ev}
    def admin_project_action(self, token, authority_ref=None, action=None, scope=None, holder=None):
        self._admin_principal(token)
        if not authority_ref or not action or not scope or not holder: raise SandboxError('missing_authority','project_authority_required')
        with self.connect() as c: self.authority_ref(c,authority_ref,holder,action,scope)
        return True
    @staticmethod
    def _load_structured_evidence(evidence_path):
        ep=Path(evidence_path)
        if not ep.is_file(): raise SandboxError('missing_authority','evidence_missing')
        raw=ep.read_bytes()
        try:
            obj=json.loads(raw.decode('utf-8'))
        except Exception:
            raise SandboxError('missing_authority','authority_evidence_invalid_format')
        required={'schema_version','evidence_kind','issuer_kind','issuer_ref','holder_entity_id','action','object_scope'}
        if not isinstance(obj,dict) or not required.issubset(obj): raise SandboxError('missing_authority','authority_evidence_invalid_schema')
        if obj['schema_version']!='authority-evidence/v1' or obj['evidence_kind'] not in ('project_authority','operator_bootstrap'):
            raise SandboxError('missing_authority','authority_evidence_invalid_schema')
        if obj['issuer_kind'] not in ('operator','approved_process') or not isinstance(obj['issuer_ref'],str) or not obj['issuer_ref']:
            raise SandboxError('missing_authority','authority_evidence_invalid_issuer')
        canonical=(json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False)+'\n').encode('utf-8')
        if raw != canonical: raise SandboxError('missing_authority','authority_evidence_not_canonical')
        digest=hashlib.sha256(raw).hexdigest()
        return ep,obj,digest
    def register_evidence(self, issuer_kind, issuer_ref, evidence_path, expected=None):
        ep,obj,digest=self._load_structured_evidence(evidence_path)
        if obj['issuer_kind']!=issuer_kind or obj['issuer_ref']!=issuer_ref:
            raise SandboxError('missing_authority','authority_evidence_semantic_mismatch')
        if expected:
            for k,v in expected.items():
                if obj.get(k)!=v: raise SandboxError('missing_authority','authority_evidence_semantic_mismatch')
        er='evidence:sha256:'+digest
        with self.connect() as c: c.execute('INSERT OR IGNORE INTO evidence_registry VALUES(?,?,?,?,?,"verified")',(er,issuer_kind,issuer_ref,str(ep.resolve()),digest))
        return {'evidence_ref':er,'evidence_version':'sha256:'+digest,'locator':str(ep.resolve()),'evidence':obj}
    def admin_import_authority(self, token, holder, issuer_kind, issuer_ref, action, scope, evidence_version, ref=None, evidence_path=None):
        self._admin_principal(token)
        expected={'evidence_kind':'project_authority','holder_entity_id':holder,'action':action,'object_scope':scope}
        ev=self.register_evidence(issuer_kind,issuer_ref,evidence_path,expected) if evidence_path else None
        if not ev or ev['evidence_version']!=evidence_version: raise SandboxError('missing_authority','evidence_version_mismatch')
        with self.connect() as c:
            if not c.execute('SELECT 1 FROM entities WHERE entity_id=?',(holder,)).fetchone(): raise SandboxError('missing_authority','holder_entity_missing')
        ar=self.add_authority(holder,issuer_kind,issuer_ref,action,scope,evidence_version,ref)
        with self.connect() as c: c.execute('UPDATE authority_refs SET evidence_locator=? WHERE authority_ref=?',(ev['locator'],ar))
        return ar
    def admin_issue_instance_credential(self, token, instance_id):
        self._admin_principal(token); self._active_instance(instance_id)
        return self.issue_credential(self.create_principal('instance',instance_id))
    def admin_read_recovery(self, token, target_entity, authority_ref):
        self._admin_principal(token)
        with self.connect() as c: self.authority_ref(c,authority_ref,target_entity,'recovery.read',f'entity:{target_entity}')
        return self.recovery_projection(target_entity)
    def _authority_holder(self, authority_ref):
        with self.connect() as c:
            r=c.execute("SELECT holder_entity_id FROM authority_refs WHERE authority_ref=? AND state='active'",(authority_ref,)).fetchone()
        if not r: raise SandboxError('missing_authority','authority_ref_mismatch')
        return r['holder_entity_id']
    def admin_register_entity(self, token, entity_id, authority_ref, idempotency_key):
        self._admin_principal(token); actor=self._authority_holder(authority_ref)
        return self.register_entity_operational(entity_id,actor,authority_ref,idempotency_key)
    def admin_register_instance(self, token, entity_id, authority_ref, idempotency_key, instance_id=None):
        self._admin_principal(token); actor=self._authority_holder(authority_ref)
        return self.register_instance_operational(entity_id,actor,authority_ref,instance_id,idempotency_key)
    def admin_activate_instance(self, token, instance_id, authority_ref, basis_ref, idempotency_key):
        self._admin_principal(token); actor=self._authority_holder(authority_ref)
        return self.activate_instance(instance_id,actor,authority_ref,basis_ref,idempotency_key,None)
    def register_entity_operational(self, entity_id, actor_entity, authority_ref):
        with self.connect() as c: self.authority_ref(c,authority_ref,actor_entity,'entity.register',f'entity:{entity_id}')
        self.register_entity(entity_id); return entity_id
    def register_instance_operational(self, entity_id, actor_entity, authority_ref, instance_id=None):
        with self.connect() as c: self.authority_ref(c,authority_ref,actor_entity,'instance.register',f'entity:{entity_id}')
        return self.register_instance(entity_id,work_mode='worker',lifecycle='initiating',instance_id=instance_id)
    def activate_instance(self, instance_id, actor_entity, authority_ref, basis_ref, idempotency_key=None, actor_instance=None):
        key=idempotency_key or ('instance.activate:'+instance_id)
        sem={'instance_id':instance_id,'actor':actor_entity,'authority_ref':authority_ref,'basis_ref':basis_ref}
        with self.connect() as c:
            old=self._command_existing(c,'instance.activate',key,sem)
            if old: return old['instance_id']
            r=c.execute('SELECT * FROM instances WHERE instance_id=?',(instance_id,)).fetchone()
            if not r or r['lifecycle']!='initiating': raise SandboxError('stale_instance','not initiating')
            self.authority_ref(c,authority_ref,actor_entity,'instance.activate',f'entity:{r["entity_id"]}')
            if not basis_ref: raise SandboxError('missing_authority','initiation_recovery_basis_required')
            b=c.execute("SELECT * FROM authority_refs WHERE authority_ref=? AND state='active' AND action='initiation.recovery_basis' AND holder_entity_id=?",(basis_ref,r['entity_id'])).fetchone()
            if not b: raise SandboxError('missing_authority','unverifiable_initiation_recovery_basis')
            c.execute('UPDATE instances SET lifecycle="active",row_version=row_version+1 WHERE instance_id=?',(instance_id,))
            self._audit(c,obj_type='instance',obj_id=instance_id,prev_v=r['row_version'],prev_s='initiating',new_v=r['row_version']+1,new_s='active',actor_entity=actor_entity,actor_instance=actor_instance,action='instance.activate',authority=authority_ref,evidence=[basis_ref],result='allowed',ikey=self._audit_key('instance.activate',key))
            self._command_store(c,'instance.activate',key,sem,{'instance_id':instance_id})
        return instance_id
    def upload_init(self, task_id, actor_entity, instance_id, idempotency_key):
        self._require_ready(); sem={'task':task_id,'actor':actor_entity,'instance':instance_id}; sf=fp(sem)
        with self.connect() as c:
            old=c.execute('SELECT * FROM upload_intents WHERE actor_entity_id=? AND idempotency_key=?',(actor_entity,idempotency_key)).fetchone()
            if old:
                if old['semantic_fingerprint']!=sf: raise SandboxError('conflict','idempotency_semantic_mismatch','idempotency_semantic_mismatch')
                return old['upload_id']
            iid=c.execute('SELECT entity_id,lifecycle FROM instances WHERE instance_id=?',(instance_id,)).fetchone()
            if not iid or iid['entity_id']!=actor_entity or iid['lifecycle']!='active': raise SandboxError('stale_instance')
            up='upload:'+str(uuid.uuid4()); path=self.staging/(up.replace(':','_')+'.bin')
            c.execute('INSERT INTO upload_intents VALUES(?,?,?,?,?,?,?,?)',(up,actor_entity,task_id,instance_id,str(path),'initiated',sf,idempotency_key))
        return up
    def upload_bytes(self, upload_id, data:bytes, caller_instance, caller_entity):
        if not caller_instance or not caller_entity: raise SandboxError('missing_authority','verified_caller_required','verified_caller_required')
        with self.connect() as c:
            r=self._upload_owner(c,upload_id,caller_instance,caller_entity)
            if not r: raise SandboxError('artifact_missing','upload missing')
            if r['state']=='published': raise SandboxError('conflict','upload_already_published','upload_already_published')
            Path(r['staging_path']).write_bytes(data); c.execute('UPDATE upload_intents SET state="uploaded" WHERE upload_id=?',(upload_id,))
        return len(data)
    def _finalize_external_publish(self, c, r, caller_instance, caller_entity, idempotency_key, semantic, digest, data, obj):
        task=c.execute('SELECT * FROM tasks WHERE task_id=?',(r['task_id'],)).fetchone()
        if not task or task['task_state']!='active': raise SandboxError('conflict','task_not_active')
        accepted=c.execute("SELECT * FROM assignments WHERE task_id=? AND assignment_state='accepted' ORDER BY rowid DESC LIMIT 1",(r['task_id'],)).fetchone()
        if not accepted or accepted['assignee_entity_id']!=caller_entity or (accepted['assignee_instance_id'] and accepted['assignee_instance_id']!=caller_instance): raise SandboxError('out_of_role','assignment_producer_mismatch')
        auth=self.authority(c,caller_entity,'artifact.publish',f"task:{r['task_id']}")
        aid=oid('artifact'); vid=oid('av')
        c.execute("INSERT INTO artifacts VALUES (?,?,?,?,?,?,0,1)",(aid,caller_entity,r['task_id'],'task-result','candidate','not_normative'))
        c.execute("INSERT INTO artifact_versions VALUES (?,?,?,?,?,'published',?)",(vid,aid,digest,len(data),str(obj),caller_instance))
        self._audit(c,obj_type='artifact',obj_id=aid,prev_v=None,prev_s=None,new_v=1,new_s='candidate',actor_entity=caller_entity,actor_instance=caller_instance,action='artifact.publish',authority=auth,evidence=[vid],result='allowed',ikey=self._audit_key('sandbox.artifact.publish',idempotency_key))
        c.execute('UPDATE upload_intents SET state="published" WHERE upload_id=?',(r['upload_id'],))
        result={'artifact_id':aid,'artifact_version_id':vid,'sha256':digest,'locator':f'/files/v1/sha256/{digest}'}
        self._command_store(c,'sandbox.artifact.publish',idempotency_key,semantic,result)
        return result
    def publish_upload(self, upload_id, idempotency_key, caller_instance, caller_entity):
        self._require_ready()
        if not caller_instance or not caller_entity: raise SandboxError('missing_authority','verified_caller_required','verified_caller_required')
        with self.connect() as c:
            r=self._upload_owner(c,upload_id,caller_instance,caller_entity)
            if r['state']=='published':
                old=c.execute("SELECT result_json FROM command_idempotency WHERE operation='sandbox.artifact.publish' AND idempotency_key=?",(idempotency_key,)).fetchone()
                if old: return json.loads(old[0])
                raise SandboxError('conflict','upload_already_published','upload_already_published')
            if r['state']!='uploaded': raise SandboxError('artifact_missing','upload not ready')
            path=Path(r['staging_path']); data=path.read_bytes() if path.exists() else None
            if data is None: raise SandboxError('artifact_missing')
            digest=hashlib.sha256(data).hexdigest(); semantic={'upload_id':upload_id,'upload_semantic_fingerprint':r['semantic_fingerprint'],'sha256':digest}
            old=self._command_existing(c,'sandbox.artifact.publish',idempotency_key,semantic)
            if old: return old
        obj=self.objects/digest[:2]/digest[2:4]/digest; obj.parent.mkdir(parents=True,exist_ok=True)
        if not obj.exists():
            tmp=obj.with_suffix('.tmp-'+uuid.uuid4().hex); tmp.write_bytes(data); os.replace(tmp,obj)
        if hashlib.sha256(obj.read_bytes()).hexdigest()!=digest: raise SandboxError('version_mismatch')
        # One coordination finalization transaction after immutable object commit.
        with self.connect() as c:
            r=self._upload_owner(c,upload_id,caller_instance,caller_entity)
            old=self._command_existing(c,'sandbox.artifact.publish',idempotency_key,semantic)
            if old: return old
            result=self._finalize_external_publish(c,r,caller_instance,caller_entity,idempotency_key,semantic,digest,data,obj)
        path.unlink(missing_ok=True)
        return result
    def scan_orphans(self):
        with self.connect() as c: refs={x[0] for x in c.execute('SELECT sha256 FROM artifact_versions')}
        found=[]
        for p in self.objects.glob('*/*/*'):
            if p.is_file() and p.name not in refs: found.append(p.name)
        return sorted(found)
    def protected_fetch(self, digest, token):
        p=self.authenticate(token)
        if p['principal_kind']!='instance': raise SandboxError('missing_authority','instance_required')
        with self.connect() as c:
            inst=c.execute('SELECT entity_id,lifecycle FROM instances WHERE instance_id=?',(p['principal_ref'],)).fetchone()
            if not inst or inst['lifecycle']!='active': raise SandboxError('stale_instance','instance_not_active')
            ent=inst['entity_id']
            versions=c.execute('SELECT av.*,a.source_entity_id FROM artifact_versions av JOIN artifacts a ON a.artifact_id=av.artifact_id WHERE av.sha256=?',(digest,)).fetchall()
            if not versions: raise SandboxError('artifact_missing','artifact_missing')
            av=None
            for cand in versions:
                delivered=bool(c.execute("SELECT 1 FROM routes WHERE required_artifact_version_id=? AND recipient_entity_id=? AND route_state IN ('delivered','received')",(cand['artifact_version_id'],ent)).fetchone())
                if cand['source_entity_id']==ent or delivered:
                    av=cand; break
            if av is None: raise SandboxError('missing_authority','artifact_read_denied')
        try: data=Path(av['locator']).read_bytes()
        except (FileNotFoundError,OSError) as e: raise SandboxError('artifact_missing','file_field_unavailable','file_field_unavailable') from e
        if hashlib.sha256(data).hexdigest()!=digest: raise SandboxError('version_mismatch')
        return data
    def dispatch_route(self, route_id, transport_message_id=None, durable=True, caller_instance=None, caller_entity=None, idempotency_key=None):
        if not caller_instance or not caller_entity: raise SandboxError('missing_authority','verified_caller_required','verified_caller_required')
        verified_entity=self._active_instance(caller_instance)
        if verified_entity!=caller_entity: raise SandboxError('missing_authority','caller_identity_mismatch','caller_identity_mismatch')
        key=idempotency_key or ('route.dispatch:'+route_id+':'+str(transport_message_id or 'auto'))
        semantic={'route_id':route_id,'caller_instance':caller_instance,'caller_entity':caller_entity,'transport_message_id':transport_message_id,'durable':bool(durable)}
        with self.connect() as c:
            r=c.execute('SELECT * FROM routes WHERE route_id=?',(route_id,)).fetchone()
            if not r: raise SandboxError('unknown','route missing')
            if r['sender_entity_id']!=caller_entity: raise SandboxError('missing_authority','route_sender_mismatch','route_sender_mismatch')
            old=self._command_existing(c,'route.dispatch',key,semantic)
            if old is not None:return old
            if not durable:
                c.execute('UPDATE outbox SET attempt_count=attempt_count+1,dispatch_state="attempted" WHERE route_id=?',(route_id,))
                out={'route_id':route_id,'transport_message_id':transport_message_id,'delivered':False}; self._command_store(c,'route.dispatch',key,semantic,out); return out
            tm=transport_message_id or oid('tm')
            if r['route_state'] not in ('created','delivered','received'): raise SandboxError('conflict','invalid_route_state')
            if r['route_state']=='created':
                c.execute('INSERT INTO inbox VALUES (?,?,?,?,?,1)',(oid('inbox'),r['recipient_entity_id'],tm,route_id,'pending'))
                c.execute("UPDATE outbox SET dispatch_state='dispatched',attempt_count=attempt_count+1,row_version=row_version+1 WHERE route_id=?",(route_id,))
                c.execute("UPDATE routes SET route_state='delivered',row_version=row_version+1 WHERE route_id=?",(route_id,))
                self._audit(c,obj_type='route',obj_id=route_id,prev_v=r['row_version'],prev_s='created',new_v=r['row_version']+1,new_s='delivered',actor_entity=caller_entity,actor_instance=caller_instance,action='route.deliver',authority='not_required',evidence=[tm],result='allowed',ikey=self._audit_key('route.dispatch',key))
            out={'route_id':route_id,'transport_message_id':tm,'delivered':True}; self._command_store(c,'route.dispatch',key,semantic,out); return out
    def receive_route_external(self, route_id, recipient_entity, recipient_instance, idempotency_key, received_sha256):
        verified_entity=self._active_instance(recipient_instance)
        if verified_entity!=recipient_entity: raise SandboxError('missing_authority','caller_identity_mismatch','caller_identity_mismatch')
        with self.connect() as c:
            r=c.execute('SELECT * FROM routes WHERE route_id=?',(route_id,)).fetchone()
            if not r or r['recipient_entity_id']!=recipient_entity: raise SandboxError('unknown')
            av=c.execute('SELECT * FROM artifact_versions WHERE artifact_version_id=?',(r['required_artifact_version_id'],)).fetchone()
            if not received_sha256: raise SandboxError('conflict','recipient_version_evidence_required','recipient_version_evidence_required')
            if received_sha256!=av['sha256']: raise SandboxError('version_mismatch','received_digest_mismatch','received_digest_mismatch')
        return super().receive_route(route_id,recipient_entity,idempotency_key)
    def writer_release(self, grant_id, actor_entity, authority_ref):
        with self.connect() as c:
            g=c.execute('SELECT * FROM writer_grants WHERE writer_grant_id=?',(grant_id,)).fetchone()
            if not g or g['state']!='active': raise SandboxError('writer_conflict')
            self.authority_ref(c,authority_ref,actor_entity,'writer.release',g['scope'])
            c.execute('UPDATE writer_grants SET state="released",row_version=row_version+1 WHERE writer_grant_id=?',(grant_id,))
        return grant_id
    def writer_handoff(self, grant_id,new_instance,actor_entity,authority_ref,evidence_ref,idempotency_key):
        with self.connect() as c:
            g=c.execute('SELECT * FROM writer_grants WHERE writer_grant_id=?',(grant_id,)).fetchone()
            if not g or g['state']!='active': raise SandboxError('writer_conflict')
            self.authority_ref(c,authority_ref,actor_entity,'writer.handoff',g['scope'])
            ni=c.execute('SELECT entity_id,lifecycle FROM instances WHERE instance_id=?',(new_instance,)).fetchone()
            if not ni or ni['entity_id']!=g['entity_id'] or ni['lifecycle']!='active': raise SandboxError('stale_instance')
            c.execute('UPDATE writer_grants SET state="superseded",row_version=row_version+1 WHERE writer_grant_id=?',(grant_id,))
            ng=oid('writer_grant'); gen=g['generation']+1
            c.execute('INSERT INTO writer_grants VALUES(?,?,?,?,?,?,?,?,?)',(ng,g['entity_id'],new_instance,authority_ref,g['scope'],gen,'active',evidence_ref,1))
        return ng,gen
    def writer_failover(self, grant_id,new_instance,actor_entity,authority_ref,evidence_ref,idempotency_key):
        # same fencing transaction, but distinct required authority action
        with self.connect() as c:
            g=c.execute('SELECT * FROM writer_grants WHERE writer_grant_id=?',(grant_id,)).fetchone()
            if not g or g['state']!='active': raise SandboxError('writer_conflict')
            self.authority_ref(c,authority_ref,actor_entity,'writer.failover',g['scope'])
            ni=c.execute('SELECT entity_id,lifecycle FROM instances WHERE instance_id=?',(new_instance,)).fetchone()
            if not ni or ni['entity_id']!=g['entity_id'] or ni['lifecycle']!='active': raise SandboxError('stale_instance')
            c.execute('UPDATE writer_grants SET state="superseded",row_version=row_version+1 WHERE writer_grant_id=?',(grant_id,))
            ng=oid('writer_grant'); gen=g['generation']+1
            c.execute('INSERT INTO writer_grants VALUES(?,?,?,?,?,?,?,?,?)',(ng,g['entity_id'],new_instance,authority_ref,g['scope'],gen,'active',evidence_ref,1))
        return ng,gen
    def register_entity_operational(self, entity_id, actor_entity, authority_ref, idempotency_key=None):
        key=idempotency_key or ('entity.register:'+entity_id); sem={'entity_id':entity_id,'actor':actor_entity,'authority_ref':authority_ref}
        with self.connect() as c:
            old=self._command_existing(c,'entity.register',key,sem)
            if old: return old['entity_id']
            self.authority_ref(c,authority_ref,actor_entity,'entity.register',f'entity:{entity_id}')
            c.execute('INSERT INTO entities(entity_id,display_name,state,row_version) VALUES(?,?,?,1)',(entity_id,entity_id,'active'))
            self._audit(c,obj_type='entity',obj_id=entity_id,prev_v=None,prev_s=None,new_v=1,new_s='active',actor_entity=actor_entity,actor_instance=None,action='entity.register',authority=authority_ref,evidence=[],result='allowed',ikey=self._audit_key('entity.register',key))
            self._command_store(c,'entity.register',key,sem,{'entity_id':entity_id})
        return entity_id
    def register_instance_operational(self, entity_id, actor_entity, authority_ref, instance_id=None, idempotency_key=None):
        iid=instance_id or oid('inst'); key=idempotency_key or ('instance.register:'+iid); sem={'entity_id':entity_id,'actor':actor_entity,'authority_ref':authority_ref,'instance_id':iid}
        with self.connect() as c:
            old=self._command_existing(c,'instance.register',key,sem)
            if old:return old['instance_id']
            self.authority_ref(c,authority_ref,actor_entity,'instance.register',f'entity:{entity_id}')
            c.execute('INSERT INTO instances(instance_id,entity_id,lifecycle,work_mode,row_version) VALUES(?,?,?,?,1)',(iid,entity_id,'initiating','worker'))
            self._audit(c,obj_type='instance',obj_id=iid,prev_v=None,prev_s=None,new_v=1,new_s='initiating',actor_entity=actor_entity,actor_instance=None,action='instance.register',authority=authority_ref,evidence=[],result='allowed',ikey=self._audit_key('instance.register',key))
            self._command_store(c,'instance.register',key,sem,{'instance_id':iid})
        return iid
    def writer_release(self, grant_id, actor_entity, authority_ref, idempotency_key=None):
        key=idempotency_key or ('writer.release:'+grant_id); sem={'grant_id':grant_id,'actor':actor_entity,'authority_ref':authority_ref}
        with self.connect() as c:
            old=self._command_existing(c,'writer.release',key,sem)
            if old:return old['grant_id']
            g=c.execute('SELECT * FROM writer_grants WHERE writer_grant_id=?',(grant_id,)).fetchone()
            if not g or g['state']!='active': raise SandboxError('writer_conflict')
            self.authority_ref(c,authority_ref,actor_entity,'writer.release',g['scope'])
            c.execute('UPDATE writer_grants SET state="released",row_version=row_version+1 WHERE writer_grant_id=?',(grant_id,))
            c.execute('UPDATE instances SET writer_grant_ref=NULL,writer_generation=NULL,writer_scope=NULL,row_version=row_version+1 WHERE instance_id=?',(g['instance_id'],))
            self._audit(c,obj_type='writer_grant',obj_id=grant_id,prev_v=g['row_version'],prev_s='active',new_v=g['row_version']+1,new_s='released',actor_entity=actor_entity,actor_instance=None,action='writer.release',authority=authority_ref,evidence=[],result='allowed',ikey=self._audit_key('writer.release',key))
            self._command_store(c,'writer.release',key,sem,{'grant_id':grant_id})
        return grant_id
    def _writer_transfer(self,op,grant_id,new_instance,actor_entity,authority_ref,evidence_ref,idempotency_key):
        sem={'grant_id':grant_id,'new_instance':new_instance,'actor':actor_entity,'authority_ref':authority_ref,'evidence_ref':evidence_ref}
        with self.connect() as c:
            old=self._command_existing(c,op,idempotency_key,sem)
            if old:return old['grant_id'],old['generation']
            g=c.execute('SELECT * FROM writer_grants WHERE writer_grant_id=?',(grant_id,)).fetchone()
            if not g or g['state']!='active': raise SandboxError('writer_conflict')
            self.authority_ref(c,authority_ref,actor_entity,op,g['scope'])
            ni=c.execute('SELECT entity_id,lifecycle FROM instances WHERE instance_id=?',(new_instance,)).fetchone()
            if not ni or ni['entity_id']!=g['entity_id'] or ni['lifecycle']!='active': raise SandboxError('stale_instance')
            c.execute('UPDATE writer_grants SET state="superseded",row_version=row_version+1 WHERE writer_grant_id=?',(grant_id,)); ng=oid('writer_grant'); gen=g['generation']+1
            c.execute('INSERT INTO writer_grants VALUES(?,?,?,?,?,?,?,?,?)',(ng,g['entity_id'],new_instance,authority_ref,g['scope'],gen,'active',evidence_ref,1))
            c.execute('UPDATE instances SET writer_grant_ref=NULL,writer_generation=NULL,writer_scope=NULL,row_version=row_version+1 WHERE instance_id=?',(g['instance_id'],))
            c.execute('UPDATE instances SET writer_grant_ref=?,writer_generation=?,writer_scope=?,row_version=row_version+1 WHERE instance_id=?',(ng,gen,g['scope'],new_instance))
            self._audit(c,obj_type='writer_grant',obj_id=grant_id,prev_v=g['row_version'],prev_s='active',new_v=g['row_version']+1,new_s='superseded',actor_entity=actor_entity,actor_instance=None,action=op,authority=authority_ref,evidence=[evidence_ref],result='allowed',ikey=self._audit_key(op,idempotency_key,'old'))
            self._audit(c,obj_type='writer_grant',obj_id=ng,prev_v=None,prev_s=None,new_v=1,new_s='active',actor_entity=actor_entity,actor_instance=None,action=op,authority=authority_ref,evidence=[evidence_ref],result='allowed',ikey=self._audit_key(op,idempotency_key,'new'))
            self._command_store(c,op,idempotency_key,sem,{'grant_id':ng,'generation':gen})
        return ng,gen
    def writer_handoff(self,*a,**k): return self._writer_transfer('writer.handoff',*a,**k)
    def writer_failover(self,*a,**k): return self._writer_transfer('writer.failover',*a,**k)
    def poll_inbox(self, entity_id):
        with self.connect() as c:return [dict(r) for r in c.execute('SELECT i.*,r.route_state,r.payload_type,r.payload_id FROM inbox i JOIN routes r ON r.route_id=i.route_id WHERE i.recipient_entity_id=? ORDER BY i.rowid',(entity_id,))]
    def inspect_task(self, task_id):
        with self.connect() as c:r=c.execute('SELECT * FROM tasks WHERE task_id=?',(task_id,)).fetchone(); return dict(r) if r else None
    def inspect_route(self, route_id):
        with self.connect() as c:r=c.execute('SELECT * FROM routes WHERE route_id=?',(route_id,)).fetchone(); return dict(r) if r else None
    def inspect_audit(self, limit=100):
        with self.connect() as c:return [dict(r) for r in c.execute('SELECT * FROM audit_transitions ORDER BY rowid DESC LIMIT ?',(limit,))]
    def _participant_task(self,c,task_id,entity_id):
        t=c.execute('SELECT owner_entity_id,source_entity_id FROM tasks WHERE task_id=?',(task_id,)).fetchone()
        return bool(t and entity_id in (t['owner_entity_id'],t['source_entity_id']))
    def read_recovery(self, requester_entity, target_entity):
        if requester_entity!=target_entity: raise SandboxError('missing_authority','cross_entity_read_denied')
        return self.recovery_projection(target_entity)
    def read_task(self, requester_entity, task_id):
        with self.connect() as c:
            if not self._participant_task(c,task_id,requester_entity): raise SandboxError('missing_authority','object_read_denied')
        return self.inspect_task(task_id)
    def read_route(self, requester_entity, route_id):
        with self.connect() as c:
            r=c.execute('SELECT sender_entity_id,recipient_entity_id FROM routes WHERE route_id=?',(route_id,)).fetchone()
            if not r or requester_entity not in (r['sender_entity_id'],r['recipient_entity_id']): raise SandboxError('missing_authority','object_read_denied')
        return self.inspect_route(route_id)
    def read_audit(self, requester_entity, limit=100):
        with self.connect() as c:
            return [dict(r) for r in c.execute('SELECT * FROM audit_transitions WHERE actor_entity_id=? ORDER BY rowid DESC LIMIT ?',(requester_entity,limit))]
    def recovery_export(self, entity_id):
        p=self.recovery/(entity_id.replace(':','_')+'.json'); data=self.recovery_projection(entity_id); p.write_text(json.dumps(data,indent=2,sort_keys=True)); return p
    def backup(self, dest:Path):
        if not self._owner_locked: raise SandboxError('coordination_field_unavailable','coordinator_owner_lock_required')
        with self._mutation_lock:
            dest=Path(dest); dest.mkdir(parents=True,exist_ok=True); db=dest/'coordination.sqlite3'
            src=self.connect(); out=sqlite3.connect(db); src.backup(out); out.close(); src.close()
            refs=[]
            c=sqlite3.connect(db); c.row_factory=sqlite3.Row
            try:
                for r in c.execute('SELECT sha256,locator FROM artifact_versions'): refs.append({'sha256':r['sha256'],'locator':r['locator']})
                hw=c.execute('SELECT COUNT(*) FROM audit_transitions').fetchone()[0]
            finally: c.close()
        objdir=dest/'objects'; objdir.mkdir(exist_ok=True)
        missing=[]
        for r in refs:
            s=Path(r['locator']); d=objdir/r['sha256']
            if s.exists(): shutil.copy2(s,d)
            else: missing.append(r['sha256'])
        manifest={'schema_version':2,'db_sha256':hashlib.sha256(db.read_bytes()).hexdigest(),'artifacts':[r['sha256'] for r in refs],'missing':missing,'audit_high_water':hw}
        (dest/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)); return manifest
    def restore_to_staging(self, backup_dir:Path, staging_root:Path):
        v=self.verify_backup(backup_dir); staging_root=Path(staging_root)
        if staging_root.exists(): shutil.rmtree(staging_root)
        (staging_root/'state').mkdir(parents=True); (staging_root/'files'/'objects'/'sha256').mkdir(parents=True)
        shutil.copy2(Path(backup_dir)/'coordination.sqlite3',staging_root/'state'/'coordination.sqlite3')
        for src in (Path(backup_dir)/'objects').glob('*'):
            if src.is_file():
                d=src.name; dst=staging_root/'files'/'objects'/'sha256'/d[:2]/d[2:4]/d; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
        # rewrite restored locators to runtime-compatible object paths
        c=sqlite3.connect(staging_root/'state'/'coordination.sqlite3')
        for (vid,digest) in c.execute('SELECT artifact_version_id,sha256 FROM artifact_versions').fetchall():
            loc=staging_root/'files'/'objects'/'sha256'/digest[:2]/digest[2:4]/digest; c.execute('UPDATE artifact_versions SET locator=? WHERE artifact_version_id=?',(str(loc),vid))
        c.commit(); c.close()
        probe=SandboxService(staging_root); ready=probe.health()['ready']
        with probe.connect() as c: count=c.execute('SELECT COUNT(*) FROM requests').fetchone()[0]
        (staging_root/'readback.json').write_text(json.dumps({'verify':v,'request_count':count,'ready':ready},sort_keys=True))
        return {'ready':bool(v['ok'] and ready),'unknown':v['unknown'],'staging_root':str(staging_root),'request_count':count}
    @staticmethod
    def verify_backup(dest:Path):
        dest=Path(dest); m=json.loads((dest/'manifest.json').read_text()); db=dest/'coordination.sqlite3'
        ok=hashlib.sha256(db.read_bytes()).hexdigest()==m['db_sha256']; unknown=[]
        for d in m['artifacts']:
            p=dest/'objects'/d
            if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=d: unknown.append(d)
        c=sqlite3.connect(db); integ=c.execute('PRAGMA integrity_check').fetchone()[0]; c.close()
        return {'ok':ok and integ=='ok' and not unknown,'unknown':unknown,'sqlite_integrity':integ}

# External sandbox mutation barrier: all externally visible business mutations serialize with backup.
def _barrier_wrap(name):
    original=getattr(SandboxService,name)
    def wrapped(self,*a,**k):
        with self._mutation_lock: return original(self,*a,**k)
    wrapped.__name__=original.__name__; setattr(SandboxService,name,wrapped)
for _n in ('create_request','create_task','assign','accept_assignment','upload_init','upload_bytes','publish_upload','create_route','dispatch_route','receive_route_external','accept_and_close','register_entity_operational','register_instance_operational','activate_instance','grant_writer','writer_release','writer_handoff','writer_failover','authoritative_commit'):
    _barrier_wrap(_n)
