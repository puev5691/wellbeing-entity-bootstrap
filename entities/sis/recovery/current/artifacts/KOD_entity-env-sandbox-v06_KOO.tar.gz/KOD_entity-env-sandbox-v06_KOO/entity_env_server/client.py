from __future__ import annotations
import json, urllib.request, urllib.error
class HTTPClient:
 def __init__(self,base_url,token): self.base=base_url.rstrip('/'); self.token=token
 def request(self,method,path,body=None,raw=None):
  data=raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
  h={'Authorization':'Bearer '+self.token,'X-Correlation-ID':'cli'}
  if raw is None:h['Content-Type']='application/json'
  req=urllib.request.Request(self.base+path,data=data,headers=h,method=method)
  with urllib.request.urlopen(req) as r:
   b=r.read(); return json.loads(b) if r.headers.get('Content-Type','').startswith('application/json') else b
 def command(self,op,**body): return self.request('POST','/api/v1/commands/'+op,body)
 def get(self,path): return self.request('GET',path)
