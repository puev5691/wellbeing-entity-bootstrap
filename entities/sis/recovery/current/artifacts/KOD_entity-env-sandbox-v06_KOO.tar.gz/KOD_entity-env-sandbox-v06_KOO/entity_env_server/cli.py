import argparse,json,os
from pathlib import Path
from .sandbox import SandboxService
from .client import HTTPClient
def main():
 p=argparse.ArgumentParser(); p.add_argument('--root'); p.add_argument('--url'); p.add_argument('--token'); p.add_argument('--admin-token'); p.add_argument('command'); p.add_argument('--dest'); p.add_argument('--path'); p.add_argument('--json',default='{}'); a=p.parse_args()
 if a.url:
  c=HTTPClient(a.url,a.token or os.environ.get('ENTITY_ENV_TOKEN',''))
  if a.command=='get': out=c.get(a.path)
  elif a.command=='command':
   b=json.loads(a.json); op=b.pop('operation'); out=c.command(op,**b)
  else: raise SystemExit('HTTP mode: get|command')
 else:
  s=SandboxService(Path(a.root)); b=json.loads(a.json)
  if a.command=='bootstrap-admin': out=s.bootstrap_operator_admin(b['evidence_path'],b.get('issuer_ref','OPR'))
  elif a.command=='bootstrap-first-entity': out=s.bootstrap_first_entity(a.admin_token,b['entity_id'],b['evidence_path'],b.get('issuer_ref','OPR'))
  elif a.command=='health': out=s.health()
  elif a.command=='orphans': out=s.scan_orphans()
  elif a.command=='backup': out=s.backup(Path(a.dest))
  elif a.command=='admin-import-authority': out={'authority_ref':s.admin_import_authority(a.admin_token,b['holder'],b['issuer_kind'],b['issuer_ref'],b['action'],b['scope'],b['evidence_version'],b.get('ref'),b.get('evidence_path'))}
  elif a.command=='admin-read-recovery': out=s.admin_read_recovery(a.admin_token,b['target_entity'],b['authority_ref'])
  elif a.command=='admin-register-entity': out={'entity_id':s.admin_register_entity(a.admin_token,b['entity_id'],b['authority_ref'],b['idempotency_key'])}
  elif a.command=='admin-register-instance': out={'instance_id':s.admin_register_instance(a.admin_token,b['entity_id'],b['authority_ref'],b['idempotency_key'],b.get('instance_id'))}
  elif a.command=='admin-activate-instance': out={'instance_id':s.admin_activate_instance(a.admin_token,b['instance_id'],b['authority_ref'],b['basis_ref'],b['idempotency_key'])}
  elif a.command=='admin-issue-credential': out=s.admin_issue_instance_credential(a.admin_token,b['instance_id'])
  elif a.command=='admin-revoke-credential': s._admin_principal(a.admin_token); s.revoke_credential(b['credential_id']); out={'credential_id':b['credential_id'],'state':'revoked'}
  elif a.command=='admin-rotate-credential':
   s._admin_principal(a.admin_token); pid=s.create_principal('instance',b['instance_id']); out=s.rotate_credential(pid,b.get('old_credential_id'))
  else: raise SystemExit('unknown direct/admin command')
 print(json.dumps(out,indent=2,default=str))
if __name__=='__main__': main()
