# ОСС single-node external sandbox v0.1

Изолированная реализация по задаче KOO. Реальный VPS, DNS, TLS issuance, systemd, firewall, ChatGPT bridge и production не затрагиваются.

## Состав

- `entity_env_server/sandbox.py` — persistent coordination service поверх принятого domain pilot v0.7.
- `entity_env_server/httpd.py` — loopback HTTP `/api/v1/...`, protected `/files/v1/sha256/<digest>`, health endpoints.
- `entity_env_server/cli.py` — локальный CLI health/orphan scan/backup.
- `migrations/001_pilot.sql` — SQLite schema, principals, credentials, upload intents.
- `entity_env/` + `schema.sql` — неизменённый regression domain layer pilot v0.7.
- `tests/` — 44 regression + external sandbox checks.

## Быстрый запуск тестов

```bash
cd KOD_entity-env-sandbox-v01_KOO
PYTHONPATH=. python3 run_tests.py
```

Ожидаемо: `70 tests`, `OK`.

## Локальный CLI

```bash
PYTHONPATH=. python3 -m entity_env_server --root /tmp/entity-env-sandbox health
PYTHONPATH=. python3 -m entity_env_server --root /tmp/entity-env-sandbox orphans
PYTHONPATH=. python3 -m entity_env_server --root /tmp/entity-env-sandbox backup --dest /tmp/entity-env-backup
```

HTTP harness намеренно не слушает публичный интерфейс автоматически. Тесты поднимают его только на `127.0.0.1` со случайным портом.

## Security boundary

Opaque bearer token создаётся через `secrets.token_urlsafe(32)` (не менее 256 бит исходной энтропии). В SQLite хранится только SHA-256 representation токена. Raw token возвращается только при issuance. Protected bytes выдаёт coordinator после authentication и recipient/source access check. Digest/locator сам по себе доступа не даёт.

`operator_admin` является отдельным technical principal и без project authority basis не выполняет privileged project action.

## Delivery

`dispatch_route(..., durable=False)` моделирует transport attempt и **не** переводит route в `delivered`. Только durable inbox boundary через штатный dispatch фиксирует `delivered`.

## File field

Canonical object path:

`files/objects/sha256/<aa>/<bb>/<digest>`

Version identity: `sha256:<digest>`. Staging не является published artifact. Orphan immutable object не становится authoritative автоматически и обнаруживается `orphans` scan.

## Ограничения

Это implementation harness, а не deployment. TLS/reverse proxy, host hardening, real disk-full injection, production secret vault, public ports и ChatGPT bridge не реализованы. E22 TLS boundary сознательно оставлен deployment-stage проверкой согласно границе задачи; вместо него есть loopback HTTP protected-fetch integration check.

## v0.2 review corrections

Revision v0.2 addresses KOO findings S1-S5 without changing the accepted local-pilot semantics.

- Upload byte write and publish enforce verified active caller instance/entity ownership at the service boundary.
- Operational HTTP calls and protected fetch reject stale/non-active instances even when a credential remains active.
- Operational Entity/Instance registration is audited; writer release/handoff/failover use persistent command idempotency, audit transitions and synchronized instance writer projection.
- Stage-A HTTP surface includes lifecycle commands plus task/route/state/audit/inbox reads; `entity_env_server.client.HTTPClient` and CLI HTTP mode never open SQLite.
- Migration v2 is applied and tracked with checksum; unknown newer schema is not ready.
- Backup uses a service mutation barrier and one SQLite snapshot as the source of artifact refs/high-water; restore-to-staging performs manifest/readback verification.
- Readiness reports schema/file-field/disk state. HTTP operations produce structured JSONL logs without raw bearer tokens.

This remains an isolated loopback sandbox. No VPS, DNS, TLS issuance, systemd, firewall, broker, WebSocket, PostgreSQL, ChatGPT bridge or production change is included.

## v0.4 bounded review corrections (S6-S10)

- Operational upload write/publish requires verified caller identity at the service boundary; omission is not a trusted fallback.
- `route.dispatch` is caller-bound, active-instance checked and persistently idempotent; response separates route and transport identities.
- Recipient protected fetch starts only after durable delivery; external receipt requires recipient-reported immutable SHA-256 evidence.
- Missing file objects return deterministic degraded-state errors.
- Applied migration checksums are validated; backup mutation barrier serializes business mutations; restore recreates runtime-compatible root and reopens it for readback.
- Network reads use least-privilege policy: own recovery/state, participant task/route, entity-filtered audit by default.


## v0.4 bounded corrections S11-S16

- caller instance/entity binding is verified at service boundary for dispatch and receipt;
- immutable object commit precedes DB artifact registration; DB failure leaves only detectable orphan;
- published upload intents are terminal and publish semantics bind the actual SHA-256 digest;
- instance activation is persistently idempotent and requires verifiable initiation/recovery basis;
- digest-only protected fetch evaluates all matching artifact versions and any legitimate access path;
- local/private operator-admin CLI supports authority import, registration/activation, credential issuance and scoped recovery diagnostics without creating project authority from admin credential.

Regression: 124/124 automated tests PASS; S11-S16: 16/16 PASS; A-F PASS.

## v0.5 bounded correction (S17-S21)

This revision closes KOO review S17-S21 without real-host deployment.

- external publish commits immutable object first and performs one coordination finalization transaction with canonical locator; no duplicate digest staging copy remains;
- fresh-root local bootstrap can create the first `operator_admin` and first Entity from a verified local operator evidence file;
- authority import hashes an existing evidence file itself and rejects missing/version-mismatched evidence;
- an exclusive root coordinator lock prevents a second service/admin direct process from becoming write-ready; offline admin mode is rejected while the coordinator owns the root;
- stable principals support multiple credentials, rotation/reissue and admin revocation;
- raw token remains excluded from SQLite/audit/recovery/logs. CLI supports environment-provided operational tokens; argv token remains compatibility-only for isolated tests and is not recommended for host deployment.

Verification: 139 tests total by module aggregation (previous 124 + 15 S17-S21), A-F PASS. `run_tests.py` remains the canonical single-suite runner; the construction environment's execution ceiling required module-separated verification for the final aggregate.

## v0.6 — S22 authority evidence semantic binding

Project-authority import now accepts only canonical structured `authority-evidence/v1` JSON evidence. The immutable SHA-256 is computed by the coordinator from the exact canonical file bytes, and `issuer_kind`, `issuer_ref`, `holder_entity_id`, `action`, and `object_scope` must exactly match the authority being imported. Arbitrary files and semantic mismatches are rejected. `operator_admin` remains a technical principal and cannot change evidence semantics during import.

Canonical project-authority evidence example:

```json
{"action":"entity.register","decision_id":"OPR-decision-001","evidence_kind":"project_authority","holder_entity_id":"ent:KOO","issuer_kind":"operator","issuer_ref":"OPR","object_scope":"entity:ent:NEW","schema_version":"authority-evidence/v1"}
```

The file must be canonical compact JSON with lexicographically sorted keys and one trailing newline. Bootstrap evidence uses the same schema with `evidence_kind="operator_bootstrap"`, `holder_entity_id=null`, `action="sandbox.bootstrap.admin"`, and `object_scope="sandbox:local"`.
