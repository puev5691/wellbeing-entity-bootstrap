import json,sys,unittest
loader=unittest.TestLoader(); suite=loader.discover('tests'); result=unittest.TextTestRunner(verbosity=2).run(suite)
print(json.dumps({'testsRun':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'successful':result.wasSuccessful()}))
sys.exit(0 if result.wasSuccessful() else 1)
