import hashlib,json,tempfile,unittest
from pathlib import Path
from entity_env_server.sandbox import SandboxService,SandboxError

class S22(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory(); self.root=Path(self.t.name); self.s=SandboxService(self.root); self.s.register_entity('ent:KOO'); p=self.s.create_principal('operator_admin','s22-admin'); self.tok=self.s.issue_credential(p)['token']
 def tearDown(self): self.s.close(); self.t.cleanup()
 def evidence(self,**changes):
  o={'schema_version':'authority-evidence/v1','evidence_kind':'project_authority','issuer_kind':'operator','issuer_ref':'OPR','holder_entity_id':'ent:KOO','action':'entity.register','object_scope':'entity:ent:NEW','decision_id':'S22-test'}; o.update(changes); raw=(json.dumps(o,sort_keys=True,separators=(',',':'))+'\n').encode(); p=self.root/('ev-'+hashlib.sha256(raw).hexdigest()[:8]+'.json'); p.write_bytes(raw); return p,'sha256:'+hashlib.sha256(raw).hexdigest()
 def call(self,p,v,holder='ent:KOO',action='entity.register',scope='entity:ent:NEW'):
  return self.s.admin_import_authority(self.tok,holder,'operator','OPR',action,scope,v,evidence_path=p)
 def test_S22_arbitrary_file_cannot_mint_project_authority(self):
  p=self.root/'arbitrary.txt'; p.write_text('this grants no authority'); v='sha256:'+hashlib.sha256(p.read_bytes()).hexdigest()
  with self.assertRaises(SandboxError): self.call(p,v)
 def test_S22_evidence_holder_mismatch_rejected(self):
  p,v=self.evidence(holder_entity_id='ent:OTHER')
  with self.assertRaises(SandboxError): self.call(p,v)
 def test_S22_evidence_action_mismatch_rejected(self):
  p,v=self.evidence(action='recovery.read')
  with self.assertRaises(SandboxError): self.call(p,v)
 def test_S22_evidence_scope_mismatch_rejected(self):
  p,v=self.evidence(object_scope='entity:ent:EVIL')
  with self.assertRaises(SandboxError): self.call(p,v)
 def test_S22_verified_structured_operator_evidence_authorizes_exact_declared_action_scope(self):
  p,v=self.evidence(); ar=self.call(p,v); out=self.s.admin_register_entity(self.tok,'ent:NEW',ar,'s22-register'); self.assertEqual(out,'ent:NEW')
if __name__=='__main__': unittest.main()
