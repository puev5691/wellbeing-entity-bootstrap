from __future__ import annotations
import json, sqlite3, sys, tempfile, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from entity_env.core import CoordinationService, PilotError

ROOT=Path(__file__).resolve().parents[1]

class PilotTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        base=Path(self.tmp.name)
        self.s=CoordinationService(base/'pilot.sqlite3',ROOT/'schema.sql',base/'file_field')
        for e in ('ent:KOO','ent:KOD'):
            self.s.register_entity(e)
        self.kod=self.s.register_instance('ent:KOD','worker')
        self.koo=self.s.register_instance('ent:KOO','worker')
        # Minimal declarative authorities. Issuer supports operator/approved_process explicitly.
        self.auth={}
        for holder,action,scope,kind,ref in [
            ('ent:KOO','task.create','entity:ent:KOD','approved_process','pilot-process:v1'),
            ('ent:KOO','task.assign','task:*','approved_process','pilot-process:v1'),
            ('ent:KOD','assignment.accept','task:*','approved_process','pilot-process:v1'),
            ('ent:KOD','artifact.publish','task:*','approved_process','pilot-process:v1'),
            ('ent:KOD','artifact.authoritative_commit','artifact:*','operator','operator-decision:pilot-impl'),
            ('ent:KOD','route.dispatch','entity:ent:KOO','approved_process','pilot-process:v1'),
            ('ent:KOO','result.accept','task:*','approved_process','pilot-process:v1'),
            ('ent:KOO','writer.grant','entity-current-state:ent:KOD','operator','operator-decision:pilot-impl'),
        ]:
            self.auth[action]=self.s.add_authority(holder,kind,ref,action,scope)

    def tearDown(self): self.tmp.cleanup()

    def make_task(self, prefix='x'):
        r=self.s.create_request('ent:KOO','ent:KOD','produce artifact','pilot',f'{prefix}:request')
        t=self.s.create_task('ent:KOD','ent:KOO',r,'accepted-result',True,'ent:KOO',f'{prefix}:task')
        a=self.s.assign(t,'ent:KOD',self.kod,'ent:KOO',f'{prefix}:assign')
        self.s.accept_assignment(a,'ent:KOD',self.kod,f'{prefix}:accept-assignment')
        return r,t,a

    def test_A_success_path(self):
        r,t,a=self.make_task('A')
        art,av=self.s.publish_artifact(t,'ent:KOD',self.kod,b'pilot-result-A','ent:KOD','A:publish')
        route=self.s.create_route('artifact_version',av,'ent:KOD','ent:KOO','A:route')
        self.s.dispatch_route(route,'tm:A')
        rec=self.s.receive_route(route,'ent:KOO','A:receipt')
        acc=self.s.accept_and_close(t,rec['receipt_id'],'ent:KOO','A:accept')
        with self.s.connect() as c:
            task=dict(c.execute('SELECT * FROM tasks WHERE task_id=?',(t,)).fetchone())
            route_row=dict(c.execute('SELECT * FROM routes WHERE route_id=?',(route,)).fetchone())
        self.assertEqual(task['task_state'],'closed')
        self.assertEqual(route_row['route_state'],'received')
        self.result={'request_id':r,'task_id':t,'assignment_id':a,'artifact_id':art,'artifact_version_id':av,'route_id':route,'receipt_id':rec['receipt_id'],'acceptance_id':acc,'task_state':'closed'}

    def test_B_version_mismatch(self):
        _,t,_=self.make_task('B')
        _,av=self.s.publish_artifact(t,'ent:KOD',self.kod,b'V1','ent:KOD','B:publish')
        route=self.s.create_route('artifact_version',av,'ent:KOD','ent:KOO','B:route'); self.s.dispatch_route(route,'tm:B')
        bad=Path(self.tmp.name)/'bad.bin'; bad.write_bytes(b'V2-different')
        with self.assertRaises(PilotError) as cm: self.s.receive_route(route,'ent:KOO','B:receipt',str(bad))
        self.assertEqual(cm.exception.code,'version_mismatch')
        with self.s.connect() as c:
            self.assertEqual(c.execute("SELECT COUNT(*) FROM receipts WHERE route_id=? AND verification_result='verified'",(route,)).fetchone()[0],0)
            self.assertEqual(c.execute('SELECT COUNT(*) FROM acceptances WHERE task_id=?',(t,)).fetchone()[0],0)
            self.assertNotEqual(c.execute('SELECT task_state FROM tasks WHERE task_id=?',(t,)).fetchone()[0],'closed')

    def test_C_worker_without_writer_grant(self):
        _,t,_=self.make_task('C')
        art,_=self.s.publish_artifact(t,'ent:KOD',self.kod,b'candidate','ent:KOD','C:publish')
        with self.s.connect() as c: before=dict(c.execute('SELECT * FROM artifacts WHERE artifact_id=?',(art,)).fetchone())
        with self.assertRaises(PilotError) as cm:
            self.s.authoritative_commit(art,'ent:KOD',self.kod,None,None,before['row_version'],'C:commit')
        self.assertEqual(cm.exception.code,'writer_conflict')
        self.assertEqual(cm.exception.subcode,'writer_grant_missing')
        with self.s.connect() as c: after=dict(c.execute('SELECT * FROM artifacts WHERE artifact_id=?',(art,)).fetchone())
        self.assertEqual(after['row_version'],before['row_version']); self.assertEqual(after['authoritative'],0); self.assertEqual(after['artifact_currentness'],'candidate')

    def test_D_competing_writer_grant(self):
        auth=self.auth['writer.grant']
        g1,_=self.s.grant_writer('ent:KOD',self.kod,'entity-current-state:ent:KOD','ent:KOO',auth,'pilot-evidence:g1')
        other=self.s.register_instance('ent:KOD','worker')
        with self.assertRaises(PilotError) as cm:
            self.s.grant_writer('ent:KOD',other,'entity-current-state:ent:KOD','ent:KOO',auth,'pilot-evidence:g2')
        self.assertEqual(cm.exception.code,'writer_conflict')
        with self.s.connect() as c:
            rows=c.execute("SELECT writer_grant_id FROM writer_grants WHERE entity_id='ent:KOD' AND scope='entity-current-state:ent:KOD' AND state='active'").fetchall()
        self.assertEqual([r[0] for r in rows],[g1])

    def test_E_dangling_route_payload(self):
        with self.assertRaises(PilotError): self.s.create_route('artifact_version','av:missing','ent:KOD','ent:KOO','E:route')
        with self.s.connect() as c:
            self.assertEqual(c.execute("SELECT COUNT(*) FROM routes WHERE idempotency_key='E:route'").fetchone()[0],0)
            self.assertEqual(c.execute("SELECT COUNT(*) FROM outbox WHERE idempotency_key='outbox:E:route'").fetchone()[0],0)

    def test_F_idempotency(self):
        r1=self.s.create_request('ent:KOO','ent:KOD','x','pilot','F:req'); r2=self.s.create_request('ent:KOO','ent:KOD','x','pilot','F:req'); self.assertEqual(r1,r2)
        t1=self.s.create_task('ent:KOD','ent:KOO',r1,'accepted-result',True,'ent:KOO','F:task'); t2=self.s.create_task('ent:KOD','ent:KOO',r1,'accepted-result',True,'ent:KOO','F:task'); self.assertEqual(t1,t2)
        a=self.s.assign(t1,'ent:KOD',self.kod,'ent:KOO','F:assign'); self.s.accept_assignment(a,'ent:KOD',self.kod,'F:aa')
        _,av=self.s.publish_artifact(t1,'ent:KOD',self.kod,b'idem','ent:KOD','F:pub')
        route1=self.s.create_route('artifact_version',av,'ent:KOD','ent:KOO','F:route'); route2=self.s.create_route('artifact_version',av,'ent:KOD','ent:KOO','F:route'); self.assertEqual(route1,route2)
        self.s.dispatch_route(route1,'tm:F:1')
        self.s.dispatch_route(route1,'tm:F:2')
        rec1=self.s.receive_route(route1,'ent:KOO','F:receipt'); rec2=self.s.receive_route(route1,'ent:KOO','F:receipt'); self.assertEqual(rec1['receipt_id'],rec2['receipt_id'])
        with self.s.connect() as c:
            self.assertEqual(c.execute("SELECT COUNT(*) FROM requests WHERE idempotency_key='F:req'").fetchone()[0],1)
            self.assertEqual(c.execute("SELECT COUNT(*) FROM tasks WHERE idempotency_key='F:task'").fetchone()[0],1)
            self.assertEqual(c.execute("SELECT COUNT(*) FROM routes WHERE idempotency_key='F:route'").fetchone()[0],1)
            self.assertEqual(c.execute("SELECT COUNT(*) FROM outbox WHERE route_id=?",(route1,)).fetchone()[0],1)
            self.assertEqual(c.execute("SELECT attempt_count FROM outbox WHERE route_id=?",(route1,)).fetchone()[0],2)
            self.assertEqual(c.execute("SELECT COUNT(*) FROM receipts WHERE idempotency_key='F:receipt'").fetchone()[0],1)

    def test_G_task_becomes_active_after_assignment_accept(self):
        _,t,a=self.make_task('G')
        with self.s.connect() as c:
            task=dict(c.execute('SELECT task_state,row_version FROM tasks WHERE task_id=?',(t,)).fetchone())
            aa=c.execute("SELECT COUNT(*) FROM audit_transitions WHERE object_type='task' AND object_id=? AND new_state='active'",(t,)).fetchone()[0]
        self.assertEqual(task['task_state'],'active')
        self.assertGreaterEqual(task['row_version'],2)
        self.assertEqual(aa,1)

    def test_H_cross_task_receipt_rejected(self):
        _,t1,_=self.make_task('H1')
        _,av=self.s.publish_artifact(t1,'ent:KOD',self.kod,b'H1-result','ent:KOD','H1:pub')
        route=self.s.create_route('artifact_version',av,'ent:KOD','ent:KOO','H1:route'); self.s.dispatch_route(route,'tm:H1')
        rec=self.s.receive_route(route,'ent:KOO','H1:receipt')
        _,t2,_=self.make_task('H2')
        with self.assertRaises(PilotError) as cm:
            self.s.accept_and_close(t2,rec['receipt_id'],'ent:KOO','H2:accept')
        self.assertEqual(cm.exception.subcode,'invalid_receipt')
        with self.s.connect() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM acceptances WHERE task_id=?',(t2,)).fetchone()[0],0)
            self.assertNotEqual(c.execute('SELECT task_state FROM tasks WHERE task_id=?',(t2,)).fetchone()[0],'closed')

    def test_I_wrong_writer_scope_rejected(self):
        _,t,_=self.make_task('I')
        art,_=self.s.publish_artifact(t,'ent:KOD',self.kod,b'I-candidate','ent:KOD','I:pub')
        wrong_auth=self.s.add_authority('ent:KOO','operator','operator-decision:wrong-scope','writer.grant','unrelated:scope')
        grant,gen=self.s.grant_writer('ent:KOD',self.kod,'unrelated:scope','ent:KOO',wrong_auth,'I:evidence')
        with self.s.connect() as c: before=dict(c.execute('SELECT * FROM artifacts WHERE artifact_id=?',(art,)).fetchone())
        with self.assertRaises(PilotError) as cm:
            self.s.authoritative_commit(art,'ent:KOD',self.kod,grant,gen,before['row_version'],'I:commit')
        self.assertEqual(cm.exception.code,'writer_conflict')
        self.assertEqual(cm.exception.subcode,'writer_scope_or_identity_mismatch')
        with self.s.connect() as c: after=dict(c.execute('SELECT * FROM artifacts WHERE artifact_id=?',(art,)).fetchone())
        self.assertEqual(after['row_version'],before['row_version']); self.assertEqual(after['authoritative'],0)

    def test_J_mismatched_writer_authority_ref_rejected(self):
        with self.assertRaises(PilotError) as cm:
            self.s.grant_writer('ent:KOD',self.kod,'entity-current-state:ent:KOD','ent:KOO',self.auth['task.create'],'J:evidence')
        self.assertEqual(cm.exception.code,'missing_authority')
        self.assertEqual(cm.exception.subcode,'authority_ref_mismatch')
        with self.s.connect() as c:
            self.assertEqual(c.execute("SELECT COUNT(*) FROM writer_grants WHERE entity_id='ent:KOD' AND state='active'").fetchone()[0],0)

    def test_audit_duplicate_vs_integrity_failure(self):
        kw=dict(obj_type='probe',obj_id='probe:1',prev_v=None,prev_s=None,new_v=1,new_s='created',
                actor_entity='ent:KOO',actor_instance=None,action='probe',authority='not_required',evidence=[],result='allowed',ikey='audit:probe')
        with self.s.connect() as c:
            self.assertEqual(self.s._audit(c,**kw),'created')
            self.assertEqual(self.s._audit(c,**kw),'duplicate')
            bad=dict(kw); bad['result']='denied'
            with self.assertRaises(PilotError) as cm: self.s._audit(c,**bad)
            self.assertEqual(cm.exception.subcode,'audit_integrity_failure')

    def test_audit_failure_rolls_back_significant_transition(self):
        r=self.s.create_request('ent:KOO','ent:KOD','audit rollback','pilot','AR:req')
        with self.s.connect() as c:
            c.execute("INSERT INTO audit_transitions(transition_id,object_type,object_id,actor_entity_id,action,authority_ref_or_not_required,result,time_source,idempotency_key) VALUES (?,?,?,?,?,?,?,'unknown',?)",
                      ('tr:collision','probe','probe:x','ent:KOO','probe','not_required','allowed','audit:task.create:AR:task'))
        with self.assertRaises(PilotError) as cm:
            self.s.create_task('ent:KOD','ent:KOO',r,'accepted-result',True,'ent:KOO','AR:task')
        self.assertEqual(cm.exception.subcode,'audit_integrity_failure')
        with self.s.connect() as c:
            self.assertEqual(c.execute("SELECT COUNT(*) FROM tasks WHERE idempotency_key='AR:task'").fetchone()[0],0)


    def test_K_skip_assignment_cannot_close_task(self):
        r=self.s.create_request('ent:KOO','ent:KOD','K','pilot','K:req')
        t=self.s.create_task('ent:KOD','ent:KOO',r,'accepted-result',True,'ent:KOO','K:task')
        with self.assertRaises(PilotError) as cm:
            self.s.publish_artifact(t,'ent:KOD',self.kod,b'K','ent:KOD','K:pub')
        self.assertEqual(cm.exception.subcode,'task_not_active')
        with self.s.connect() as c: self.assertEqual(c.execute('SELECT task_state FROM tasks WHERE task_id=?',(t,)).fetchone()[0],'created')

    def test_L_foreign_instance_cannot_publish_artifact(self):
        _,t,_=self.make_task('L')
        with self.assertRaises(PilotError) as cm:
            self.s.publish_artifact(t,'ent:KOD',self.koo,b'L','ent:KOD','L:pub')
        self.assertEqual(cm.exception.subcode,'artifact_producer_mismatch')

    def test_M_unrelated_request_cannot_be_task_origin(self):
        r=self.s.create_request('ent:KOO','ent:KOO','M','pilot','M:req')
        with self.assertRaises(PilotError) as cm:
            self.s.create_task('ent:KOD','ent:KOO',r,'accepted-result',True,'ent:KOO','M:task')
        self.assertEqual(cm.exception.subcode,'origin_request_mismatch')

    def test_N_request_semantic_idempotency_mismatch(self):
        self.s.create_request('ent:KOO','ent:KOD','one','pilot','N:req')
        with self.assertRaises(PilotError) as cm: self.s.create_request('ent:KOO','ent:KOD','two','pilot','N:req')
        self.assertEqual(cm.exception.subcode,'idempotency_semantic_mismatch')

    def test_N_task_semantic_idempotency_mismatch(self):
        r=self.s.create_request('ent:KOO','ent:KOD','N','pilot','N2:req')
        self.s.create_task('ent:KOD','ent:KOO',r,'accepted-result',True,'ent:KOO','N2:task')
        with self.assertRaises(PilotError) as cm: self.s.create_task('ent:KOD','ent:KOO',r,'other-criterion',True,'ent:KOO','N2:task')
        self.assertEqual(cm.exception.subcode,'idempotency_semantic_mismatch')

    def test_N_route_semantic_idempotency_mismatch(self):
        _,t,_=self.make_task('N3'); _,av1=self.s.publish_artifact(t,'ent:KOD',self.kod,b'N31','ent:KOD','N3:p1')
        # second version as a second artifact to preserve task result semantics for test purposes
        art2,av2=self.s.publish_artifact(t,'ent:KOD',self.kod,b'N32','ent:KOD','N3:p2')
        self.s.create_route('artifact_version',av1,'ent:KOD','ent:KOO','N3:route')
        with self.assertRaises(PilotError) as cm: self.s.create_route('artifact_version',av2,'ent:KOD','ent:KOO','N3:route')
        self.assertEqual(cm.exception.subcode,'idempotency_semantic_mismatch')

    def test_O_version_mismatch_failure_is_audited(self):
        _,t,_=self.make_task('O1'); _,av=self.s.publish_artifact(t,'ent:KOD',self.kod,b'V1','ent:KOD','O1:pub')
        route=self.s.create_route('artifact_version',av,'ent:KOD','ent:KOO','O1:route'); self.s.dispatch_route(route,'tm:O1')
        bad=Path(self.tmp.name)/'O1bad'; bad.write_bytes(b'V2')
        with self.assertRaises(PilotError): self.s.receive_route(route,'ent:KOO','O1:receipt',str(bad))
        with self.s.connect() as c: n=c.execute("SELECT COUNT(*) FROM audit_transitions WHERE object_id=? AND result='version_mismatch'",(route,)).fetchone()[0]
        self.assertEqual(n,1)

    def test_O_writer_conflict_failure_is_audited(self):
        _,t,_=self.make_task('O2'); art,_=self.s.publish_artifact(t,'ent:KOD',self.kod,b'O2','ent:KOD','O2:pub')
        with self.s.connect() as c: v=c.execute('SELECT row_version FROM artifacts WHERE artifact_id=?',(art,)).fetchone()[0]
        with self.assertRaises(PilotError): self.s.authoritative_commit(art,'ent:KOD',self.kod,None,None,v,'O2:commit')
        with self.s.connect() as c: n=c.execute("SELECT COUNT(*) FROM audit_transitions WHERE object_id=? AND result='writer_conflict'",(art,)).fetchone()[0]
        self.assertEqual(n,1)

    def test_P_dispatch_retry_cannot_regress_received_route(self):
        _,t,_=self.make_task('P'); _,av=self.s.publish_artifact(t,'ent:KOD',self.kod,b'P','ent:KOD','P:pub')
        route=self.s.create_route('artifact_version',av,'ent:KOD','ent:KOO','P:route'); self.s.dispatch_route(route,'tm:P1'); self.s.receive_route(route,'ent:KOO','P:receipt')
        self.s.dispatch_route(route,'tm:P2')
        with self.s.connect() as c: self.assertEqual(c.execute('SELECT route_state FROM routes WHERE route_id=?',(route,)).fetchone()[0],'received')

    def test_Q_receive_before_dispatch_rejected(self):
        _,t,_=self.make_task('Q'); _,av=self.s.publish_artifact(t,'ent:KOD',self.kod,b'Q','ent:KOD','Q:pub')
        route=self.s.create_route('artifact_version',av,'ent:KOD','ent:KOO','Q:route')
        with self.assertRaises(PilotError) as cm: self.s.receive_route(route,'ent:KOO','Q:receipt')
        self.assertEqual(cm.exception.subcode,'route_not_delivered')
        with self.s.connect() as c: self.assertEqual(c.execute('SELECT COUNT(*) FROM receipts WHERE route_id=?',(route,)).fetchone()[0],0)

    def test_R_unresolved_dependency_present_in_recovery_projection(self):
        r=self.s.create_request('ent:KOO','ent:KOD','R','pilot','R:req'); t=self.s.create_task('ent:KOD','ent:KOO',r,'accepted-result',True,'ent:KOO','R:task')
        with self.s.connect() as c: c.execute("INSERT INTO dependencies VALUES (?,?,?,?,?,'unsatisfied',1)",('dep:R',t,'artifact_exists','artifact:x',None))
        proj=self.s.recovery_projection('ent:KOD')
        self.assertEqual(proj['unresolved_dependencies'][0]['dependency_id'],'dep:R')
        self.assertEqual(proj['unresolved_dependencies'][0]['evaluation_state'],'unsatisfied')

    def test_inbox_duplicate_vs_integrity_failure(self):
        _,t,_=self.make_task('IN'); _,av=self.s.publish_artifact(t,'ent:KOD',self.kod,b'IN','ent:KOD','IN:pub')
        r1=self.s.create_route('artifact_version',av,'ent:KOD','ent:KOO','IN:r1'); self.s.dispatch_route(r1,'tm:same')
        # exact duplicate identity for same route is tolerated
        self.s.dispatch_route(r1,'tm:same')
        r2=self.s.create_route('artifact_version',av,'ent:KOD','ent:KOO','IN:r2')
        with self.assertRaises(PilotError) as cm: self.s.dispatch_route(r2,'tm:same')
        self.assertEqual(cm.exception.subcode,'inbox_integrity_failure')


    def test_S_publish_semantic_idempotency_mismatch(self):
        _,t,_=self.make_task('S')
        self.s.publish_artifact(t,'ent:KOD',self.kod,b'ONE','ent:KOD','S:pub')
        with self.assertRaises(PilotError) as cm:
            self.s.publish_artifact(t,'ent:KOD',self.kod,b'TWO-DIFFERENT','ent:KOD','S:pub')
        self.assertEqual(cm.exception.subcode,'idempotency_semantic_mismatch')

    def test_T_assignment_semantic_idempotency_mismatch(self):
        r=self.s.create_request('ent:KOO','ent:KOD','T','pilot','T:req')
        t=self.s.create_task('ent:KOD','ent:KOO',r,'accepted-result',True,'ent:KOO','T:task')
        other=self.s.register_instance('ent:KOD','worker')
        self.s.assign(t,'ent:KOD',self.kod,'ent:KOO','T:assign')
        with self.assertRaises(PilotError) as cm:
            self.s.assign(t,'ent:KOD',other,'ent:KOO','T:assign')
        self.assertEqual(cm.exception.subcode,'idempotency_semantic_mismatch')

    def test_U_assignment_accept_exact_retry(self):
        r=self.s.create_request('ent:KOO','ent:KOD','U','pilot','U:req')
        t=self.s.create_task('ent:KOD','ent:KOO',r,'accepted-result',True,'ent:KOO','U:task')
        a=self.s.assign(t,'ent:KOD',self.kod,'ent:KOO','U:assign')
        x=self.s.accept_assignment(a,'ent:KOD',self.kod,'U:accept')
        y=self.s.accept_assignment(a,'ent:KOD',self.kod,'U:accept')
        self.assertEqual(x,y)
        with self.s.connect() as c:
            self.assertEqual(c.execute("SELECT COUNT(*) FROM audit_transitions WHERE object_type='assignment' AND object_id=? AND action='assignment.accept'",(a,)).fetchone()[0],1)

    def test_V_acceptance_semantic_idempotency_mismatch(self):
        _,t1,_=self.make_task('V1')
        _,av1=self.s.publish_artifact(t1,'ent:KOD',self.kod,b'V1','ent:KOD','V1:pub')
        ro1=self.s.create_route('artifact_version',av1,'ent:KOD','ent:KOO','V1:route'); self.s.dispatch_route(ro1,'tm:V1')
        rec1=self.s.receive_route(ro1,'ent:KOO','V1:receipt')['receipt_id']
        self.s.accept_and_close(t1,rec1,'ent:KOO','V:accept')
        _,t2,_=self.make_task('V2')
        _,av2=self.s.publish_artifact(t2,'ent:KOD',self.kod,b'V2','ent:KOD','V2:pub')
        ro2=self.s.create_route('artifact_version',av2,'ent:KOD','ent:KOO','V2:route'); self.s.dispatch_route(ro2,'tm:V2')
        rec2=self.s.receive_route(ro2,'ent:KOO','V2:receipt')['receipt_id']
        with self.assertRaises(PilotError) as cm:
            self.s.accept_and_close(t1,rec2,'ent:KOO','V:accept')
        self.assertEqual(cm.exception.subcode,'idempotency_semantic_mismatch')

    def test_W_authoritative_commit_exact_retry(self):
        _,t,_=self.make_task('W')
        art,_=self.s.publish_artifact(t,'ent:KOD',self.kod,b'W','ent:KOD','W:pub')
        grant,gen=self.s.grant_writer('ent:KOD',self.kod,'entity-current-state:ent:KOD','ent:KOO',self.auth['writer.grant'],'W:evidence',idempotency_key='W:grant')
        with self.s.connect() as c: v=c.execute('SELECT row_version FROM artifacts WHERE artifact_id=?',(art,)).fetchone()[0]
        x=self.s.authoritative_commit(art,'ent:KOD',self.kod,grant,gen,v,'W:commit')
        y=self.s.authoritative_commit(art,'ent:KOD',self.kod,grant,gen,v,'W:commit')
        self.assertEqual(x,y)
        with self.s.connect() as c: self.assertEqual(c.execute('SELECT row_version FROM artifacts WHERE artifact_id=?',(art,)).fetchone()[0],v+1)

    def test_X_receipt_semantic_idempotency_mismatch(self):
        _,t,_=self.make_task('X')
        _,av=self.s.publish_artifact(t,'ent:KOD',self.kod,b'X','ent:KOD','X:pub')
        ro=self.s.create_route('artifact_version',av,'ent:KOD','ent:KOO','X:route'); self.s.dispatch_route(ro,'tm:X')
        self.s.receive_route(ro,'ent:KOO','X:receipt')
        other=Path(self.tmp.name)/'other'; other.write_bytes(b'OTHER')
        with self.assertRaises(PilotError) as cm:
            self.s.receive_route(ro,'ent:KOO','X:receipt',str(other))
        self.assertEqual(cm.exception.subcode,'idempotency_semantic_mismatch')

    def test_Y_idempotency_key_scoped_by_operation(self):
        key='Y:same-client-key'
        r=self.s.create_request('ent:KOO','ent:KOD','Y','pilot',key)
        t=self.s.create_task('ent:KOD','ent:KOO',r,'accepted-result',True,'ent:KOO','Y:task')
        a=self.s.assign(t,'ent:KOD',self.kod,'ent:KOO','Y:assign'); self.s.accept_assignment(a,'ent:KOD',self.kod,'Y:aa')
        _,av=self.s.publish_artifact(t,'ent:KOD',self.kod,b'Y','ent:KOD','Y:pub')
        ro=self.s.create_route('artifact_version',av,'ent:KOD','ent:KOO',key)
        self.assertTrue(r.startswith('request:')); self.assertTrue(ro.startswith('route:'))
        with self.s.connect() as c:
            rows=c.execute("SELECT operation,idempotency_key FROM command_idempotency WHERE idempotency_key=? ORDER BY operation",(key,)).fetchall()
        self.assertEqual([x['operation'] for x in rows],['request.create','route.create'])

    def test_writer_grant_exact_retry(self):
        args=('ent:KOD',self.kod,'entity-current-state:ent:KOD','ent:KOO',self.auth['writer.grant'],'WG:evidence')
        a=self.s.grant_writer(*args,idempotency_key='WG:key')
        b=self.s.grant_writer(*args,idempotency_key='WG:key')
        self.assertEqual(a,b)
        with self.s.connect() as c:
            self.assertEqual(c.execute("SELECT COUNT(*) FROM writer_grants WHERE entity_id='ent:KOD' AND state='active'").fetchone()[0],1)

    def test_Z1_foreign_assignee_instance_rejected_at_assignment_create(self):
        r=self.s.create_request('ent:KOO','ent:KOD','Z1','pilot','Z1:req')
        t=self.s.create_task('ent:KOD','ent:KOO',r,'accepted-result',True,'ent:KOO','Z1:task')
        self.s.register_entity('ent:KAN'); foreign=self.s.register_instance('ent:KAN','worker')
        with self.assertRaises(PilotError): self.s.assign(t,'ent:KOD',foreign,'ent:KOO','Z1:assign')
        with self.s.connect() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM assignments WHERE task_id=?',(t,)).fetchone()[0],0)

    def test_Z2_closed_task_points_to_accepted_artifact(self):
        _,t,_=self.make_task('Z2')
        a1,v1=self.s.publish_artifact(t,'ent:KOD',self.kod,b'Z2-A1','ent:KOD','Z2:p1')
        a2,v2=self.s.publish_artifact(t,'ent:KOD',self.kod,b'Z2-A2','ent:KOD','Z2:p2')
        with self.s.connect() as c: self.assertIsNone(c.execute('SELECT result_artifact_id FROM tasks WHERE task_id=?',(t,)).fetchone()[0])
        ro=self.s.create_route('artifact_version',v1,'ent:KOD','ent:KOO','Z2:r'); self.s.dispatch_route(ro,'tm:Z2')
        rec=self.s.receive_route(ro,'ent:KOO','Z2:rec')['receipt_id']; self.s.accept_and_close(t,rec,'ent:KOO','Z2:acc')
        with self.s.connect() as c:
            row=c.execute('SELECT task_state,result_artifact_id FROM tasks WHERE task_id=?',(t,)).fetchone()
        self.assertEqual((row['task_state'],row['result_artifact_id']),('closed',a1)); self.assertNotEqual(row['result_artifact_id'],a2)

    def test_Z3_retry_after_resolved_version_mismatch_succeeds(self):
        _,t,_=self.make_task('Z3'); _,av=self.s.publish_artifact(t,'ent:KOD',self.kod,b'GOOD','ent:KOD','Z3:p')
        ro=self.s.create_route('artifact_version',av,'ent:KOD','ent:KOO','Z3:r'); self.s.dispatch_route(ro,'tm:Z3')
        with self.s.connect() as c: loc=c.execute('SELECT locator FROM artifact_versions WHERE artifact_version_id=?',(av,)).fetchone()[0]
        Path(loc).write_bytes(b'BAD')
        with self.assertRaises(PilotError) as cm: self.s.receive_route(ro,'ent:KOO','Z3:rec')
        self.assertEqual(cm.exception.code,'version_mismatch')
        Path(loc).write_bytes(b'GOOD')
        out=self.s.receive_route(ro,'ent:KOO','Z3:rec'); self.assertEqual(out['verification_result'],'verified')

    def test_Z4_second_equivalent_valid_authority_ref_accepted(self):
        second=self.s.add_authority('ent:KOO','approved_process','fixture','writer.grant','entity-current-state:ent:KOD',ref='auth:second')
        g,gen=self.s.grant_writer('ent:KOD',self.kod,'entity-current-state:ent:KOD','ent:KOO',second,'Z4:evidence',idempotency_key='Z4:g')
        self.assertTrue(g.startswith('wg:')); self.assertEqual(gen,1)

    def test_Z5_foreign_artifact_dispatch_rejected(self):
        _,t,_=self.make_task('Z5'); _,av=self.s.publish_artifact(t,'ent:KOD',self.kod,b'Z5','ent:KOD','Z5:p')
        self.s.register_entity('ent:KAN'); self.s.add_authority('ent:KAN','approved_process','fixture','route.dispatch','entity:ent:KOO')
        with self.assertRaises(PilotError) as cm: self.s.create_route('artifact_version',av,'ent:KAN','ent:KOO','Z5:r')
        self.assertEqual(cm.exception.subcode,'foreign_artifact_dispatch')
        with self.s.connect() as c: self.assertEqual(c.execute("SELECT COUNT(*) FROM routes WHERE idempotency_key='Z5:r'").fetchone()[0],0)

    def test_Z6_foreign_or_misdirected_request_route_rejected(self):
        req=self.s.create_request('ent:KOO','ent:KOD','Z6','pilot','Z6:req')
        self.s.register_entity('ent:FOO')
        self.s.add_authority('ent:FOO','approved_process','fixture','route.dispatch','entity:ent:KOD')
        with self.assertRaises(PilotError) as cm:
            self.s.create_route('request',req,'ent:FOO','ent:KOD','Z6:route')
        self.assertEqual(cm.exception.subcode,'request_route_mismatch')
        with self.s.connect() as c:
            self.assertEqual(c.execute("SELECT COUNT(*) FROM routes WHERE idempotency_key='Z6:route'").fetchone()[0],0)

    def test_Z7_assignment_to_closed_or_nonassignable_task_rejected(self):
        _,t,_=self.make_task('Z7')
        _,av=self.s.publish_artifact(t,'ent:KOD',self.kod,b'Z7','ent:KOD','Z7:pub')
        ro=self.s.create_route('artifact_version',av,'ent:KOD','ent:KOO','Z7:route'); self.s.dispatch_route(ro,'tm:Z7')
        rec=self.s.receive_route(ro,'ent:KOO','Z7:rec')['receipt_id']; self.s.accept_and_close(t,rec,'ent:KOO','Z7:close')
        with self.assertRaises(PilotError) as cm:
            self.s.assign(t,'ent:KOD',self.kod,'ent:KOO','Z7:assign2')
        self.assertEqual(cm.exception.subcode,'task_not_assignable')

    def test_Z8_foreign_assignee_for_pilot_task_rejected(self):
        r=self.s.create_request('ent:KOO','ent:KOD','Z8a','pilot','Z8a:req')
        t=self.s.create_task('ent:KOD','ent:KOO',r,'accepted-result',True,'ent:KOO','Z8a:task')
        self.s.register_entity('ent:FOO'); foo=self.s.register_instance('ent:FOO','worker')
        with self.assertRaises(PilotError) as cm:
            self.s.assign(t,'ent:FOO',foo,'ent:KOO','Z8a:assign')
        self.assertEqual(cm.exception.subcode,'pilot_foreign_assignee')

    def test_Z8_result_producer_must_match_accepted_assignment(self):
        _,t,_=self.make_task('Z8b')
        other=self.s.register_instance('ent:KOD','worker')
        with self.assertRaises(PilotError) as cm:
            self.s.publish_artifact(t,'ent:KOD',other,b'wrong producer','ent:KOD','Z8b:pub')
        self.assertEqual(cm.exception.subcode,'assignment_producer_mismatch')
        with self.s.connect() as c:
            self.assertEqual(c.execute("SELECT COUNT(*) FROM artifacts WHERE task_id=?",(t,)).fetchone()[0],0)

    def test_Z9_route_created_delivered_received_have_audit_transitions(self):
        _,t,_=self.make_task('Z9')
        _,av=self.s.publish_artifact(t,'ent:KOD',self.kod,b'Z9','ent:KOD','Z9:pub')
        ro=self.s.create_route('artifact_version',av,'ent:KOD','ent:KOO','Z9:route')
        self.s.dispatch_route(ro,'tm:Z9')
        self.s.receive_route(ro,'ent:KOO','Z9:rec')
        with self.s.connect() as c:
            rows=c.execute("SELECT previous_state,new_state,action FROM audit_transitions WHERE object_type='route' AND object_id=? ORDER BY rowid",(ro,)).fetchall()
        self.assertEqual([(r['previous_state'],r['new_state'],r['action']) for r in rows],[(None,'created','route.dispatch'),('created','delivered','route.deliver'),('delivered','received','route.receive')])

    def test_Z10a_publish_current_rejected_without_writer_bypass(self):
        _,t,_=self.make_task('Z10a')
        with self.s.connect() as c:
            before=c.execute("SELECT COUNT(*) FROM artifacts WHERE task_id=?",(t,)).fetchone()[0]
        with self.assertRaises(PilotError) as cm:
            self.s.publish_artifact(t,'ent:KOD',self.kod,b'Z10-current','ent:KOD','Z10a:pub',currentness='current')
        self.assertEqual(cm.exception.subcode,'invalid_artifact_currentness')
        with self.s.connect() as c:
            after=c.execute("SELECT COUNT(*) FROM artifacts WHERE task_id=?",(t,)).fetchone()[0]
            currents=c.execute("SELECT COUNT(*) FROM artifacts WHERE task_id=? AND artifact_currentness='current'",(t,)).fetchone()[0]
        self.assertEqual((before,after,currents),(0,0,0))

    def test_Z10b_unknown_currentness_rejected_without_artifact_row(self):
        _,t,_=self.make_task('Z10b')
        with self.assertRaises(PilotError) as cm:
            self.s.publish_artifact(t,'ent:KOD',self.kod,b'Z10-unknown','ent:KOD','Z10b:pub',currentness='banana')
        self.assertEqual(cm.exception.subcode,'invalid_artifact_currentness')
        with self.s.connect() as c:
            self.assertEqual(c.execute("SELECT COUNT(*) FROM artifacts WHERE task_id=?",(t,)).fetchone()[0],0)
            self.assertEqual(c.execute("SELECT COUNT(*) FROM command_idempotency WHERE operation='artifact.publish' AND idempotency_key='Z10b:pub'").fetchone()[0],0)

if __name__=='__main__': unittest.main(verbosity=2)
